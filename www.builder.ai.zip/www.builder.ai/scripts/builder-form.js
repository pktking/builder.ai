var za=Object.create;var Pt=Object.defineProperty;var Ga=Object.getOwnPropertyDescriptor;var Va=Object.getOwnPropertyNames;var Ka=Object.getPrototypeOf,Ya=Object.prototype.hasOwnProperty;var Y=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports);var Ja=(e,t,a,i)=>{if(t&&typeof t=="object"||typeof t=="function")for(let r of Va(t))!Ya.call(e,r)&&r!==a&&Pt(e,r,{get:()=>t[r],enumerable:!(i=Ga(t,r))||i.enumerable});return e};var Qa=(e,t,a)=>(a=e!=null?za(Ka(e)):{},Ja(t||!e||!e.__esModule?Pt(a,"default",{value:e,enumerable:!0}):a,e));var Rt=Y(at=>{"use strict";Object.defineProperty(at,"__esModule",{value:!0});function Za(e,t){if(!e)throw new Error(t)}at.default=Za});var qt=Y(De=>{"use strict";var Xa=De&&De.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(De,"__esModule",{value:!0});var Ne=Xa(Rt());function ei(e){Ne.default(Array.isArray(e.domains),"domains must be an array"),Ne.default(Array.isArray(e.topLevelDomains),"topLevelDomains must be an array"),Ne.default(Array.isArray(e.secondLevelDomains),"secondLevelDomains must be an array"),Ne.default(typeof e.distanceFunction=="function","distanceFunction must be a function")}De.default=ei});var Ot=Y(it=>{"use strict";Object.defineProperty(it,"__esModule",{value:!0});function ti(e){return encodeURI(e).replace(/%20/g," ").replace(/%25/g,"%").replace(/%5E/g,"^").replace(/%60/g,"`").replace(/%7B/g,"{").replace(/%7C/g,"|").replace(/%7D/g,"}")}it.default=ti});var $t=Y(ot=>{"use strict";Object.defineProperty(ot,"__esModule",{value:!0});function ai(e){let{domain:t,domains:a,distanceFunction:i,threshold:r}=e,s,o=1/0,n=null;if(!(!t||!a)){for(let c=0;c<a.length;c++){if(t===a[c])return t;s=i(t,a[c]),s<o&&(o=s,n=a[c])}if(o<=r&&n!==null)return n}}ot.default=ai});var Bt=Y(rt=>{"use strict";Object.defineProperty(rt,"__esModule",{value:!0});var ii=/\s/;function oi(e){return e.trim?e.trim():ni(ri(e))}function ri(e){return e.trimLeft?e.trimLeft():e.replace(/^\s\s*/,"")}function ni(e){if(e.trimRight)return e.trimRight();let t=e.length;for(;ii.test(e.charAt(--t)););return e.slice(0,t+1)}rt.default=oi});var Nt=Y(Fe=>{"use strict";var si=Fe&&Fe.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(Fe,"__esModule",{value:!0});var di=si(Bt()),li=2;function ui(e){let a=di.default(e).split("@");if(a.length<li)return!1;for(let n=0;n<a.length;n++)if(a[n]==="")return!1;let i="",r="",s=a.pop(),o=s.split(".");if(o.length===0)return!1;if(o.length==1)r=o[0];else{i=o[0];for(let n=1;n<o.length;n++)r+=o[n]+".";r=r.substring(0,r.length-1)}return{topLevelDomain:r,secondLevelDomain:i,domain:s,address:a.join("@")}}Fe.default=ui});var Wt=Y(Te=>{"use strict";var st=Te&&Te.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(Te,"__esModule",{value:!0});var ci=st(Ot()),nt=st($t()),gi=st(Nt());function mi(e){let t=ci.default(e.email.toLowerCase()),a=gi.default(t);if(!a)return;let{domains:i,domainThreshold:r,distanceFunction:s,secondLevelDomains:o,topLevelDomains:n}=e;if(o&&n&&o.indexOf(a.secondLevelDomain)!==-1&&n.indexOf(a.topLevelDomain)!==-1)return;let c=nt.default({domain:a.domain,domains:i,distanceFunction:s,threshold:r});if(c)return c==a.domain?void 0:{address:a.address,domain:c,full:a.address+"@"+c};let h=nt.default({domain:a.secondLevelDomain,domains:o,distanceFunction:s,threshold:e.secondLevelThreshold}),g=nt.default({domain:a.topLevelDomain,domains:n,distanceFunction:s,threshold:e.topLevelThreshold});if(a.domain){c=a.domain;let x=!1;if(h&&h!=a.secondLevelDomain&&(c=c.replace(a.secondLevelDomain,h),x=!0),g&&g!=a.topLevelDomain&&a.secondLevelDomain!==""&&(c=c.replace(new RegExp(a.topLevelDomain+"$"),g),x=!0),x)return{address:a.address,domain:c,full:a.address+"@"+c}}}Te.default=mi});var Ut=Y(dt=>{"use strict";Object.defineProperty(dt,"__esModule",{value:!0});function bi(e,t){if(e==null||e.length===0)return t==null||t.length===0?0:t.length;if(t==null||t.length===0)return e.length;let a=0,i=0,r=0,s=0,o=5;for(;a+i<e.length&&a+r<t.length;){if(e.charAt(a+i)==t.charAt(a+r))s++;else{i=0,r=0;for(let n=0;n<o;n++){if(a+n<e.length&&e.charAt(a+n)==t.charAt(a)){i=n;break}if(a+n<t.length&&e.charAt(a)==t.charAt(a+n)){r=n;break}}}a++}return(e.length+t.length)/2-s}dt.default=bi});var lt=Y(ee=>{"use strict";var fi=ee&&ee.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(ee,"__esModule",{value:!0});ee.POPULAR_TLDS=ee.POPULAR_DOMAINS=ee.DEFAULT_CONFIG=void 0;var pi=fi(Ut()),jt=["msn.com","bellsouth.net","telus.net","comcast.net","optusnet.com.au","earthlink.net","qq.com","sky.com","icloud.com","sympatico.ca","googlemail.com","att.net","xtra.co.nz","web.de","cox.net","gmail.com","ymail.com","aim.com","rogers.com","verizon.net","rocketmail.com","optonline.net","sbcglobal.net","aol.com","aim.com","me.com","mailw.com","btinternet.com","charter.net","shaw.ca","hey.com","proton.me","pm.com","protonmail.com","zoho.com","yandex.com","titan.email"];ee.POPULAR_DOMAINS=jt;var Ht=["com","com.au","com.tw","co","ca","co.nz","co.uk","de","fr","it","ru","org","edu","gov","jp","nl","kr","se","eu","ie","co.il","us","at","be","dk","hk","es","gr","ch","no","cz","net","net.au","info","biz","mil","co.jp","sg","hu","uk","sk","ar","cf","cl","cn","ga","gq","ir","ml","mx","nu","nz","ph","pl","ro","tk","tw","ua","vg","ws","xn","za","app","au","ai","biz","br","blog","cloud","club","cc","de","dev","digital","fi","finance","id","in","io","me","mobi","network","pw","so","xyz","software","to","tech"];ee.POPULAR_TLDS=Ht;var hi={domainThreshold:2,domains:jt,secondLevelThreshold:2,secondLevelDomains:["yahoo","hotmail","mail","live","outlook"],topLevelThreshold:2,topLevelDomains:Ht,distanceFunction:pi.default};ee.DEFAULT_CONFIG=hi});var zt=Y(ut=>{"use strict";Object.defineProperty(ut,"__esModule",{value:!0});var fe=lt();function vi(e){return{email:e.email,domains:e.domains||fe.DEFAULT_CONFIG.domains,topLevelDomains:e.topLevelDomains||fe.DEFAULT_CONFIG.topLevelDomains,secondLevelDomains:e.secondLevelDomains||fe.DEFAULT_CONFIG.secondLevelDomains,distanceFunction:e.distanceFunction||fe.DEFAULT_CONFIG.distanceFunction,domainThreshold:e.domainThreshold||fe.DEFAULT_CONFIG.domainThreshold,secondLevelThreshold:e.secondLevelThreshold||fe.DEFAULT_CONFIG.secondLevelThreshold,topLevelThreshold:e.topLevelThreshold||fe.DEFAULT_CONFIG.topLevelThreshold,suggested:e.suggested||void 0,empty:e.suggested||void 0}}ut.default=vi});var Gt=Y(Le=>{"use strict";var ct=Le&&Le.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(Le,"__esModule",{value:!0});var yi=ct(qt()),ki=ct(Wt()),wi=ct(zt());function _i(e){let t=wi.default(e);yi.default(t||{});let a=ki.default(t);return!a&&e.empty&&e.empty(),a&&e.suggested&&e.suggested(a),a}Le.default=_i});var Kt=Y(Q=>{"use strict";var xi=Q&&Q.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(Q,"__esModule",{value:!0});Q.POPULAR_TLDS=Q.POPULAR_DOMAINS=Q.run=void 0;var Vt=xi(Gt());Q.run=Vt.default;var We=lt();Object.defineProperty(Q,"POPULAR_DOMAINS",{enumerable:!0,get:function(){return We.POPULAR_DOMAINS}});Object.defineProperty(Q,"POPULAR_TLDS",{enumerable:!0,get:function(){return We.POPULAR_TLDS}});var Si={run:Vt.default,POPULAR_DOMAINS:We.POPULAR_DOMAINS,POPULAR_TLDS:We.POPULAR_TLDS};Q.default=Si});var Ie=Qa(Kt());var Yt="209",Jt="224",gt="225",Qt="226",Zt="227",Xt="229",ea="230",ta="232",aa="243",ia="244";function z(e,t,a=()=>{}){new URL(e.location.href).host==="www.builder.ai"?(e._vis_opt_queue=e._vis_opt_queue||[],new URL(e.location.href).searchParams.has("dev-vwo-goals")&&console.log(`Enqueued VWO Goal: G${t}`),e._vis_opt_queue.push(function(){e._vis_opt_goal_conversion(t),new URL(e.location.href).searchParams.has("dev-vwo-goals")&&console.log(`Sent VWO Goal: G${t}`)})):console.log(`Would fire VWO Goal: G${t}`);let i="VWO_goal";if(t==="229"?i="form_submission":t==="230"?i="form_interaction":t==="243"?i="lead_form_main_details_submitted":t==="244"&&(i="lead_form_bant_details_submitted"),e.trackMixpanelEvent&&e.trackMixpanelEvent(i,{VWO_goal:`G${t}`,time:Date.now()/1e3},a),i!=="VWO_goal"){let r=new CustomEvent("tracked",{detail:{eventName:i},bubbles:!0,cancelable:!0,composed:!0});console.log(`dispatched: ${r}`),e.dispatchEvent(r)}}var Me=new URL(window.location.href).pathname==="/studio-store-apps/ecommerce-app-india"||new URL(window.location.href).searchParams.has("dev-multi-step-forms");function oa(){window.VWO=window.VWO||[],window.VWO.push(["activate",!1,[202],!0]),window.VWO.push(["activate",!1,[204],!0])}function ra(){return window.dataLayer=window.dataLayer||[],window.dataLayer}var Ai=new URL(window.location.href).hostname==="www.builder.ai",k=(e,t,a=1e3)=>{let i=ra();t&&(e.eventCallback=t,e.eventTimeout=a),i.push(e),Ai||console.log(e)};function Pe(e,t=1e3){let a=!1,i;return new Promise((r,s)=>{let o=()=>{a&&window.clearTimeout(i),a=!0,r(void 0)};try{i=window.setTimeout(o,t),k(e,o,t)}catch(n){s(n)}})}function na(e){let t=new URLSearchParams;return e.forEach((a,i)=>{typeof a=="string"&&t.append(i,a)}),t}var ne=new URL(window.location.href),M=ne.pathname.startsWith("/events")&&ne.searchParams.has("at-event");ne.pathname==="/at-event"&&window.addEventListener("unload",function(){});var se=ne.pathname.startsWith("/events/upcoming/")?ne.pathname.substring(17):ne.pathname.substring(8);!se&&ne.searchParams.has("event")&&(se=ne.searchParams.get("event"));var Ue=[{email:"rushi.kakarla@builder.ai",SFID:"005C5000000KsXX",event:[]},{email:"brandon.cromer@builder.ai",SFID:"005C5000000IANK",event:[]},{email:"shreyasi.kundale@builder.ai",SFID:"005C5000000KNW9",event:[]},{email:"bhumika.uniyal@builder.ai",SFID:"005C5000000KGQx",event:[]},{email:"jacob.haynes@builder.ai",SFID:"005C5000000Ktz8",event:[]},{email:"jackson.alexander@builder.ai",SFID:"005C5000000KP3d",event:[]},{email:"jacob.majatladi@builder.ai",SFID:"005C5000000Kum5",event:[]},{email:"juhi.saluja@builder.ai",SFID:"005C5000000KrxK",event:[]},{email:"prasun.mukhopadhyay@builder.ai",SFID:"005C5000000Kkyu",event:[]},{email:"manish.karne@builder.ai",SFID:"005C5000000Iybs",event:[]},{email:"aalok.jassal@builder.ai",SFID:"005C5000000IyA3",event:[]},{email:"tapashya.rawat@builder.ai",SFID:"005C5000000KaQT",event:[]},{email:"malika.gusain@builder.ai",SFID:"0055g00000BQVHv",event:[]},{email:"conor.finn@builder.ai",SFID:"005C5000000KHIk",event:[]},{email:"anurag.pandey@builder.ai",SFID:"005C5000000Jo2y",event:[]},{email:"akshay.rathi@builder.ai",SFID:"005C5000000JAlQ",event:[]},{email:"bairavi.manoharan@builder.ai",SFID:"005C5000000Jvlt",event:[]},{email:"shanno.k@builder.ai",SFID:"005C5000000Ilto",event:[]},{email:"akshit.gupta@builder.ai",SFID:"005C5000000Irw5",event:[]},{email:"manav.subramanian@builder.ai",SFID:"005C5000000KmTt",event:[]},{email:"nur.khandakar@builder.ai",SFID:"005C5000000JIff",event:[]},{email:"ian.mousley@builder.ai",SFID:"005C5000000IuCy",event:[]},{email:"tanto.pilando@builder.ai",SFID:"005C5000000J76U",event:[]},{email:"fawad.bhatti@builder.ai",SFID:"005C5000000KKcO",event:[]},{email:"vaibhav.vishnu@builder.ai",SFID:"005C5000000KfVi",event:[]},{email:"keerat.wadkar@builder.ai",SFID:"005C5000000KKcJ",event:[]},{email:"mike.leonard@builder.ai",SFID:"005C5000000JRaj",event:[]},{email:"vineeta.choudhary@builder.ai",SFID:"005C5000000Jvly",event:[]},{email:"burhanuddin.chashmawala@builder.ai",SFID:"005C5000000JP5K",event:[]},{email:"shanya.gupta@builder.ai",SFID:"005C5000000ITo7",event:[]},{email:"atulya.singh@builder.ai",SFID:"0055g00000BRQ1M",event:[]},{email:"jacob.dinsdale@builder.ai",SFID:"005C5000000IVcw",event:[]},{email:"adil.ghaffar@builder.ai",SFID:"005C5000000InFR",event:[]},{email:"dhara.augusty@builder.ai",SFID:"005C5000000JlNh",event:[]},{email:"amr.abdelhamid@builder.ai",SFID:"005C5000000J404",event:[]},{email:"mudit.kumar@builder.ai",SFID:"005C5000000KqNQ",event:[]},{email:"sennett.tennyson@builder.ai",SFID:"005C5000000K4AK",event:[]},{email:"jesse.quainoo@builder.ai",SFID:"005C5000000JZmB",event:[]},{email:"tobi.ajayi@builder.ai",SFID:"005C5000000KwJj",event:[]},{email:"ashish.kohli@builder.ai",SFID:"005C5000000Jd0f",event:[]},{email:"tanya.arlina@builder.ai",SFID:"005C5000000KNij",event:[]},{email:"prakhar.rungta@builder.ai",SFID:"005C5000000JMKb",event:[]},{email:"audrey.thunhorst@builder.ai",SFID:"005C5000000KBc5",event:[]},{email:"jonathan.yuvienco@builder.ai",SFID:"005C5000000Iqsb",event:[]},{email:"data.engineering@builder.ai",SFID:"005C5000000KWvI",event:[]},{email:"jayson.rosales@builder.ai",SFID:"005C5000000K8hl",event:[]},{email:"damian.earl@builder.ai",SFID:"005C5000000JKwO",event:[]},{email:"violet.graham@builder.ai",SFID:"005C5000000KoCB",event:[]},{email:"khadija.fatima@builder.ai",SFID:"005C5000000JNP3",event:[]},{email:"weston.sandberg@builder.ai",SFID:"005C5000000JKw4",event:[]},{email:"shannon.sunwoo@builder.ai",SFID:"005C5000000Iybx",event:[]},{email:"ashwini.bhaskar@builder.ai",SFID:"005C5000000KvfA",event:[]},{email:"richard.nixon@builder.ai",SFID:"005C5000000J3Oo",event:[]},{email:"sachin@builder.ai",SFID:"0055g00000E1aQ5",event:[]},{email:"lovelyn.go@builder.ai",SFID:"0055g00000CnQoC",event:[]},{email:"swati.mishra1@builder.ai",SFID:"005C5000000KumA",event:[]},{email:"sulafa.ghassan@builder.ai",SFID:"005C5000000IbJR",event:[]},{email:"lifin.xavier@builder.ai",SFID:"005C5000000KdBv",event:[]},{email:"shimoli.jhaveri@builder.ai",SFID:"005C5000000KdCA",event:[]},{email:"shivani.sachdeva1@builder.ai",SFID:"005C5000000KtzN",event:[]},{email:"nestor.saa@builder.ai",SFID:"005C5000000InFl",event:[]},{email:"syeed.khan@builder.ai",SFID:"005C5000000KgVy",event:[]},{email:"erwann.collet@builder.ai",SFID:"005C5000000ICeK",event:[]},{email:"pragati.sanjay@builder.ai",SFID:"005C5000000KXsy",event:[]},{email:"seth.lee@builder.ai",SFID:"005C5000000Iblf",event:[]},{email:"rowaida.abdelmaksoud@builder.ai",SFID:"005C5000000KNio",event:[]},{email:"youssef.kamash@builder.ai",SFID:"005C5000000KfVT",event:[]},{email:"pavan.vasantha@builder.ai",SFID:"005C5000000KPOv",event:[]},{email:"ziad.shaheen@builder.ai",SFID:"005C5000000KKcY",event:[]},{email:"emily.purches@builder.ai",SFID:"005C5000000KQq2",event:[]},{email:"diksha.agnihotri@builder.ai",SFID:"005C5000000JRkP",event:[]},{email:"liam.collins1@builder.ai",SFID:"005C5000000IuGl",event:[]},{email:"akshata.sagotia@builder.ai",SFID:"005C5000000KgqS",event:[]},{email:"forida.begum@builder.ai",SFID:"005C5000000InEs",event:[]},{email:"jeet.bhatia@builder.ai",SFID:"005C5000000KdCK",event:[]},{email:"hasan.beg@builder.ai",SFID:"005C5000000IHfI",event:[]},{email:"joshua.dacosta@builder.ai",SFID:"005C5000000Iyc2",event:[]},{email:"mary.viray@x.builder.ai",SFID:"005C5000000IJFC",event:[]},{email:"ramya.karanam@builder.ai",SFID:"005C5000000KaSP",event:[]},{email:"mohammed.hussain@builder.ai",SFID:"005C5000000J2c1",event:[]},{email:"vaanee.vardhan@builder.ai",SFID:"005C5000000KrxP",event:[]},{email:"harry.burns@builder.ai",SFID:"005C5000000K9Ps",event:[]},{email:"maheshwari.v@builder.ai",SFID:"005C5000000KO0J",event:[]},{email:"vaishali.chhabra@builder.ai",SFID:"005C5000000IpFY",event:[]},{email:"prashanth.sridhar@builder.ai",SFID:"0055g00000CkneO",event:[]},{email:"mohammad.kafiat@builder.ai",SFID:"005C5000000K5AO",event:[]},{email:"srimathi.subramanian@builder.ai",SFID:"005C5000000JcgB",event:[]},{email:"neha.yadav1@builder.ai",SFID:"005C5000000IqTM",event:[]},{email:"subhash.jk@builder.ai",SFID:"005C5000000Iz75",event:[]},{email:"adrian.vanrensburg@builder.ai",SFID:"005C5000000IuCo",event:[]},{email:"sonal.goel@builder.ai",SFID:"005C5000000HsKD",event:[]},{email:"minakshi.sharma@builder.ai",SFID:"005C5000000HyrD",event:[]},{email:"will.hutchinson@builder.ai",SFID:"005C5000000KWyM",event:[]},{email:"achin.sharma@builder.ai",SFID:"005C5000000Kpkx",event:[]},{email:"reda.sayed@builder.ai",SFID:"005C5000000IpmD",event:[]},{email:"omar.al-halaika@builder.ai",SFID:"005C5000000IV0d",event:[]},{email:"yashika.bhatia@builder.ai",SFID:"005C5000000Ip59",event:[]},{email:"ahmed.yasser@builder.ai",SFID:"005C5000000KBdS",event:[]},{email:"bitan.barua@builder.ai",SFID:"005C5000000JBme",event:[]},{email:"saurabh.satheesh@builder.ai",SFID:"005C5000000KQwP",event:[]},{email:"amira.chaban@builder.ai",SFID:"005C5000000InFv",event:[]},{email:"ankita.bhardwaj@builder.ai",SFID:"005C5000000KnDw",event:[]},{email:"shadan.zaman@builder.ai",SFID:"005C5000000K57t",event:[]},{email:"leonardo.cammarata@builder.ai",SFID:"005C5000000KD3l",event:[]},{email:"nischay.acharya@builder.ai",SFID:"0055g00000BQVI2",event:[]},{email:"omar.abouhamdan@builder.ai",SFID:"005C5000000IiW3",event:[]},{email:"vansh.bhardwaj@builder.ai",SFID:"005C5000000JGnX",event:[]},{email:"adarsh.raj@builder.ai",SFID:"0055g00000CmZy0",event:[]},{email:"ian.mccollum@builder.ai",SFID:"005C5000000KM81",event:[]},{email:"adhaar.khanna@builder.ai",SFID:"0055g00000BRQ1F",event:[]},{email:"irina.tjahjana@builder.ai",SFID:"005C5000000KfXK",event:[]},{email:"steve.knight@builder.ai",SFID:"0055g00000BQVgi",event:[]},{email:"alex.keoghan@builder.ai",SFID:"005C5000000K57F",event:[]},{email:"aya.mohamed@builder.ai",SFID:"005C5000000KqNV",event:[]},{email:"jean.fideli@builder.ai",SFID:"005C5000000KmrR",event:[]},{email:"sally.darrouj@builder.ai",SFID:"005C5000000KnDm",event:[]},{email:"vishaka.n@builder.ai",SFID:"005C5000000JMfK",event:[]},{email:"cameron.butler@builder.ai",SFID:"005C5000000Igrn",event:[]},{email:"faran.ahmad@builder.ai",SFID:"005C5000000JBho",event:[]},{email:"shivali.kanoongo@builder.ai",SFID:"005C5000000ISBn",event:[]},{email:"smriti.easwaran@builder.ai",SFID:"005C5000000KdBq",event:[]},{email:"rishiraj.dutta@builder.ai",SFID:"005C5000000KrrH",event:[]},{email:"apurva.sooden@builder.ai",SFID:"0055g00000E1XGq",event:[]},{email:"sepehr.ghasemi@builder.ai",SFID:"005C5000000K5An",event:[]},{email:"abhinav.maltesh@builder.ai",SFID:"0055g00000BRQ1E",event:[]},{email:"sean.clark@builder.ai",SFID:"005C5000000K8hv",event:[]},{email:"kavya.krishnappa@builder.ai",SFID:"0055g00000BQVHt",event:[]},{email:"konark.rawat@builder.ai",SFID:"005C5000000IqDY",event:[]},{email:"smita.nagaonkar@builder.ai",SFID:"005C5000000KP4C",event:[]},{email:"simran.jain@builder.ai",SFID:"005C5000000IdH8",event:[]},{email:"rohan.khanna@builder.ai",SFID:"0055g000008mbAL",event:[]},{email:"prasad.kadam@builder.ai",SFID:"005C5000000JGnN",event:[]},{email:"anukriti.srivastava@builder.ai",SFID:"005C5000000Hyr8",event:[]},{email:"braxton.reid@builder.ai",SFID:"005C5000000IVdG",event:[]},{email:"karthik.arun@builder.ai",SFID:"005C5000000JHz5",event:[]},{email:"ritwika.chowdhury@builder.ai",SFID:"005C5000000KZi2",event:[]},{email:"christian.albert@builder.ai",SFID:"005C5000000J2bm",event:[]},{email:"raghav.bhasin@builder.ai",SFID:"005C5000000IyA8",event:[]},{email:"purvi.garg@builder.ai",SFID:"005C5000000IxdT",event:[]},{email:"lianna.ma@builder.ai",SFID:"005C5000000IlPZ",event:[]},{email:"rami.khairallah@builder.ai",SFID:"005C5000000KjVm",event:[]},{email:"rohit.nambiar@builder.ai",SFID:"005C5000000KyYb",event:[]},{email:"pooja.thombre@builder.ai",SFID:"005C5000000KVjV",event:[]},{email:"huda.kaziz@builder.ai",SFID:"005C5000000Hzjj",event:[]},{email:"kayed.matarneh@builder.ai",SFID:"005C5000000KJVv",event:[]},{email:"bryan.summers@builder.ai",SFID:"005C5000000JAlL",event:[]},{email:"sumitg2@damcogroup.com.prod",SFID:"005C5000000KjnH",event:[]},{email:"kartik.arora@builder.ai",SFID:"005C5000000IDZ6",event:[]},{email:"ridhima.wadhwa@builder.ai",SFID:"0055g00000CmF7u",event:[]},{email:"akansha.garg@builder.ai",SFID:"005C5000000JHA7",event:[]},{email:"atreya.basu@builder.ai",SFID:"005C5000000JZ0R",event:[]},{email:"surisetty.sagarika@builder.ai",SFID:"005C5000000IqDi",event:[]},{email:"shikha.kumari@builder.ai",SFID:"005C5000000J9BC",event:[]},{email:"deepika.maheshwari@builder.ai",SFID:"0055g00000BQVHq",event:[]},{email:"chris.mcdonough@builder.ai",SFID:"005C5000000KwJZ",event:[]},{email:"winston.ho@builder.ai",SFID:"005C5000000KVjG",event:[]},{email:"bharath.kumar@builder.ai",SFID:"005C5000000KdBb",event:[]},{email:"anju.chaudhary@engineer.ai",SFID:"0055g00000BRUS4",event:[]},{email:"abhishek.chaturvedi@builder.ai",SFID:"005C5000000KfWM",event:[]},{email:"muskan.kinger@builder.ai",SFID:"0055g00000CmF84",event:[]},{email:"samyukta.agarwal@builder.ai",SFID:"005C5000000Kvlw",event:[]},{email:"baylee.magee@builder.ai",SFID:"005C5000000KGjV",event:[]},{email:"mahesh.kumar@builder.ai",SFID:"005C5000000Ix8p",event:[]},{email:"manish.singh1@builder.ai",SFID:"005C5000000Jd0a",event:[]},{email:"archit.khandelwal@builder.ai",SFID:"005C5000000KSa6",event:[]},{email:"akash.chugh@builder.ai",SFID:"0055g00000BRQ1G",event:[]},{email:"raman.jain@builder.ai",SFID:"005C5000000KP47",event:[]},{email:"gurleen.kaur@builder.ai",SFID:"005C5000000Kola",event:[]},{email:"biplab.das@builder.ai",SFID:"005C5000000InB0",event:[]},{email:"taniya.mandal@builder.ai",SFID:"005C5000000JpcK",event:[]},{email:"mathew.alexander@builder.ai",SFID:"005C5000000HsKN",event:[]},{email:"aagman.mishra@builder.ai",SFID:"005C5000000K5As",event:[]},{email:"varun.chhabra@builder.ai",SFID:"005C5000000KNW4",event:[]},{email:"sahil.saxena@builder.ai",SFID:"005C5000000J6j6",event:[]},{email:"rishi.mozumder@builder.ai",SFID:"005C5000000JIfk",event:[]},{email:"shruti.tiwari@builder.ai",SFID:"005C5000000IZmC",event:[]},{email:"hamad.muneer@builder.ai",SFID:"005C5000000Kmbs",event:[]},{email:"reannie.arevalo@x.builder.ai",SFID:"005C5000000IxA7",event:[]},{email:"freesia.cana@builder.ai",SFID:"005C5000000I43Y",event:[]},{email:"john.olegario@x.builder.ai",SFID:"005C5000000Iksp",event:[]},{email:"ginalene.concha@x.builder.ai",SFID:"005C5000000IhGx",event:[]},{email:"patrick.donnelly@builder.ai",SFID:"005C5000000IkID",event:[]},{email:"loretta.nguyen@builder.ai",SFID:"0055g00000BQVIc",event:[]},{email:"lauren.ogbogu@builder.ai",SFID:"005C5000000JzWA",event:[]},{email:"aaron.whitney@builder.ai",SFID:"0055g00000BQJYj",event:[]},{email:"erik.thomsen@builder.ai",SFID:"005C5000000Hzci",event:[]},{email:"peyton.young@builder.ai",SFID:"005C5000000JeVZ",event:[]},{email:"coby.borceguin@builder.ai",SFID:"005C5000000IaPT",event:[]},{email:"sean.ricucci@builder.ai",SFID:"005C5000000Jo3X",event:[]},{email:"chanel.chance@builder.ai",SFID:"005C5000000Kmc7",event:[]},{email:"derek.gardner@builder.ai",SFID:"005C5000000Iqt5",event:[]},{email:"muhammed.hassan@builder.ai",SFID:"005C5000000KGR2",event:[]},{email:"bireswar.biswas@builder.ai",SFID:"005C5000000Hu8Y",event:[]},{email:"james.langran@builder.ai",SFID:"005C5000000IcAf",event:[]},{email:"adam.angelov@builder.ai",SFID:"005C5000000Ktz3",event:[]},{email:"rakesh.rathod@builder.ai",SFID:"0055g00000Cnex4",event:[]},{email:"laud.kouao@builder.ai",SFID:"005C5000000ImiD",event:[]},{email:"mohammed.sohail@engineer.ai",SFID:"0055g00000BQVI0",event:[]},{email:"abhinandan.baidya@builder.ai",SFID:"005C5000000JYu9",event:[]},{email:"kavitha.amar@builder.ai",SFID:"005C5000000KdBl",event:[]},{email:"priyanka.lall@builder.ai",SFID:"005C5000000KdBg",event:[]},{email:"vagesha.sinha@builder.ai",SFID:"005C5000000IuDX",event:[]},{email:"rajvi.shah@builder.ai",SFID:"005C5000000IeKh",event:[]},{email:"arpita.jain@builder.ai",SFID:"005C5000000KumF",event:[]},{email:"mohak.goad@builder.ai",SFID:"0055g00000BQVHz",event:[]},{email:"vidushi.uniyal@builder.ai",SFID:"005C5000000L02r",event:[]},{email:"jemina.moirangthem@builder.ai",SFID:"005C5000000JG5z",event:[]},{email:"khadija.karachiwala@builder.ai",SFID:"005C5000000KGAf",event:[]},{email:"giannis.mermeklis@builder.ai",SFID:"005C5000000IeKc",event:[]},{email:"ujwal.shah@builder.ai",SFID:"005C5000000L02w",event:[]},{email:"mohammed.shakeel@builder.ai",SFID:"005C5000000IgkS",event:[]},{email:"divya.chawla@builder.ai",SFID:"005C5000000HtY6",event:[]},{email:"lakshya.gaur@builder.ai",SFID:"005C5000000Kkyz",event:[]},{email:"shirley.daniel@builder.ai",SFID:"005C5000000IaAY",event:[]},{email:"aakash.kumar@builder.ai",SFID:"005C5000000JLfi",event:[]},{email:"akarsh.sinha@builder.ai",SFID:"005C5000000KGQs",event:[]},{email:"carly.koch@builder.ai",SFID:"005C5000000KHIp",event:[]},{email:"deeksha.wadhwa@builder.ai",SFID:"005C5000000Ky3E",event:[]},{email:"raunaq.singhania@builder.ai",SFID:"005C5000000KjVr",event:[]},{email:"stevan.scully@builder.ai",SFID:"005C5000000JruP",event:[]},{email:"morris.otchere-forbih@builder.ai",SFID:"005C5000000KHU2",event:[]},{email:"parth.verma@x.builder.ai",SFID:"005C5000000JbK4",event:[]},{email:"varghese.cherian@builder.ai",SFID:"0055g00000CmfqS",event:[]},{email:"omer.babiker@builder.ai",SFID:"005C5000000KnDr",event:[]},{email:"jogesh.soni@builder.ai",SFID:"005C5000000KHiJ",event:[]},{email:"monnika.bisht@builder.ai",SFID:"005C5000000JvJG",event:[]},{email:"pratik.goyal@builder.ai",SFID:"005C5000000Ir0V",event:[]},{email:"ruchika.khaitan@builder.ai",SFID:"005C5000000KtzS",event:[]},{email:"shibani.sahoo@builder.ai",SFID:"005C5000000Ksrw",event:[]},{email:"jack.smillie@builder.ai",SFID:"005C5000000JP63",event:[]},{email:"abhishek.srivastava2@builder.ai",SFID:"005C5000000Koyo",event:[]},{email:"mohan.babu@builder.ai",SFID:"005C5000000KtnW",event:[]},{email:"anirudh.chauhan@builder.ai",SFID:"005C5000000K8hb",event:[]},{email:"bhavika.khanna@builder.ai",SFID:"005C5000000Ik4a",event:[]},{email:"aditi.tomar@builder.ai",SFID:"005C5000000KtzD",event:[]},{email:"vinod.sharma@builder.ai",SFID:"005C5000000KtzI",event:[]},{email:"nikhil.bajaj@builder.ai",SFID:"005C5000000KumK",event:[]},{email:"femi.ashiyanbi@builder.ai",SFID:"005C5000000Irvv",event:[]},{email:"deepak.madhani@builder.ai",SFID:"005C5000000IWg6",event:[]},{email:"shweta.narendernath@builder.ai",SFID:"005C5000000IynZ",event:[]},{email:"mohamed.elsaiad@builder.ai",SFID:"005C5000000IiVy",event:[]},{email:"priyanka.kochhar@builder.ai",SFID:"005C5000000I4wx",event:[]},{email:"ranjit.jayaram@builder.ai",SFID:"005C5000000Kvf0",event:[]},{email:"ayushi.singh@builder.ai",SFID:"005C5000000KEVH",event:[]},{email:"tara.howard@builder.ai",SFID:"005C5000000K9YQ",event:[]},{email:"ritu.khatri@builder.ai",SFID:"005C5000000IyRE",event:[]},{email:"rawan.mohamed@builder.ai",SFID:"005C5000000KbgI",event:[]},{email:"gaurav.gulati@builder.ai",SFID:"0055g000008naVG",event:[]},{email:"siddharth.bhatnagar@builder.ai",SFID:"005C5000000KsXS",event:[]},{email:"ranwa.sarkis@builder.ai",SFID:"005C5000000KbAR",event:[]},{email:"himanshu.singhal@builder.ai",SFID:"005C5000000IJUq",event:[]},{email:"shalabh@builder.ai",SFID:"0055g00000BRUS5",event:[]},{email:"laura.varsandan@builder.ai",SFID:"005C5000000JUEH",event:[]},{email:"apatro@builder.ai",SFID:"005C5000000I95t",event:[]},{email:"nur.istiqamah@builder.ai",SFID:"005C5000000Ii7w",event:[]},{email:"lavajiit.singh@builder.ai",SFID:"005C5000000IrvW",event:[]},{email:"sumit.pachlangiya@builder.ai",SFID:"005C5000000Hv6i",event:[]},{email:"ananth.ramanathan@builder.ai",SFID:"0055g00000BRUS3",event:[]},{email:"david.acheson@builder.ai",SFID:"005C5000000IyRJ",event:[]},{email:"sid@builder.ai",SFID:"005C5000000KSWT",event:[]},{email:"manoshi.lahiri@builder.ai",SFID:"005C5000000JGce",event:[]},{email:"louise.slattery@builder.ai",SFID:"005C5000000KFz3",event:[]},{email:"andrei.nita@builder.ai",SFID:"0055g00000E1WS7",event:[]},{email:"andres.elizondo@builder.ai",SFID:"005C5000000IDxw",event:[]},{email:"nikhil.burad@builder.ai",SFID:"005C5000000KRZg",event:[]},{email:"amit.garg@builder.ai",SFID:"005C5000000J0hT",event:[]},{email:"rohit.pandey@builder.ai_prod",SFID:"005C5000000Js40",event:[]},{email:"beatrice.andrew@builder.ai",SFID:"005C5000000IHxv",event:[]},{email:"swati.rastogi@builder.ai",SFID:"005C5000000Jo3w",event:[]},{email:"marco.giglio@builder.ai",SFID:"005C5000000I4BI",event:[]},{email:"liam@builder.ai",SFID:"0055g00000CjaTh",event:[]},{email:"siyaam.zakriya@builder.ai",SFID:"0055g000008mPTQ",event:[]},{email:"oona.hook@builder.ai",SFID:"005C5000000IrU6",event:[]},{email:"rajiv.saini@builder.ai",SFID:"005C5000000IKln",event:[]},{email:"joe.norena@builder.ai",SFID:"005C5000000IMjo",event:[]},{email:"deliveryandops.datagroup@builder.ai",SFID:"005C5000000IFjh",event:[]},{email:"rohan@builder.ai",SFID:"005C5000000KOvo",event:[]},{email:"jofin.jose@builder.ai",SFID:"005C5000000L036",event:[]},{email:"kayla.mcnutt@builder.ai",SFID:"005C5000000KgVt",event:[]},{email:"surya.bharadwaj@builder.ai",SFID:"005C5000000Kvf5",event:[]},{email:"raunaq.khanna@builder.ai",SFID:"005C5000000L02m",event:[]},{email:"ganesh.apte@builder.ai",SFID:"005C5000000Ky3T",event:[]},{email:"sonali.bhatia@builder.ai",SFID:"005C5000000KvfF",event:[]},{email:"manmohit.singhal@builder.ai",SFID:"005C5000000KqNL",event:[]},{email:"dhruv.lav@builder.ai",SFID:"005C5000000L3wdIAC",event:[]},{email:"aishwarya.jain@builder.ai",SFID:"005C5000000L43ZIAS",event:[]},{email:"peter.sharples@builder.ai",SFID:"005S2000001KZ7WIAW",event:[]},{email:"shrey.gupta@builder.ai",SFID:"005S2000000mEK1IAM",event:[]},{email:"udita.valecha@builder.ai",SFID:"005S2000000Zi3KIAS",event:[]},{email:"siddhant.kharb@builder.ai",SFID:"005S2000001S7z1IAC",event:[]},{email:"amar.bidari@builder.ai",SFID:"005S2000000SLCn",event:[]},{email:"sydney.akgun@builder.ai",SFID:"005C5000000L9gC",event:[]},{email:"abeed.ahmed@builder.ai",SFID:"005S2000000ys2L",event:[]},{email:"lea.lace@builder.ai",SFID:"005S2000000sqfx",event:[]},{email:"ryan.devries@builder.ai",SFID:"005C5000000L9JX",event:[]},{email:"alisha.rahman@builder.ai",SFID:"005S2000002EYna",event:[]},{email:"madhur.ahuja@builder.ai",SFID:"005S20000028hcv",event:[]},{email:"monica.nelson@builder.ai",SFID:"005S2000001QzDlIAK",event:[]},{email:"srimathi.subramanian@builder.ai",SFID:"005C5000000JcgB",event:[]},{email:"shrestha.misra@builder.ai",SFID:"005S2000003LmCn",event:[]},{email:"lovelyn.go@builder.ai",SFID:"0055g00000CnQoC",event:[]},{email:"rob.charles@builder.ai ",SFID:"005S2000001UicX",event:[]},{email:"benedict.lee@builder.ai",SFID:"005S2000003LfQK",event:[]},{email:"henry.neo@builder.ai",SFID:"005S2000002VRQz",event:[]},{email:"jerome.miniano@builder.ai",SFID:"005S2000005JBph",event:[]},{email:"kanaan.stevenson@builder.ai",SFID:"005S2000005vEg5",event:[]},{email:"naman.bhutani@builder.ai",SFID:"0055g00000BQljF",event:[]},{email:"hiba.istanbouli@builder.ai",SFID:"005C5000000JG64",event:[]},{email:"jitendra.alwani@builder.ai",SFID:"005C5000000KWfj",event:[]},{email:"manish.limani@builder.ai",SFID:"005C5000000JlNm",event:[]},{email:"nicolas.boulos@builder.ai",SFID:"005C5000000Ix9O",event:[]},{email:"praful.khabiya@builder.ai",SFID:"005C5000000HuRz",event:[]},{email:"sofia.niaz@builder.ai",SFID:"005C5000000L7MP",event:[]},{email:"pooja.mehta@engineer.ai",SFID:"0055g00000BRQ1U",event:[]},{email:"sharavati.thorat@builder.ai",SFID:"005C5000000L3vuIAC",event:[]},{email:"akhil.pillai@builder.ai",SFID:"005C5000000J5sC",event:[]},{email:"sudeep.victor@builder.ai",SFID:"005C5000000J5yP",event:[]},{email:"tejeswi.sreekantan@builder.ai",SFID:"005S2000000Nlg6",event:[]},{email:"pinky.verma@builder.ai",SFID:"0055g00000E1W1V",event:[]},{email:"sharavati.thorat@builder.ai",SFID:"005C5000000L3vu",event:[]},{email:"kayed.matarneh@builder.ai",SFID:"005C5000000KJVv",event:[]},{email:"theo.parthomsakulrat@builder.ai",SFID:"005S2000005JBxl",event:[]},{email:"amara.konneh@builder.ai",SFID:"005S2000005J9oF",event:[]},{email:"vikas.thakur@builder.ai",SFID:"0055g00000BRQ1a",event:[]},{email:"naveen.chopra@builder.ai",SFID:"005S2000006iz5x",event:[]},{email:"sonal.jha@builder.ai",SFID:"005S2000003Lf4u",event:[]},{email:"emanuele.galli@builder.ai",SFID:"005S2000008fnD4",event:[]},{email:"takrim.panvelkar@builder.ai",SFID:"005S2000004wA9i",event:[]},{email:"john.ogrady@builder.ai",SFID:"005S2000003VcUR",event:[]},{email:"vinay.kumar@builder.ai",SFID:"005S2000002dwEH",event:[]},{email:"sam.sheehy@builder.ai",SFID:"005S2000001QvwY",event:[]},{email:"peyton.parker@builder.ai",SFID:"005S2000005f2r3",event:[]}],je=[];M&&se==="msft-round-table-event-2024---hyderabad"&&(je=[{email:"smriti.easwaran@builder.ai",SFID:"005C5000000KdBq",event:[]},{email:"vikas.thakur@builder.ai",SFID:"0055g00000BRQ1a",event:[]},{email:"anju.chaudhary@engineer.ai",SFID:"0055g00000BRUS4",event:[]},{email:"pooja.mehta@engineer.ai",SFID:"0055g00000BRQ1U",event:[]}]);async function sa(e){let t=e.formData,a=e.target;Ii(t),Ei(t),Ci(t),Di(t),Fi(t),Ti(t),Li(t),Mi(t),Pi(t),Ri(t),$i(t),Bi(t),qi(t),Oi(t),Wi(t),Ni(t);let{setStudioStoreAppType:i,setFormType:r,setFormRef:s,setRedirectURL:o}=Ui(a);if(i(t),r(t),s(t),o(t),Hi(t),!t.get("CompanyName")){let b=t.get("FirstName"),_=t.get("LastName");["/events/dreambuilder25","/events/web-summit-24"].includes(window.location.pathname)||b&&_&&t.set("CompanyName",`${b} ${_}`)}let n=t.get("CountryCode");n&&(n=n.split(" ")[0],t.set("CountryCode",n)),t.has("NewsletterSignup")?t.set("NewsletterSignup","TRUE"):t.set("NewsletterSignup","FALSE"),t.get("FormRef")==="AC28"&&t.set("NewsletterSignup","TRUE");let h=t.get("AtEventBuilderAIRepresentative"),g="",x=new URL(window.location.href);if(!g&&M&&x.pathname==="/events/davos-2023"&&(g="0055g00000E1aQ5AAJ"),h){for(let b of Ue)if(b.email===h){g=b.SFID;break}}if(t.set("AtEventBuilderAIRepresentativeSFID",g),M){let b=t.get("AtEventBuilderAIRepresentative"),_=t.get("EventYouWillBeAttending");!_&&x.searchParams.has("event")&&(x.searchParams.get("event")==="uts-ny-2024"?(_="UTS NY 2024",g||(b="chris.mcdonough@builder.ai",g="005C5000000KwJZ")):x.searchParams.get("event")==="msft-round-table-event-2024---hyderabad"&&(_="MSFT Round Table Event 2024 - Hyderabad"),_&&t.set("EventYouWillBeAttending",_),b&&t.set("AtEventBuilderAIRepresentative",b),g&&t.set("AtEventBuilderAIRepresentativeSFID",g)),window.localStorage&&(b?window.localStorage.setItem("AtEventBuilderAIRepresentative",b):window.localStorage.removeItem("AtEventBuilderAIRepresentative"),_?window.localStorage.setItem("EventYouWillBeAttending",_):window.localStorage.removeItem("EventYouWillBeAttending"))}if(t.has("HowMuchDoYouExpectToSpend")){let b="More than \u20B9400,000 (customised build)";t.get("HowMuchDoYouExpectToSpend")==="I'm looking for free solution"?b="I don\u2019t have any budget":t.get("HowMuchDoYouExpectToSpend")==="Less than $5,000"?b="Less than \u20B9400,000 (templated build)":t.get("HowMuchDoYouExpectToSpend")==="I need guidance from a professional"&&(b="I need guidance from a professional"),t.set("BudgetExperiment",b)}try{let b=document.getElementById("context");if(b){let _=JSON.parse(b.innerText);_&&_.cfCity&&t.set("CityFromIPAddress",_.cfCity)}}catch{}}function G(e,t,a,i){let r=new URLSearchParams(window.location.search),s="";if(a){let o=r.get(a);o&&(s=o)}if(!s&&i){let o=da(i);o&&(s=decodeURI(o))}e.append(t,s)}function Ii(e){G(e,"UTMCampaign","utm_campaign","utmCampaign")}function Ei(e){G(e,"UTMContent","utm_content","utmContent")}function Ci(e){G(e,"UTMMedium","utm_medium","utmMedium")}function Di(e){G(e,"UTMSource","utm_source","utmSource")}function Fi(e){G(e,"UTMTerm","utm_term","utmTerm")}function Ti(e){G(e,"GCLID","gclid","utmGCLID")}function Li(e){G(e,"RedditCID","rdt_cid","rdt_cid")}function Mi(e){G(e,"FacebookClickID","fbclid","_fbc")}function Pi(e){G(e,"FacebookBrowserID",void 0,"_fbp")}function Ri(e){G(e,"GAClientID",void 0,"_ga")}function qi(e){G(e,"LinkedinClickID",void 0,"li_fat_id")}function Oi(e){G(e,"HubspotUserToken",void 0,"hubspotutk")}function $i(e){G(e,"BuilderCookieID",void 0,"builder_cookie_id")}function Bi(e){G(e,"SegmentAnonymousID",void 0,"ajs_anonymous_id")}function Ni(e){e.append("Referrer",decodeURI(da("referrer")))}function Wi(e){let t=new URL(window.location.href),a=t.searchParams.get("from");t.searchParams.delete("from");let i=t;if(a)try{i=new URL(a,t.href)}catch{}e.append("PageURL",i.href),e.append("FormPageURL",t.href),e.append("PageURLPath",i.pathname),e.append("FormPageURLPath",t.pathname)}function Ui(e){function t(a){return function(i){let r=e.getAttribute("data-"+a)??"";i.append(a,r)}}return{setStudioStoreAppType:t("StudioStoreAppType"),setFormType:t("FormType"),setFormRef:t("FormRef"),setRedirectURL:t("RedirectURL")}}function da(e){for(var t=e+"=",a=decodeURIComponent(document.cookie),i=a.split(";"),r=0;r<i.length;r++){for(var s=i[r];s.charAt(0)==" ";)s=s.substring(1);if(s.indexOf(t)==0)return s.substring(t.length,s.length)}return""}function ji(){if(window.statsig){let t=window.statsig,a=t.experiment,i=t.getContext().user.statsigEnvironment.tier;if(a){let r=a.groupName?a.groupName:"BLANK";return console.log(`getVWODataFromLocalStorage: ${a.name}_${r}`),{vwo_campaign_id:i==="production"?a.name:`${a.name}_staging`,vwo_campaign_name:i==="production"?a.name:`${a.name}_staging`,vwo_variation_id:r,vwo_variation_name:r,vwo_test:i==="production"?`${a.name}_${r}`:`${a.name}_staging_${r}`}}else console.log("getVWODataFromLocalStorage: no experiment")}let e=window.localStorage.getItem("VWOLastVariantApplied");if(e)try{let t=JSON.parse(e);for(let a of["vwo_campaign_id","vwo_campaign_name","vwo_variation_id","vwo_variation_name"])if(!t[a])return;return t.vwo_test=t.vwo_campaign_id+"_"+t.vwo_campaign_name+"_"+t.vwo_variation_id+"_"+t.vwo_variation_name,t}catch(t){console.error(t);return}}function Hi(e){let t=ji();if(!t){e.set("VWOCampaignID",""),e.set("VWOCampaignName",""),e.set("VWOVariationID",""),e.set("VWOVariationName",""),e.set("VWOTest","");return}e.set("VWOCampaignID",t.vwo_campaign_id??""),e.set("VWOCampaignName",t.vwo_campaign_name??""),e.set("VWOVariationID",t.vwo_variation_id??""),e.set("VWOVariationName",t.vwo_variation_name??""),e.set("VWOTest",t.vwo_test??"")}var He;function le(e){let t="",a=!1;if(document&&document.body&&document.body.hasAttribute("data-selected-product")&&(t=document.body.getAttribute("data-selected-product"),a=!0),t||e.searchParams.has("product")&&(t=e.searchParams.get("product")),t||e.searchParams.has("dev-product")&&(t=e.searchParams.get("dev-product")),t=t.toLowerCase(),t){let n;if(["pro","spro","studio","studio pro","studiopro","studio-pro","studio_pro","builder studio","builderstudio","builder-studio","builder_studio"].includes(t)?n="StudioPro":["store","sstore","studiostore","studio store","studio-store","studio_store"].includes(t)&&(n="StudioStore"),a&&(He=n),n)return n}if(e.pathname==="/quiz-result"&&e.searchParams.has("type")&&["studioStore","store","sstore"].includes(e.searchParams.get("type").toLowerCase()))return"StudioStore";if((e.pathname.startsWith("/pricing")||e.pathname==="/quiz")&&window.sessionStorage){let n=window.sessionStorage.getItem("product"),c="StudioPro";return n==="StudioStore"&&(c=n),c}if(e.pathname==="/email-book-demo"||e.pathname==="/chat-book-demo"){let n="StudioStore";return e.searchParams.has("product")&&e.searchParams.get("product")==="StudioPro"&&(n="StudioPro"),n}let i="StudioPro";for(let n of["/studio-store-vs","/studio-store-apps","/studio-store-stores","/studio-store-features","/ecommerce/","/studio-store/","/sell/"])e.pathname.startsWith(n)&&(i="StudioStore");let r=["/compare/woocommerce","/compare/wix","/compare/shopify","/compare/marketplaces"],s=["/case-studies/eat-denbys","/case-studies/bandi-bytz","/case-studies/bentley","/case-studies/ekobon","/case-studies/kitchenfirst","/case-studies/safariart"];for(let n of[...r,...s,"/brex-employees","/brex-cardholders","/studio-store-product/free-ecommerce-app-website","/studio-store-product/ecommerce-app-website","/studio-store-product/award-winning-ecommerce","/studio-store-product/one-stop-ecommerce-shop","/studio-store-product/builder-x-microsoft","/studio-store-product/builder-x-enterprise-nation","/studio-store-product/explainer-video","/studio-store-product/talk-to-us","/studio-store-product/restaurant-app-india","/studio-store-product/store-field-marketing","/products/studio-store","/formsb/studio-store","/formsb/studio-store-1","/formsb/download-guide-studio-store","/how-to-sell-online","/vsmarketplace","/studio-store/free-ecommerce-app","/events/enterprise-nation-2023","/studio-store-product/partnership-with-idfc","/studio-store-product/partnership-with-idfc/restaurant","/christmas-in-july","/ecommerce","/restaurant-app/restaurant-app","/restaurant-app/medical-app","/blog/online-selling-platforms","/blog/dropshipping-vs-ecommerce","/blog/app-ideas","/blog/ecommerce-competitive-analysis","/blog/build-an-ecommerce-app-from-scratch","/blog/passive-income-ideas","/blog/build-restaurant-reservation-app","/blog/website-builders-for-beginners","/blog/top-10-small-business-ideas","/blog/developing-restaurant-reservation-system","/blog/motivational-quotes","/blog/app-development-tips-for-entrepreneurs","/blog/digital-menu-for-restaurants","/blog/studio-store-the-latest-evolution","/blog/develop-restaurant-app-without-coding","/blog/build-online-ordering-system-for-restaurants","/blog/virtual-queuing-system","/blog/create-marketplace-app-for-restaurants","/blog/ecommerce-automation","/blog/retail-app-features","/blog/build-an-app-like-deliveroo","/blog/create-mobile-app-for-restaurant-ordering","/blog/build-restaurant-reservation-app-like-just-eat","/blog/shopify-alternatives","/blog/online-app-maker-is-worth-the-investment","/get-started/studio-store","/sell"])e.pathname===n&&(i="StudioStore");let o=e.searchParams.get("utm_campaign");return o&&o.toLowerCase().indexOf("SSTORE".toLowerCase())>-1&&(i="StudioStore"),o&&o.toLowerCase().indexOf("SPRO".toLowerCase())>-1&&(i="StudioPro"),i}var mt=[{phone:"+93",region:"APAC",subregion:"ROW - APAC",code:"AF"},{phone:"+355",region:"EMEA",subregion:"Europe",code:"AL"},{phone:"+213",region:"EMEA",subregion:"MENA",code:"DZ"},{phone:"+376",region:"EMEA",subregion:"Europe",code:"AD"},{phone:"+244",region:"EMEA",subregion:"ROW - EMEA",code:"AO"},{phone:"+54",region:"Americas",subregion:"SA",code:"AR"},{phone:"+374",region:"EMEA",subregion:"Europe",code:"AM"},{phone:"+61",region:"APAC",subregion:"ROW - APAC",code:"AU"},{phone:"+43",region:"EMEA",subregion:"Europe",code:"AT"},{phone:"+994",region:"EMEA",subregion:"ROW - EMEA",code:"AZ"},{phone:"+973",region:"EMEA",subregion:"MENA",code:"BH"},{phone:"+880",region:"APAC",subregion:"ROW - APAC",code:"BD"},{phone:"+375",region:"EMEA",subregion:"Europe",code:"BY"},{phone:"+32",region:"EMEA",subregion:"Europe",code:"BE"},{phone:"+501",region:"Americas",subregion:"SA",code:"BZ"},{phone:"+229",region:"EMEA",subregion:"ROW - EMEA",code:"BJ"},{phone:"+975",region:"APAC",subregion:"ROW - APAC",code:"BT"},{phone:"+591",region:"Americas",subregion:"SA",code:"BO"},{phone:"+387",region:"EMEA",subregion:"Europe",code:"BA"},{phone:"+267",region:"EMEA",subregion:"ROW - EMEA",code:"BW"},{phone:"+55",region:"Americas",subregion:"SA",code:"BR"},{phone:"+673",region:"APAC",subregion:"ROW - APAC",code:"BN"},{phone:"+359",region:"EMEA",subregion:"Europe",code:"BG"},{phone:"+226",region:"EMEA",subregion:"ROW - EMEA",code:"BF"},{phone:"+257",region:"EMEA",subregion:"ROW - EMEA",code:"BI"},{phone:"+238",region:"EMEA",subregion:"ROW - EMEA",code:"CV"},{phone:"+855",region:"APAC",subregion:"ROW - APAC",code:"KH"},{phone:"+237",region:"EMEA",subregion:"ROW - EMEA",code:"CM"},{phone:"+236",region:"EMEA",subregion:"ROW - EMEA",code:"CF"},{phone:"+235",region:"EMEA",subregion:"ROW - EMEA",code:"TD"},{phone:"+56",region:"Americas",subregion:"SA",code:"CL"},{phone:"+86",region:"APAC",subregion:"ROW - APAC",code:"CN"},{phone:"+57",region:"Americas",subregion:"SA",code:"CO"},{phone:"+269",region:"EMEA",subregion:"ROW - EMEA",code:"KM"},{phone:"+243",region:"EMEA",subregion:"ROW - EMEA",code:"CD"},{phone:"+242",region:"EMEA",subregion:"ROW - EMEA",code:"CG"},{phone:"+506",region:"Americas",subregion:"SA",code:"CR"},{phone:"+225",region:"EMEA",subregion:"ROW - EMEA",code:"CI"},{phone:"+385",region:"EMEA",subregion:"Europe",code:"HR"},{phone:"+53",region:"Americas",subregion:"SA",code:"CU"},{phone:"+357",region:"EMEA",subregion:"Europe",code:"CY"},{phone:"+420",region:"EMEA",subregion:"Europe",code:"CZ"},{phone:"+45",region:"EMEA",subregion:"Europe",code:"DK"},{phone:"+253",region:"EMEA",subregion:"ROW - EMEA",code:"DJ"},{phone:"+593",region:"Americas",subregion:"SA",code:"EC"},{phone:"+20",region:"EMEA",subregion:"MENA",code:"EG"},{phone:"+503",region:"Americas",subregion:"SA",code:"SV"},{phone:"+240",region:"EMEA",subregion:"ROW - EMEA",code:"GQ"},{phone:"+291",region:"EMEA",subregion:"ROW - EMEA",code:"ER"},{phone:"+372",region:"EMEA",subregion:"Europe",code:"EE"},{phone:"+268",region:"EMEA",subregion:"ROW - EMEA",code:"SZ"},{phone:"+251",region:"EMEA",subregion:"ROW - EMEA",code:"ET"},{phone:"+679",region:"APAC",subregion:"ROW - APAC",code:"FJ"},{phone:"+358",region:"EMEA",subregion:"Europe",code:"FI"},{phone:"+33",region:"EMEA",subregion:"Europe",code:"FR"},{phone:"+241",region:"EMEA",subregion:"ROW - EMEA",code:"GA"},{phone:"+220",region:"EMEA",subregion:"ROW - EMEA",code:"GM"},{phone:"+995",region:"EMEA",subregion:"ROW - EMEA",code:"GE"},{phone:"+49",region:"EMEA",subregion:"Europe",code:"DE"},{phone:"+233",region:"EMEA",subregion:"ROW - EMEA",code:"GH"},{phone:"+30",region:"EMEA",subregion:"Europe",code:"GR"},{phone:"+502",region:"Americas",subregion:"SA",code:"GT"},{phone:"+224",region:"EMEA",subregion:"ROW - EMEA",code:"GN"},{phone:"+245",region:"EMEA",subregion:"ROW - EMEA",code:"GW"},{phone:"+592",region:"Americas",subregion:"SA",code:"GY"},{phone:"+509",region:"Americas",subregion:"SA",code:"HT"},{phone:"+504",region:"Americas",subregion:"SA",code:"HN"},{phone:"+36",region:"EMEA",subregion:"Europe",code:"HU"},{phone:"+354",region:"EMEA",subregion:"Europe",code:"IS"},{phone:"+91",region:"APAC",subregion:"India",code:"IN"},{phone:"+62",region:"APAC",subregion:"ASEAN",code:"ID"},{phone:"+98",region:"EMEA",subregion:"MENA",code:"IR"},{phone:"+964",region:"EMEA",subregion:"MENA",code:"IQ"},{phone:"+353",region:"EMEA",subregion:"Europe",code:"IE"},{phone:"+972",region:"EMEA",subregion:"MENA",code:"IL"},{phone:"+39",region:"EMEA",subregion:"Europe",code:"IT"},{phone:"+81",region:"APAC",subregion:"ROW - APAC",code:"JP"},{phone:"+962",region:"EMEA",subregion:"MENA",code:"JO"},{phone:"+7",region:"EMEA",subregion:"ROW - EMEA",code:"KZ"},{phone:"+254",region:"EMEA",subregion:"ROW - EMEA",code:"KE"},{phone:"+686",region:"APAC",subregion:"ROW - APAC",code:"KI"},{phone:"+965",region:"EMEA",subregion:"MENA",code:"KW"},{phone:"+996",region:"EMEA",subregion:"ROW - EMEA",code:"KG"},{phone:"+371",region:"EMEA",subregion:"Europe",code:"LV"},{phone:"+961",region:"EMEA",subregion:"MENA",code:"LB"},{phone:"+266",region:"EMEA",subregion:"ROW - EMEA",code:"LS"},{phone:"+231",region:"EMEA",subregion:"ROW - EMEA",code:"LR"},{phone:"+218",region:"EMEA",subregion:"MENA",code:"LY"},{phone:"+423",region:"EMEA",subregion:"Europe",code:"LI"},{phone:"+370",region:"EMEA",subregion:"Europe",code:"LT"},{phone:"+352",region:"EMEA",subregion:"Europe",code:"LU"},{phone:"+261",region:"EMEA",subregion:"ROW - EMEA",code:"MG"},{phone:"+265",region:"EMEA",subregion:"ROW - EMEA",code:"MW"},{phone:"+60",region:"APAC",subregion:"ASEAN",code:"MY"},{phone:"+960",region:"APAC",subregion:"ROW - APAC",code:"MV"},{phone:"+223",region:"EMEA",subregion:"ROW - EMEA",code:"ML"},{phone:"+356",region:"EMEA",subregion:"Europe",code:"MT"},{phone:"+692",region:"APAC",subregion:"ROW - APAC",code:"MH"},{phone:"+222",region:"EMEA",subregion:"ROW - EMEA",code:"MR"},{phone:"+230",region:"EMEA",subregion:"ROW - EMEA",code:"MU"},{phone:"+52",region:"Americas",subregion:"SA",code:"MX"},{phone:"+691",region:"APAC",subregion:"ROW - APAC",code:"FM"},{phone:"+373",region:"EMEA",subregion:"Europe",code:"MD"},{phone:"+377",region:"EMEA",subregion:"Europe",code:"MC"},{phone:"+976",region:"APAC",subregion:"ROW - APAC",code:"MN"},{phone:"+382",region:"EMEA",subregion:"Europe",code:"ME"},{phone:"+212",region:"EMEA",subregion:"MENA",code:"MA"},{phone:"+258",region:"EMEA",subregion:"ROW - EMEA",code:"MZ"},{phone:"+95",region:"APAC",subregion:"ROW - APAC",code:"MM"},{phone:"+264",region:"EMEA",subregion:"ROW - EMEA",code:"NA"},{phone:"+674",region:"APAC",subregion:"ROW - APAC",code:"NR"},{phone:"+977",region:"APAC",subregion:"ROW - APAC",code:"NP"},{phone:"+31",region:"EMEA",subregion:"Europe",code:"NL"},{phone:"+64",region:"APAC",subregion:"ROW - APAC",code:"NZ"},{phone:"+505",region:"Americas",subregion:"SA",code:"NI"},{phone:"+227",region:"EMEA",subregion:"ROW - EMEA",code:"NE"},{phone:"+234",region:"EMEA",subregion:"ROW - EMEA",code:"NG"},{phone:"+389",region:"EMEA",subregion:"Europe",code:"MK"},{phone:"+47",region:"EMEA",subregion:"Europe",code:"NO"},{phone:"+968",region:"EMEA",subregion:"MENA",code:"OM"},{phone:"+92",region:"APAC",subregion:"ROW - APAC",code:"PK"},{phone:"+680",region:"APAC",subregion:"ROW - APAC",code:"PW"},{phone:"+970",region:"EMEA",subregion:"MENA",code:"PS"},{phone:"+507",region:"Americas",subregion:"SA",code:"PA"},{phone:"+675",region:"APAC",subregion:"ROW - APAC",code:"PG"},{phone:"+595",region:"Americas",subregion:"SA",code:"PY"},{phone:"+51",region:"Americas",subregion:"SA",code:"PE"},{phone:"+63",region:"APAC",subregion:"ASEAN",code:"PH"},{phone:"+48",region:"EMEA",subregion:"Europe",code:"PL"},{phone:"+351",region:"EMEA",subregion:"Europe",code:"PT"},{phone:"+974",region:"EMEA",subregion:"MENA",code:"QA"},{phone:"+40",region:"EMEA",subregion:"Europe",code:"RO"},{phone:"+7",region:"EMEA",subregion:"ROW - EMEA",code:"RU"},{phone:"+250",region:"EMEA",subregion:"ROW - EMEA",code:"RW"},{phone:"+685",region:"APAC",subregion:"ROW - APAC",code:"WS"},{phone:"+378",region:"EMEA",subregion:"Europe",code:"SM"},{phone:"+239",region:"EMEA",subregion:"ROW - EMEA",code:"ST"},{phone:"+966",region:"EMEA",subregion:"MENA",code:"SA"},{phone:"+221",region:"EMEA",subregion:"ROW - EMEA",code:"SN"},{phone:"+381",region:"EMEA",subregion:"Europe",code:"RS"},{phone:"+248",region:"EMEA",subregion:"ROW - EMEA",code:"SC"},{phone:"+232",region:"EMEA",subregion:"ROW - EMEA",code:"SL"},{phone:"+65",region:"APAC",subregion:"ASEAN",code:"SG"},{phone:"+421",region:"EMEA",subregion:"Europe",code:"SK"},{phone:"+386",region:"EMEA",subregion:"Europe",code:"SI"},{phone:"+677",region:"APAC",subregion:"ROW - APAC",code:"SB"},{phone:"+252",region:"EMEA",subregion:"ROW - EMEA",code:"SO"},{phone:"+27",region:"EMEA",subregion:"ROW - EMEA",code:"ZA"},{phone:"+82",region:"APAC",subregion:"ROW - APAC",code:"KR"},{phone:"+211",region:"EMEA",subregion:"MENA",code:"SD"},{phone:"+34",region:"EMEA",subregion:"Europe",code:"ES"},{phone:"+94",region:"APAC",subregion:"ROW - APAC",code:"LK"},{phone:"+249",region:"EMEA",subregion:"ROW - EMEA",code:"SD"},{phone:"+597",region:"Americas",subregion:"SA",code:"SR"},{phone:"+46",region:"EMEA",subregion:"Europe",code:"SE"},{phone:"+41",region:"EMEA",subregion:"Europe",code:"CH"},{phone:"+886",region:"APAC",subregion:"ROW - APAC",code:"TW"},{phone:"+992",region:"EMEA",subregion:"ROW - EMEA",code:"TJ"},{phone:"+255",region:"EMEA",subregion:"ROW - EMEA",code:"TZ"},{phone:"+66",region:"APAC",subregion:"ASEAN",code:"TH"},{phone:"+856",region:"APAC",subregion:"ROW - APAC",code:"LA"},{phone:"+670",region:"EMEA",subregion:"ROW - EMEA",code:"TP"},{phone:"+228",region:"EMEA",subregion:"ROW - EMEA",code:"TG"},{phone:"+676",region:"APAC",subregion:"ROW - APAC",code:"TO"},{phone:"+216",region:"EMEA",subregion:"MENA",code:"TN"},{phone:"+90",region:"EMEA",subregion:"ROW - EMEA",code:"TR"},{phone:"+993",region:"EMEA",subregion:"ROW - EMEA",code:"TM"},{phone:"+688",region:"APAC",subregion:"ROW - APAC",code:"TV"},{phone:"+256",region:"EMEA",subregion:"ROW - EMEA",code:"UG"},{phone:"+380",region:"EMEA",subregion:"Europe",code:"UA"},{phone:"+971",region:"EMEA",subregion:"MENA",code:"AE"},{phone:"+44",region:"EMEA",subregion:"Europe",code:"GB"},{phone:"+1",region:"Americas",subregion:"USA",code:"US"},{phone:"+598",region:"Americas",subregion:"SA",code:"UY"},{phone:"+998",region:"EMEA",subregion:"ROW - EMEA",code:"UZ"},{phone:"+678",region:"APAC",subregion:"ROW - APAC",code:"VU"},{phone:"+58",region:"Americas",subregion:"SA",code:"VE"},{phone:"+84",region:"APAC",subregion:"ASEAN",code:"VN"},{phone:"+967",region:"EMEA",subregion:"MENA",code:"YE"},{phone:"+260",region:"EMEA",subregion:"ROW - EMEA",code:"ZM"},{phone:"+263",region:"EMEA",subregion:"ROW - EMEA",code:"ZW"}];function la(e){if(!e)return null;for(let t of mt)if(e===t.phone)return t;return null}function Re(e){if(!e)return null;for(let t of mt)if(e===t.code)return t;return null}function ua(){for(let e of mt)if(e.code==="IN")return e;throw Error("Unexpected: default IN country code not found")}function ze(e,t){let a=zi(e,t);(!a||a==="https://calendly.com/")&&(a="https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone",t==="StudioPro"&&(a="https://calendly.com/studio-pro-asia/demo"));let i="Book a free 30 minute demo call";t==="StudioPro"&&(i="Book your call with a Builder.ai expert"),a==="https://calendly.com/d/dpz-ydx-43m/builder-ai-intro-call"&&(i="Schedule your call");let r=new URL(window.location.href);return r.pathname==="/email-book-demo"&&r.searchParams.get("utm_campaign")==="bark_calendly_link_india"&&a==="https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone"&&(a="https://calendly.com/india-store/builder-ai-demo-call-studio-store-bark"),r.pathname==="/studio-store-product/partnership-with-idfc"&&a==="https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone"&&(a="https://calendly.com/india-store/builder-ai-demo-call-studio-store-idfc"),r.searchParams.has("dev-log-calendly-url")&&console.log(`Embedded Calendly URL is: ${a} with title: "${i}"`),{calendlyURL:a,calendlyTitle:i}}function zi(e,t){if(e.region==="EMEA")if(e.subregion==="Europe"){if(t==="StudioStore")return"https://calendly.com/europe-store/demo";if(t==="StudioPro")return"https://calendly.com/builder-ai-studio-pro-europe/builder-ai-intro-call";de(t)}else{if(e.subregion==="MENA"||e.subregion==="ROW - EMEA")return"https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone";de(e)}else if(e.region==="Americas"){if(t==="StudioStore")return"https://calendly.com/christian-albert/30min";if(t==="StudioPro")return"https://calendly.com/builder-ai-studio-pro-usa/builder-ai-zoom-demo-call";de(t)}else if(e.region==="APAC")if(e.subregion==="ASEAN"){if(t==="StudioStore")return"https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone";if(t==="StudioPro")return"https://calendly.com/studio-pro-asia/demo";de(t)}else if(e.subregion==="India"||e.subregion==="ROW - APAC"){if(t==="StudioStore")return"https://calendly.com/india-store/builder-ai-demo-call-studio-store-clone";if(t==="StudioPro")return"https://calendly.com/studio-pro-asia/demo";de(t)}else de(e);else de(e);de("Unreachable")}function de(e,t="Reached unexpected case in exhaustive switch"){throw new Error(t)}var bt=class{constructor(t=""){this.token=t}async submit(t){let{portalId:a,formGuid:i}=t,r=this.token===""?`https://api.hsforms.com/submissions/v3/integration/submit/${a}/${i}`:`https://api.hsforms.com/submissions/v3/secure/integration/secure/submit/${a}/${i}`;r=new URL(`/api/forms/v1?portalId=${a}&formGuid=${i}`,window.location.href).href,console.log(r);let s={body:JSON.stringify(t),method:"POST",credentials:"same-origin",headers:this.token?new Headers({"Content-Type":"application/json",Authorization:`Bearer ${this.token}`}):new Headers({"Content-Type":"application/json"})},o=await fetch(r,s);if(o.ok){console.log("hubspot form submit: ok");try{let c=await o.json();return console.log(c),c}catch{return}}console.log("hubspot form submit: not ok");let n=await o.text();throw console.error(n),new Error(`${o.status} ${o.statusText} ${n}`)}};function Gi(e){let t="hubspotutk=";for(let a of e.split("; "))if(a.startsWith(t))return a.substring(t.length)}async function Ge(e){let t=new URL(window.location.href);t.pathname==="/events/qic-appathon"?(e.set("EventYouWillBeAttending","MENA Insurtech Summit 2024"),e.get("CompanyName")||e.set("CompanyName",">")):["/events/dreambuilder25","/events/web-summit-24"].includes(t.pathname)&&(e.get("CompanyName")||e.set("CompanyName",">"));let a=[],i=e.get("NewsletterSignup");i==="TRUE"||i==="on"?e.set("NewsletterSignup","Yes"):e.set("NewsletterSignup","No");let r=e.get("AISummitCheckbox");r&&(r==="TRUE"||r==="on"?e.set("AISummitCheckbox","Yes"):e.set("AISummitCheckbox","No"),a.push({objectTypeId:"0-1",name:"aisummitcheckbox",value:e.get("AISummitCheckbox")??""})),a.push({objectTypeId:"0-1",name:"firstname",value:e.get("FirstName")??""}),a.push({objectTypeId:"0-1",name:"lastname",value:e.get("LastName")??""}),a.push({objectTypeId:"0-1",name:"email",value:e.get("Email")??""}),a.push({objectTypeId:"0-1",name:"country_code__c",value:e.get("CountryCode")??ca()??""}),a.push({objectTypeId:"0-1",name:"phone_number__c",value:e.get("Phone")??""}),a.push({objectTypeId:"0-1",name:"company",value:e.get("CompanyName")??""}),a.push({objectTypeId:"0-1",name:"newsletter_sign_up__c",value:e.get("NewsletterSignup")??""}),a.push({objectTypeId:"0-1",name:"product_type__c",value:e.get("ProductType")??""}),a.push({objectTypeId:"0-1",name:"lead_form_product_type",value:e.get("LeadFormProductType")??""}),a.push({objectTypeId:"0-1",name:"lead_form_previous_step",value:e.get("LeadFormPreviousStep")??""}),a.push({objectTypeId:"0-1",name:"lead_form_current_step",value:e.get("LeadFormCurrentStep")??""}),a.push({objectTypeId:"0-1",name:"lead_form_next_step",value:e.get("LeadFormNextStep")??""}),a.push({objectTypeId:"0-1",name:"lead_form_user_product_choice",value:e.get("LeadFormUserProductChoice")??""}),a.push({objectTypeId:"0-1",name:"lead_form_debug_log",value:e.get("LeadFormDebugLog")??""}),a.push({objectTypeId:"0-1",name:"company_size__c",value:e.get("CompanySize")??""}),a.push({objectTypeId:"0-1",name:"student_checkbox__c",value:e.get("StudentCheckbox")??""}),a.push({objectTypeId:"0-1",name:"what_best_describes_you__c",value:e.get("WhatBestDescribesYou")??""}),a.push({objectTypeId:"0-1",name:"stage_of_idea__c",value:e.get("StageOfIdea")??""}),a.push({objectTypeId:"0-1",name:"what_s_your_product_idea__c",value:e.get("ProductIdea")??""}),a.push({objectTypeId:"0-1",name:"what_budget_do_you_have__c",value:e.get("Budget")??""}),a.push({objectTypeId:"0-1",name:"country_name__c",value:e.get("Country")??""}),a.push({objectTypeId:"0-1",name:"city__c",value:e.get("City")??""}),a.push({objectTypeId:"0-1",name:"city_from_ip_address__c",value:e.get("CityFromIPAddress")??""}),a.push({objectTypeId:"0-1",name:"funding",value:e.get("Funding")??""}),a.push({objectTypeId:"0-1",name:"stage_of_business",value:e.get("StageOfBusiness")??""}),a.push({objectTypeId:"0-1",name:"app_category__c",value:e.get("AppCategory")??""}),a.push({objectTypeId:"0-1",name:"industry_lead_form__c",value:e.get("IndustryExperiment")??""}),a.push({objectTypeId:"0-1",name:"other_app_category__c",value:e.get("OtherAppCategory")??""}),a.push({objectTypeId:"0-1",name:"budget_experiment__c",value:e.get("BudgetExperiment")??""}),a.push({objectTypeId:"0-1",name:"annual_revenue__c",value:e.get("AnnualRevenue")??""});let s=e.get("HowMuchDoYouExpectToSpend")??"";s&&s.replace("\u2019","'"),a.push({objectTypeId:"0-1",name:"how_much_do_you_expect_to_spend__c",value:s}),a.push({objectTypeId:"0-1",name:"timeline_experiment__c",value:e.get("TimelineExperiment")??""}),a.push({objectTypeId:"0-1",name:"quiz_recommended_product",value:e.get("QuizRecommendedProduct")??""}),a.push({objectTypeId:"0-1",name:"quiz_business_need",value:e.get("QuizBusinessNeed")??""}),a.push({objectTypeId:"0-1",name:"quiz_tech_comfort_level",value:e.get("QuizTechComfortLevel")??""}),a.push({objectTypeId:"0-1",name:"quiz_involvement_preference",value:e.get("QuizInvolvementPreference")??""}),a.push({objectTypeId:"0-1",name:"quiz_expected_budget",value:e.get("QuizExpectedBudget")??""}),a.push({objectTypeId:"0-1",name:"referral_code__c",value:e.get("ReferralCode")??""}),a.push({objectTypeId:"0-1",name:"experian_phone_confidence_level",value:e.get("ExperianPhoneConfidenceLevel")??""}),a.push({objectTypeId:"0-1",name:"experian_phone_type",value:e.get("ExperianPhoneType")??""}),a.push({objectTypeId:"0-1",name:"experian_email_confidence_level",value:e.get("ExperianEmailConfidenceLevel")??""}),a.push({objectTypeId:"0-1",name:"experian_email_confidence_level_verbose",value:e.get("ExperianEmailConfidenceLevelVerbose")??""}),a.push({objectTypeId:"0-1",name:"page_url__c",value:e.get("PageURL")??""}),a.push({objectTypeId:"0-1",name:"form_page_url__c",value:e.get("FormPageURL")??""}),a.push({objectTypeId:"0-1",name:"studio_store_app_type__c",value:e.get("StudioStoreAppType")??""}),a.push({objectTypeId:"0-1",name:"referrer__c",value:e.get("Referrer")??""}),a.push({objectTypeId:"0-1",name:"experiment__c",value:e.get("Experiment")??""}),a.push({objectTypeId:"0-1",name:"vwocampaignid__c",value:e.get("VWOCampaignID")??""}),a.push({objectTypeId:"0-1",name:"vwocampaignname__c",value:e.get("VWOCampaignName")??""}),a.push({objectTypeId:"0-1",name:"vwovariationid__c",value:e.get("VWOVariationID")??""}),a.push({objectTypeId:"0-1",name:"vwovariationname__c",value:e.get("VWOVariationName")??""}),a.push({objectTypeId:"0-1",name:"vwotest__c",value:e.get("VWOTest")??""}),a.push({objectTypeId:"0-1",name:"abstract_email_deliverability__c",value:e.get("AbstractEmailDeliverability")??""}),a.push({objectTypeId:"0-1",name:"abstract_email_is_disposable_email__c",value:e.get("AbstractEmailIsDisposableEmail")??""}),a.push({objectTypeId:"0-1",name:"abstract_email_quality_score__c",value:e.get("AbstractEmailQualityScore")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_city__c",value:e.get("AbstractLocationCity")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_continent__c",value:e.get("AbstractLocationContinent")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_country_code__c",value:e.get("AbstractLocationCountryCode")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_is_vpn__c",value:e.get("AbstractLocationSecurityIsVPN")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_postal_code__c",value:e.get("AbstractLocationRegionPostalCode")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_region__c",value:e.get("AbstractLocationRegion")??""}),a.push({objectTypeId:"0-1",name:"abstract_location_time_zone__c",value:e.get("AbstractLocationTimezoneName")??""}),a.push({objectTypeId:"0-1",name:"abstract_phone_country_prefix__c",value:e.get("AbstractPhoneCountryPrefix")??""}),a.push({objectTypeId:"0-1",name:"abstract_phone_is_valid__c",value:e.get("AbstractPhoneIsValidNumber")??""}),a.push({objectTypeId:"0-1",name:"abstract_phone_registered_location__c",value:e.get("AbstractPhoneRegisteredLocation")??""}),a.push({objectTypeId:"0-1",name:"abstractphonecountry__c",value:e.get("AbstractPhoneCountryName")??""}),a.push({objectTypeId:"0-1",name:"notes__c",value:e.get("Notes")??""}),a.push({objectTypeId:"0-1",name:"what_brought_you_to_the_stand__c",value:e.get("WhatBroughtYouToTheStand")??""});let o=e.get("AboutToReceiveADemoAtEvent");if(o&&o==="Yes"){a.push({objectTypeId:"0-1",name:"leadstatus",value:"Demo"});let w=`${Number(new Date().setUTCHours(0,0,0,0))}`;a.push({objectTypeId:"0-1",name:"demo_scheduled_date__c",value:w}),a.push({objectTypeId:"0-1",name:"demo_schedule_date_time__c",value:w})}a.push({objectTypeId:"0-1",name:"where_did_you_hear_about_us_",value:e.get("WhereDidYouHearAboutUs")??""});let n="",c=e.get("EventYouWillBeAttending");if(console.log({EventYouWillBeAttending:c}),t.pathname==="/events/qic-appathon"){let w=e.get("PromotionalTermsAcceptance")??"No",D=e.get("FormType")??"";D=`${D}${w}`,a.push({objectTypeId:"0-1",name:"form_type__c",value:D}),n="Trade Show",a.push({objectTypeId:"0-1",name:"conference_name__c",value:"MENA Insurtech Summit 2024"})}else if(t.pathname==="/events/dreambuilder25")n="Trade Show",a.push({objectTypeId:"0-1",name:"conference_name__c",value:"Startup Grind Global Conference 2025"});else if(t.pathname==="/events/web-summit-24")n="Trade Show",a.push({objectTypeId:"0-1",name:"conference_name__c",value:"Web Summit Lisbon 2024"}),a.push({objectTypeId:"0-1",name:"form_type__c",value:"web-summit-24-preregistration"});else if(c){n="Trade Show",c.trim()==="GITEX GLOBAL 2023 (Etisalat Stand)"&&(c="GITEX GLOBAL 2023",n="Etisalat",e.set("AtEventBuilderAIRepresentativeSFID","0055g00000BQVI2")),e.delete("UTMCampaign"),e.delete("UTMContent"),e.delete("UTMMedium"),e.delete("UTMSource"),e.delete("UTMTerm"),e.delete("GCLID"),e.delete("RedditCID"),e.delete("FacebookClickID"),e.delete("FacebookBrowserID"),e.delete("GAClientID"),e.delete("BuilderCookieID"),e.delete("BuilderSessionID"),e.delete("SegmentAnonymousID"),e.delete("LinkedinClickID"),e.delete("HubspotUserToken"),a.push({objectTypeId:"0-1",name:"conference_name__c",value:c});let w=c.trim().toLowerCase().replace(/ +/g,"-");a.push({objectTypeId:"0-1",name:"form_type__c",value:w})}else{let w=e.get("FormType")??"";a.push({objectTypeId:"0-1",name:"form_type__c",value:w})}(e.get("FormType")==="book-demo-thailand"||e.get("FormType")==="book_demo_thailand")&&e.set("AtEventBuilderAIRepresentativeSFID","005C5000000KP4C"),a.push({objectTypeId:"0-1",name:"ateventbuilderairepresentativesfid__c",value:e.get("AtEventBuilderAIRepresentativeSFID")??""}),a.push({objectTypeId:"0-1",name:"utm_campaign__c",value:e.get("UTMCampaign")??""}),a.push({objectTypeId:"0-1",name:"utm_content__c",value:e.get("UTMContent")??""}),a.push({objectTypeId:"0-1",name:"utm_medium__c",value:e.get("UTMMedium")??""}),a.push({objectTypeId:"0-1",name:"utm_source__c",value:e.get("UTMSource")??""}),a.push({objectTypeId:"0-1",name:"utm_term__c",value:e.get("UTMTerm")??""}),a.push({objectTypeId:"0-1",name:"gclid__c",value:e.get("GCLID")??""}),a.push({objectTypeId:"0-1",name:"reddit_cid",value:e.get("RedditCID")??""}),a.push({objectTypeId:"0-1",name:"facebook_click_id__c",value:e.get("FacebookClickID")??""}),a.push({objectTypeId:"0-1",name:"facebook_browser_id__c",value:e.get("FacebookBrowserID")??""}),a.push({objectTypeId:"0-1",name:"ga_client_id__c",value:e.get("GAClientID")??""}),a.push({objectTypeId:"0-1",name:"builder_cookie_id__c",value:e.get("BuilderCookieID")??""}),a.push({objectTypeId:"0-1",name:"segment_anonymous_id__c",value:e.get("SegmentAnonymousID")??""}),a.push({objectTypeId:"0-1",name:"linkedin_click_id__c",value:e.get("LinkedinClickID")??""}),a.push({objectTypeId:"0-1",name:"hubspot_user_token__c",value:e.get("HubspotUserToken")??""});let h=e.get("UTMSource"),g=e.get("UTMCampaign");(h&&h.toLowerCase()==="field-sales"||h&&h.toLowerCase()==="field_sales"||g&&g.toLowerCase().includes("field_sales")||g&&g.toLowerCase().includes("field-sales"))&&(n="Field Sales"),n&&a.push({objectTypeId:"0-1",name:"leadsource",value:n}),new URL(window.location.href).hostname!=="www.builder.ai"&&console.log(JSON.stringify(a,void 0,"  "));let x=Gi(document.cookie);(window.location.origin!=="https://www.builder.ai"||e.get("Email").endsWith("@builder.ai")||e.get("Email").indexOf("test")>-1||t.searchParams.has("dev-no-hutk")||M)&&(x=void 0);let b=new URL(window.location.href);return b.searchParams.forEach(function(w,D,P){D.startsWith("dev-")||P.delete(D)}),b.hash="",e.get("UTMCampaign")&&b.searchParams.set("utm_campaign",e.get("UTMCampaign")),e.get("UTMContent")&&b.searchParams.set("utm_content",e.get("UTMContent")),e.get("UTMMedium")&&b.searchParams.set("utm_medium",e.get("UTMMedium")),e.get("UTMSource")&&b.searchParams.set("utm_source",e.get("UTMSource")),e.get("UTMTerm")&&b.searchParams.set("utm_term",e.get("UTMTerm")),e.get("UTMSource")&&b.searchParams.set("utm_source",e.get("UTMSource")),M&&(b.searchParams.delete("UTMCampaign"),b.searchParams.delete("UTMContent"),b.searchParams.delete("UTMMedium"),b.searchParams.delete("UTMSource"),b.searchParams.delete("UTMTerm"),b.searchParams.delete("GCLID")),await new bt().submit({portalId:"25293623",formGuid:"6a3b95e6-4b01-461a-84f1-6a7fefc6e43d",fields:a,context:{hutk:x,pageUri:b.href,pageName:window.document.title}})}var ga=[{name:"United States",code:"1",ref:"us"},{name:"United Kingdom",code:"44",ref:"gb"},{name:"India",code:"91",ref:"in"},{name:"United Arab Emirates",code:"971",ref:"ae"},{name:"Saudi Arabia",code:"966",ref:"sa"},{name:"Singapore",code:"65",ref:"sg"},{name:"Japan",code:"81",ref:"jp"},{name:"Afghanistan",code:"93",ref:"af"},{name:"Aland Islands",code:"358",ref:"ax"},{name:"Albania",code:"355",ref:"al"},{name:"Algeria",code:"213",ref:"dz"},{name:"AmericanSamoa",code:"1684",ref:"as"},{name:"Andorra",code:"376",ref:"ad"},{name:"Angola",code:"244",ref:"ao"},{name:"Anguilla",code:"1264",ref:"ai"},{name:"Antarctica",code:"672",ref:"aq"},{name:"Antigua and Barbuda",code:"1268",ref:"ag"},{name:"Argentina",code:"54",ref:"ar"},{name:"Armenia",code:"374",ref:"am"},{name:"Aruba",code:"297",ref:"aw"},{name:"Australia",code:"61",ref:"au"},{name:"Austria",code:"43",ref:"at"},{name:"Azerbaijan",code:"994",ref:"az"},{name:"Bahamas",code:"1242",ref:"bs"},{name:"Bahrain",code:"973",ref:"bh"},{name:"Bangladesh",code:"880",ref:"bd"},{name:"Barbados",code:"1246",ref:"bb"},{name:"Belarus",code:"375",ref:"by"},{name:"Belgium",code:"32",ref:"be"},{name:"Belize",code:"501",ref:"bz"},{name:"Benin",code:"229",ref:"bj"},{name:"Bermuda",code:"1441",ref:"bm"},{name:"Bhutan",code:"975",ref:"bt"},{name:"Bolivia, Plurinational State of",code:"591",ref:"bo"},{name:"Bosnia and Herzegovina",code:"387",ref:"ba"},{name:"Botswana",code:"267",ref:"bw"},{name:"Brazil",code:"55",ref:"br"},{name:"British Indian Ocean Territory",code:"246",ref:"io"},{name:"Brunei Darussalam",code:"673",ref:"bn"},{name:"Bulgaria",code:"359",ref:"bg"},{name:"Burkina Faso",code:"226",ref:"bf"},{name:"Burundi",code:"257",ref:"bi"},{name:"Cambodia",code:"855",ref:"kh"},{name:"Cameroon",code:"237",ref:"cm"},{name:"Canada",code:"1",ref:"ca"},{name:"Cape Verde",code:"238",ref:"cv"},{name:"Cayman Islands",code:"345",ref:"ky"},{name:"Central African Republic",code:"236",ref:"cf"},{name:"Chad",code:"235",ref:"td"},{name:"Chile",code:"56",ref:"cl"},{name:"China",code:"86",ref:"cn"},{name:"Christmas Island",code:"61",ref:"cx"},{name:"Cocos (Keeling) Islands",code:"61",ref:"cc"},{name:"Colombia",code:"57",ref:"co"},{name:"Comoros",code:"269",ref:"km"},{name:"Congo",code:"242",ref:"cg"},{name:"Congo, The Democratic Republic of the Congo",code:"243",ref:"cd"},{name:"Cook Islands",code:"682",ref:"ck"},{name:"Costa Rica",code:"506",ref:"cr"},{name:"Cote d'Ivoire",code:"225",ref:"ci"},{name:"Croatia",code:"385",ref:"hr"},{name:"Cuba",code:"53",ref:"cu"},{name:"Cyprus",code:"357",ref:"cy"},{name:"Czech Republic",code:"420",ref:"cz"},{name:"Denmark",code:"45",ref:"dk"},{name:"Djibouti",code:"253",ref:"dj"},{name:"Dominica",code:"1767",ref:"dm"},{name:"Dominican Republic",code:"1849",ref:"do"},{name:"Ecuador",code:"593",ref:"ec"},{name:"Egypt",code:"20",ref:"eg"},{name:"El Salvador",code:"503",ref:"sv"},{name:"Equatorial Guinea",code:"240",ref:"gq"},{name:"Eritrea",code:"291",ref:"er"},{name:"Estonia",code:"372",ref:"ee"},{name:"Ethiopia",code:"251",ref:"et"},{name:"Falkland Islands (Malvinas)",code:"500",ref:"fk"},{name:"Faroe Islands",code:"298",ref:"fo"},{name:"Fiji",code:"679",ref:"fj"},{name:"Finland",code:"358",ref:"fi"},{name:"France",code:"33",ref:"fr"},{name:"French Guiana",code:"594",ref:"gf"},{name:"French Polynesia",code:"689",ref:"pf"},{name:"Gabon",code:"241",ref:"ga"},{name:"Gambia",code:"220",ref:"gm"},{name:"Georgia",code:"995",ref:"ge"},{name:"Germany",code:"49",ref:"de"},{name:"Ghana",code:"233",ref:"gh"},{name:"Gibraltar",code:"350",ref:"gi"},{name:"Greece",code:"30",ref:"gr"},{name:"Greenland",code:"299",ref:"gl"},{name:"Grenada",code:"1473",ref:"gd"},{name:"Guadeloupe",code:"590",ref:"gp"},{name:"Guam",code:"1671",ref:"gu"},{name:"Guatemala",code:"502",ref:"gt"},{name:"Guernsey",code:"44",ref:"gg"},{name:"Guinea",code:"224",ref:"gn"},{name:"Guinea-Bissau",code:"245",ref:"gw"},{name:"Guyana",code:"595",ref:"gy"},{name:"Haiti",code:"509",ref:"ht"},{name:"Holy See (Vatican City State)",code:"379",ref:"va"},{name:"Honduras",code:"504",ref:"hn"},{name:"Hong Kong",code:"852",ref:"hk"},{name:"Hungary",code:"36",ref:"hu"},{name:"Iceland",code:"354",ref:"is"},{name:"Indonesia",code:"62",ref:"id"},{name:"Iran, Islamic Republic of Persian Gulf",code:"98",ref:"ir"},{name:"Iraq",code:"964",ref:"iq"},{name:"Ireland",code:"353",ref:"ie"},{name:"Isle of Man",code:"44",ref:"im"},{name:"Israel",code:"972",ref:"il"},{name:"Italy",code:"39",ref:"it"},{name:"Jamaica",code:"1876",ref:"jm"},{name:"Jersey",code:"44",ref:"je"},{name:"Jordan",code:"962",ref:"jo"},{name:"Kazakhstan",code:"77",ref:"kz"},{name:"Kenya",code:"254",ref:"ke"},{name:"Kiribati",code:"686",ref:"ki"},{name:"Korea, Democratic People's Republic of Korea",code:"850",ref:"kp"},{name:"Korea, Republic of South Korea",code:"82",ref:"kr"},{name:"Kuwait",code:"965",ref:"kw"},{name:"Kyrgyzstan",code:"996",ref:"kg"},{name:"Laos",code:"856",ref:"la"},{name:"Latvia",code:"371",ref:"lv"},{name:"Lebanon",code:"961",ref:"lb"},{name:"Lesotho",code:"266",ref:"ls"},{name:"Liberia",code:"231",ref:"lr"},{name:"Libyan Arab Jamahiriya",code:"218",ref:"ly"},{name:"Liechtenstein",code:"423",ref:"li"},{name:"Lithuania",code:"370",ref:"lt"},{name:"Luxembourg",code:"352",ref:"lu"},{name:"Macao",code:"853",ref:"mo"},{name:"Macedonia",code:"389",ref:"mk"},{name:"Madagascar",code:"261",ref:"mg"},{name:"Malawi",code:"265",ref:"mw"},{name:"Malaysia",code:"60",ref:"my"},{name:"Maldives",code:"960",ref:"mv"},{name:"Mali",code:"223",ref:"ml"},{name:"Malta",code:"356",ref:"mt"},{name:"Marshall Islands",code:"692",ref:"mh"},{name:"Martinique",code:"596",ref:"mq"},{name:"Mauritania",code:"222",ref:"mr"},{name:"Mauritius",code:"230",ref:"mu"},{name:"Mayotte",code:"262",ref:"yt"},{name:"Mexico",code:"52",ref:"mx"},{name:"Micronesia, Federated States of Micronesia",code:"691",ref:"fm"},{name:"Moldova",code:"373",ref:"md"},{name:"Monaco",code:"377",ref:"mc"},{name:"Mongolia",code:"976",ref:"mn"},{name:"Montenegro",code:"382",ref:"me"},{name:"Montserrat",code:"1664",ref:"ms"},{name:"Morocco",code:"212",ref:"ma"},{name:"Mozambique",code:"258",ref:"mz"},{name:"Myanmar",code:"95",ref:"mm"},{name:"Namibia",code:"264",ref:"na"},{name:"Nauru",code:"674",ref:"nr"},{name:"Nepal",code:"977",ref:"np"},{name:"Netherlands",code:"31",ref:"nl"},{name:"Netherlands Antilles",code:"599",ref:"an"},{name:"New Caledonia",code:"687",ref:"nc"},{name:"New Zealand",code:"64",ref:"nz"},{name:"Nicaragua",code:"505",ref:"ni"},{name:"Niger",code:"227",ref:"ne"},{name:"Nigeria",code:"234",ref:"ng"},{name:"Niue",code:"683",ref:"nu"},{name:"Norfolk Island",code:"672",ref:"nf"},{name:"Northern Mariana Islands",code:"1670",ref:"mp"},{name:"Norway",code:"47",ref:"no"},{name:"Oman",code:"968",ref:"om"},{name:"Pakistan",code:"92",ref:"pk"},{name:"Palau",code:"680",ref:"pw"},{name:"Palestinian Territory, Occupied",code:"970",ref:"ps"},{name:"Panama",code:"507",ref:"pa"},{name:"Papua New Guinea",code:"675",ref:"pg"},{name:"Paraguay",code:"595",ref:"py"},{name:"Peru",code:"51",ref:"pe"},{name:"Philippines",code:"63",ref:"ph"},{name:"Pitcairn",code:"872",ref:"pn"},{name:"Poland",code:"48",ref:"pl"},{name:"Portugal",code:"351",ref:"pt"},{name:"Puerto Rico",code:"1939",ref:"pr"},{name:"Qatar",code:"974",ref:"qa"},{name:"Romania",code:"40",ref:"ro"},{name:"Russia",code:"7",ref:"ru"},{name:"Rwanda",code:"250",ref:"rw"},{name:"Reunion",code:"262",ref:"re"},{name:"Saint Barthelemy",code:"590",ref:"bl"},{name:"Saint Helena, Ascension and Tristan Da Cunha",code:"290",ref:"sh"},{name:"Saint Kitts and Nevis",code:"1869",ref:"kn"},{name:"Saint Lucia",code:"1758",ref:"lc"},{name:"Saint Martin",code:"590",ref:"mf"},{name:"Saint Pierre and Miquelon",code:"508",ref:"pm"},{name:"Saint Vincent and the Grenadines",code:"1784",ref:"vc"},{name:"Samoa",code:"685",ref:"ws"},{name:"San Marino",code:"378",ref:"sm"},{name:"Sao Tome and Principe",code:"239",ref:"st"},{name:"Senegal",code:"221",ref:"sn"},{name:"Serbia",code:"381",ref:"rs"},{name:"Seychelles",code:"248",ref:"sc"},{name:"Sierra Leone",code:"232",ref:"sl"},{name:"Slovakia",code:"421",ref:"sk"},{name:"Slovenia",code:"386",ref:"si"},{name:"Solomon Islands",code:"677",ref:"sb"},{name:"Somalia",code:"252",ref:"so"},{name:"South Africa",code:"27",ref:"za"},{name:"South Sudan",code:"211",ref:"ss"},{name:"South Georgia and the South Sandwich Islands",code:"500",ref:"gs"},{name:"Spain",code:"34",ref:"es"},{name:"Sri Lanka",code:"94",ref:"lk"},{name:"Sudan",code:"249",ref:"sd"},{name:"Suriname",code:"597",ref:"sr"},{name:"Svalbard and Jan Mayen",code:"47",ref:"sj"},{name:"Swaziland",code:"268",ref:"sz"},{name:"Sweden",code:"46",ref:"se"},{name:"Switzerland",code:"41",ref:"ch"},{name:"Syrian Arab Republic",code:"963",ref:"sy"},{name:"Taiwan",code:"886",ref:"tw"},{name:"Tajikistan",code:"992",ref:"tj"},{name:"Tanzania, United Republic of Tanzania",code:"255",ref:"tz"},{name:"Thailand",code:"66",ref:"th"},{name:"Timor-Leste",code:"670",ref:"tl"},{name:"Togo",code:"228",ref:"tg"},{name:"Tokelau",code:"690",ref:"tk"},{name:"Tonga",code:"676",ref:"to"},{name:"Trinidad and Tobago",code:"1868",ref:"tt"},{name:"Tunisia",code:"216",ref:"tn"},{name:"Turkey",code:"90",ref:"tr"},{name:"Turkmenistan",code:"993",ref:"tm"},{name:"Turks and Caicos Islands",code:"1649",ref:"tc"},{name:"Tuvalu",code:"688",ref:"tv"},{name:"Uganda",code:"256",ref:"ug"},{name:"Ukraine",code:"380",ref:"ua"},{name:"Uruguay",code:"598",ref:"uy"},{name:"Uzbekistan",code:"998",ref:"uz"},{name:"Vanuatu",code:"678",ref:"vu"},{name:"Venezuela, Bolivarian Republic of Venezuela",code:"58",ref:"ve"},{name:"Vietnam",code:"84",ref:"vn"},{name:"Virgin Islands, British",code:"1284",ref:"vg"},{name:"Virgin Islands, U.S.",code:"1340",ref:"vi"},{name:"Wallis and Futuna",code:"681",ref:"wf"},{name:"Yemen",code:"967",ref:"ye"},{name:"Zambia",code:"260",ref:"zm"},{name:"Zimbabwe",code:"263",ref:"zw"}];var p=String.raw,ma=String.raw,ft=0;function L(e){return ft=ft+1,`${e}-${ft}`}var ue=ma`
.tailwind *, .tailwind :before, .tailwind:after {border:0 solid;box-sizing:border-box}.tailwind:after,.tailwind:before{--tw-content:""}.tailwind{-webkit-text-size-adjust:100%;font-family:ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Arial,Noto Sans,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;line-height:1.5;-moz-tab-size:4;-o-tab-size:4;tab-size:4}.tailwind hr{border-top-width:1px;color:inherit;height:0}.tailwind abbr[title]{-webkit-text-decoration:underline dotted;text-decoration:underline dotted}.tailwind h1,.tailwind h2,.tailwind h3,.tailwind h4,.tailwind h5,.tailwind h6{font-size:inherit;font-weight:inherit}.tailwind a{color:inherit;text-decoration:inherit}.tailwind b,.tailwind strong{font-weight:bolder}.tailwind code,.tailwind kbd,.tailwind pre,.tailwind samp{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,Liberation Mono,Courier New,monospace;font-size:1em}.tailwind small{font-size:80%}.tailwind sub,.tailwind sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}.tailwind sub{bottom:-.25em}.tailwind sup{top:-.5em}.tailwind table{border-collapse:collapse;border-color:inherit;text-indent:0}.tailwind button,.tailwind input,.tailwind optgroup,.tailwind select,.tailwind textarea{color:inherit;font-family:inherit;font-size:100%;line-height:inherit;margin:0;padding:0}.tailwind button,.tailwind select{text-transform:none}.tailwind [type=button],.tailwind [type=reset],.tailwind [type=submit],.tailwind button{-webkit-appearance:button}.tailwind :-moz-focusring{outline:auto}.tailwind :-moz-ui-invalid{box-shadow:none}.tailwind progress{vertical-align:baseline}.tailwind ::-webkit-inner-spin-button,.tailwind ::-webkit-outer-spin-button{height:auto}.tailwind [type=search]{-webkit-appearance:textfield;outline-offset:-2px}.tailwind ::-webkit-search-decoration{-webkit-appearance:none}.tailwind ::-webkit-file-upload-button{-webkit-appearance:button;font:inherit}.tailwind summary{display:list-item}.tailwind blockquote,.tailwind dd,.tailwind dl,.tailwind figure,.tailwind h1,.tailwind h2,.tailwind h3,.tailwind h4,.tailwind h5,.tailwind h6,.tailwind hr,.tailwind p,.tailwind pre{margin:0}.tailwind fieldset{margin:0;padding:0}.tailwind legend{padding:0}.tailwind menu,.tailwind ol,.tailwind ul{list-style:none;margin:0;padding:0}.tailwind textarea{resize:vertical}.tailwind input::-moz-placeholder,.tailwind textarea::-moz-placeholder{color:#9ca3af;opacity:1}.tailwind input:-ms-input-placeholder,.tailwind textarea:-ms-input-placeholder{color:#9ca3af;opacity:1}.tailwind input::placeholder,.tailwind textarea::placeholder{color:#9ca3af;opacity:1}.tailwind [role=button],.tailwind button{cursor:pointer}.tailwind :disabled{cursor:default}.tailwind audio,.tailwind canvas,.tailwind embed,.tailwind iframe,.tailwind img,.tailwind object,.tailwind svg,.tailwind video{display:block;vertical-align:middle}.tailwind img,.tailwind video{height:auto;max-width:100%}.tailwind [hidden]{display:none}.bg-white{background-color:#fff!important}.tailwind *,.tailwind :after,.tailwind :before{--tw-translate-x:0;--tw-translate-y:0;--tw-rotate:0;--tw-skew-x:0;--tw-skew-y:0;--tw-scale-x:1;--tw-scale-y:1;--tw-transform:translateX(var(--tw-translate-x)) translateY(var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));border-color:currentColor}.container{width:100%}@media (min-width:320px){.container{max-width:320px}}@media (min-width:475px){.container{max-width:475px}}@media (min-width:640px){.container{max-width:640px}}@media (min-width:768px){.container{max-width:768px}}@media (min-width:1024px){.container{max-width:1024px}}@media (min-width:1280px){.container{max-width:1280px}}@media (min-width:1536px){.container{max-width:1536px}}.tailwind .sr-only{clip:rect(0,0,0,0);border-width:0;height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;white-space:nowrap;width:1px}.tailwind .not-sr-only{clip:auto;height:auto;margin:0;overflow:visible;padding:0;position:static;white-space:normal;width:auto}.tailwind .pointer-events-none{pointer-events:none}.tailwind .static{position:static}.tailwind .absolute{position:absolute}.tailwind .relative{position:relative}.tailwind .inset-y-0{bottom:0;top:0}.tailwind .inset-x-2{left:.5rem;right:.5rem}.tailwind .inset-x-4{left:1rem;right:1rem}.tailwind .right-0{right:0}.tailwind .col-span-full{grid-column:1/-1}.tailwind .row-start-1{grid-row-start:1}.tailwind .m-10{margin:2.5rem}.tailwind .mx-3{margin-left:.75rem;margin-right:.75rem}.tailwind .my-8{margin-bottom:2rem;margin-top:2rem}.tailwind .my-4{margin-bottom:1rem;margin-top:1rem}.tailwind .my-1{margin-bottom:.25rem;margin-top:.25rem}.tailwind .my-2{margin-bottom:.5rem;margin-top:.5rem}.tailwind .-mx-2{margin-left:-.5rem;margin-right:-.5rem}.tailwind .my-10{margin-bottom:2.5rem;margin-top:2.5rem}.tailwind .mx-auto{margin-left:auto;margin-right:auto}.tailwind .mb-1{margin-bottom:.25rem}.tailwind .mt-4{margin-top:1rem}.tailwind .mt-2{margin-top:.5rem}.tailwind .mt-1{margin-top:.25rem}.tailwind .ml-3{margin-left:.75rem}.tailwind .mt-3{margin-top:.75rem}.tailwind .mt-6{margin-top:1.5rem}.tailwind .mt-10{margin-top:2.5rem}.tailwind .mb-0{margin-bottom:0}.tailwind .block{display:block}.tailwind .inline-block{display:inline-block}.tailwind .inline{display:inline}.tailwind .flex{display:flex}.tailwind .inline-flex{display:inline-flex}.tailwind .table{display:table}.tailwind .grid{display:grid}.tailwind .hidden{display:none}.tailwind .h-4{height:1rem}.tailwind .h-6{height:1.5rem}.tailwind .h-full{height:100%}.tailwind .h-min{height:-webkit-min-content;height:-moz-min-content;height:min-content}.tailwind .h-5{height:1.25rem}.tailwind .w-full{width:100%}.tailwind .w-4{width:1rem}.tailwind .w-6{width:1.5rem}.tailwind .w-min{width:-webkit-min-content;width:-moz-min-content;width:min-content}.tailwind .w-5{width:1.25rem}.tailwind .min-w-max{min-width:-webkit-max-content;min-width:-moz-max-content;min-width:max-content}.tailwind .min-w-\[100px\]{min-width:100px}.tailwind .min-w-\[10em\]{min-width:10em}.tailwind .min-w-\[50\%\]{min-width:50%}.tailwind .max-w-lg{max-width:32rem}.tailwind .max-w-max{max-width:-webkit-max-content;max-width:-moz-max-content;max-width:max-content}.tailwind .max-w-full{max-width:100%}.tailwind .max-w-xl{max-width:36rem}.tailwind .max-w-screen-md{max-width:768px}.tailwind .max-w-\[120px\]{max-width:120px}.tailwind .flex-grow{flex-grow:1}.tailwind .border-collapse{border-collapse:collapse}.tailwind .transform{transform:var(--tw-transform)}.tailwind .cursor-pointer{cursor:pointer}.tailwind .resize{resize:both}.tailwind .appearance-none{-webkit-appearance:none;-moz-appearance:none;appearance:none}.tailwind .grid-cols-1{grid-template-columns:repeat(1,minmax(0,1fr))}.tailwind .grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}.tailwind .flex-row{flex-direction:row}.tailwind .flex-col{flex-direction:column}.tailwind .flex-wrap{flex-wrap:wrap}.tailwind .flex-nowrap{flex-wrap:nowrap}.tailwind .items-start{align-items:flex-start}.tailwind .items-center{align-items:center}.tailwind .justify-center{justify-content:center}.tailwind .justify-around{justify-content:space-around}.tailwind .gap-2{gap:.5rem}.tailwind .gap-4{gap:1rem}.tailwind .gap-1{gap:.25rem}.tailwind .space-x-2>:not([hidden])~:not([hidden]){--tw-space-x-reverse:0;margin-left:calc(.5rem*(1 - var(--tw-space-x-reverse)));margin-right:calc(.5rem*var(--tw-space-x-reverse))}.tailwind .whitespace-nowrap{white-space:nowrap}.tailwind .rounded{border-radius:.25rem}.tailwind .rounded-lg{border-radius:.5rem}.tailwind .rounded-full{border-radius:9999px}.tailwind .border{border-width:1px}.tailwind .border-y{border-bottom-width:1px;border-top-width:1px}.tailwind .border-x{border-left-width:1px;border-right-width:1px}.tailwind .border-bluegray-6{--tw-border-opacity:1;border-color:rgb(175 178 192/var(--tw-border-opacity))}.tailwind .border-builderpurple-a5{--tw-border-opacity:1;border-color:rgb(98 0 234/var(--tw-border-opacity))}.tailwind .border-bluegray-2{--tw-border-opacity:1;border-color:rgb(236 237 240/var(--tw-border-opacity))}.tailwind .bg-buildergreen-a45{--tw-bg-opacity:1;background-color:rgb(0 214 89/var(--tw-bg-opacity))}.tailwind .bg-gray-1{--tw-bg-opacity:1;background-color:rgb(255 255 255/var(--tw-bg-opacity))}.tailwind .bg-gray-2{--tw-bg-opacity:1;background-color:rgb(250 250 250/var(--tw-bg-opacity))}.tailwind .fill-current{fill:currentColor}.tailwind .p-3{padding:.75rem}.tailwind .px-10{padding-left:2.5rem;padding-right:2.5rem}.tailwind .py-3{padding-bottom:.75rem;padding-top:.75rem}.tailwind .px-4{padding-left:1rem;padding-right:1rem}.tailwind .px-2{padding-left:.5rem;padding-right:.5rem}.tailwind .px-6{padding-left:1.5rem;padding-right:1.5rem}.tailwind .py-4{padding-bottom:1rem;padding-top:1rem}.tailwind .py-6{padding-bottom:1.5rem;padding-top:1.5rem}.tailwind .pr-8{padding-right:2rem}.tailwind .pl-8{padding-left:2rem}.tailwind .pr-2{padding-right:.5rem}.tailwind .pl-16{padding-left:4rem}.tailwind .pr-4{padding-right:1rem}.tailwind .pb-6{padding-bottom:1.5rem}.tailwind .text-left{text-align:left}.tailwind .text-center{text-align:center}.tailwind .font-rubik{font-family:Rubik,Arial,sans-serif}.tailwind .text-sm{font-size:.875rem;letter-spacing:-.2px;line-height:1.25rem}.tailwind .text-lg{font-size:1.125rem;letter-spacing:-.03em;line-height:1.5rem}.tailwind .text-xs{font-size:.75rem;letter-spacing:-.1px;line-height:1rem}.tailwind .text-xl{font-size:1.25rem;letter-spacing:-.03em;line-height:1.75rem}.tailwind .font-semibold{font-weight:600}.tailwind .font-bold{font-weight:700}.tailwind .font-medium{font-weight:500}.tailwind .leading-tight{line-height:1.25}.tailwind .tracking-wide{letter-spacing:.025em}.tailwind .text-builderpurple-a5{--tw-text-opacity:1;color:rgb(98 0 234/var(--tw-text-opacity))}.tailwind .text-gray-10{--tw-text-opacity:1;color:rgb(0 0 0/var(--tw-text-opacity))}.tailwind .text-bluegray-6{--tw-text-opacity:1;color:rgb(175 178 192/var(--tw-text-opacity))}.tailwind .text-bluegray-9{--tw-text-opacity:1;color:rgb(103 107 126/var(--tw-text-opacity))}.tailwind .underline{-webkit-text-decoration-line:underline;text-decoration-line:underline}.tailwind .accent-builderpurple-a5{accent-color:#6200ea}.tailwind .outline{outline-style:solid}:root{--form-control-color:#7c4dff}.tailwind .form-control{display:grid;gap:.5em;grid-template-columns:1em auto}.tailwind input[type=checkbox],.tailwind input[type=radio]{-webkit-appearance:none;-moz-appearance:none;appearance:none;background-color:var(--form-background);border:.15em solid #d0d2da;border-radius:50%;color:currentColor;display:grid;font:inherit;margin:0;place-content:center;transform:translateY(.075em)}.tailwind input[type=checkbox]{border-radius:.15em}.tailwind input[type=checkbox]:before,.tailwind input[type=radio]:before{background-color:CanvasText;border-radius:50%;box-shadow:inset 1em 1em var(--form-control-color);content:"";height:1em;transform:scale(0);transition:transform .12s ease-in-out;width:1em}.tailwind input[type=checkbox]:before{-webkit-clip-path:polygon(14% 44%,0 65%,50% 100%,100% 16%,80% 0,43% 62%);clip-path:polygon(14% 44%,0 65%,50% 100%,100% 16%,80% 0,43% 62%);transform-origin:bottom left}.tailwind input[type=checkbox]:checked:before,.tailwind input[type=radio]:checked:before{transform:scale(1)}.tailwind input[type=radio]:focus{outline:solid #fff;outline-offset:max(2px,.15em)}.tailwind .form-control--disabled{color:#959495;cursor:not-allowed}.flag-icon,.flag-icon-background{background-position:50%;background-repeat:no-repeat;background-size:contain}.flag-icon{display:inline-block;line-height:1em;position:relative;width:1.33333333em}.flag-icon:before{content:"\00a0"}.flag-icon.flag-icon-squared{width:1em}.flag-icon-ad{background-image:url(https://studio.builder.ai/ad.45026b922ec57f969a0a.svg)}.flag-icon-ad.flag-icon-squared{background-image:url(https://studio.builder.ai/ad.94e810253dbc84702e9a.svg)}.flag-icon-ae{background-image:url(https://studio.builder.ai/ae.2c530f6449f3e5abd04b.svg)}.flag-icon-ae.flag-icon-squared{background-image:url(https://studio.builder.ai/ae.23c174705b39d649ba43.svg)}.flag-icon-af{background-image:url(https://studio.builder.ai/af.458ab7e0c32d14aefe33.svg)}.flag-icon-af.flag-icon-squared{background-image:url(https://studio.builder.ai/af.867627c537fd29812532.svg)}.flag-icon-ag{background-image:url(https://studio.builder.ai/ag.5929ca9ff0f160f96fb5.svg)}.flag-icon-ag.flag-icon-squared{background-image:url(https://studio.builder.ai/ag.3f18bb58815f1eb37b60.svg)}.flag-icon-ai{background-image:url(https://studio.builder.ai/ai.c4699001b99c1638c765.svg)}.flag-icon-ai.flag-icon-squared{background-image:url(https://studio.builder.ai/ai.546a12e334b3f4d8967c.svg)}.flag-icon-al{background-image:url(https://studio.builder.ai/al.3dd8853b91d6f490b4c1.svg)}.flag-icon-al.flag-icon-squared{background-image:url(https://studio.builder.ai/al.090568ab89f9b7e68f3b.svg)}.flag-icon-am{background-image:url(https://studio.builder.ai/am.e935f82147f4d3c76c92.svg)}.flag-icon-am.flag-icon-squared{background-image:url(https://studio.builder.ai/am.36fc7db319e532bff785.svg)}.flag-icon-ao{background-image:url(https://studio.builder.ai/ao.ad6f3c8c3519f36b36c4.svg)}.flag-icon-ao.flag-icon-squared{background-image:url(https://studio.builder.ai/ao.7ed590a16ff7642e7a85.svg)}.flag-icon-aq{background-image:url(https://studio.builder.ai/aq.e3fbc5d0ce77f1c9e808.svg)}.flag-icon-aq.flag-icon-squared{background-image:url(https://studio.builder.ai/aq.e6c275d0d4e5135fb04b.svg)}.flag-icon-ar{background-image:url(https://studio.builder.ai/ar.2ff091f8773d0ea8640d.svg)}.flag-icon-ar.flag-icon-squared{background-image:url(https://studio.builder.ai/ar.5a7c09af30ea06db87f1.svg)}.flag-icon-as{background-image:url(https://studio.builder.ai/as.3b86b6876653592c0fa3.svg)}.flag-icon-as.flag-icon-squared{background-image:url(https://studio.builder.ai/as.7ae00cb9d6bf497132c1.svg)}.flag-icon-at{background-image:url(https://studio.builder.ai/at.1281f451a103684e9248.svg)}.flag-icon-at.flag-icon-squared{background-image:url(https://studio.builder.ai/at.d7b3791eb6679e92a2bd.svg)}.flag-icon-au{background-image:url(https://studio.builder.ai/au.932d918261bcbb88f0cc.svg)}.flag-icon-au.flag-icon-squared{background-image:url(https://studio.builder.ai/au.5b98a120aeec3f5a1aeb.svg)}.flag-icon-aw{background-image:url(https://studio.builder.ai/aw.98298192f432c6fc56cc.svg)}.flag-icon-aw.flag-icon-squared{background-image:url(https://studio.builder.ai/aw.b478dded01c70ad2275c.svg)}.flag-icon-ax{background-image:url(https://studio.builder.ai/ax.6651bb2513bc040f7f2b.svg)}.flag-icon-ax.flag-icon-squared{background-image:url(https://studio.builder.ai/ax.c260e9a581b4c4415f20.svg)}.flag-icon-az{background-image:url(https://studio.builder.ai/az.d4faca473814e47b3f03.svg)}.flag-icon-az.flag-icon-squared{background-image:url(https://studio.builder.ai/az.84126238074d3c3c30b9.svg)}.flag-icon-ba{background-image:url(https://studio.builder.ai/ba.7097f2f878560a3debc6.svg)}.flag-icon-ba.flag-icon-squared{background-image:url(https://studio.builder.ai/ba.d1e732dc96724fe02492.svg)}.flag-icon-bb{background-image:url(https://studio.builder.ai/bb.021629a6a596929b0462.svg)}.flag-icon-bb.flag-icon-squared{background-image:url(https://studio.builder.ai/bb.17738ccf41cecf9d38ba.svg)}.flag-icon-bd{background-image:url(https://studio.builder.ai/bd.d16830cba55e113c5888.svg)}.flag-icon-bd.flag-icon-squared{background-image:url(https://studio.builder.ai/bd.a3ae69dedf0b3ad8fb44.svg)}.flag-icon-be{background-image:url(https://studio.builder.ai/be.410c4acc521ec3a59836.svg)}.flag-icon-be.flag-icon-squared{background-image:url(https://studio.builder.ai/be.914a3c37d1998aa1f6b0.svg)}.flag-icon-bf{background-image:url(https://studio.builder.ai/bf.4275eb85c53fe2d0f6a8.svg)}.flag-icon-bf.flag-icon-squared{background-image:url(https://studio.builder.ai/bf.6fc31e160aec39c1d496.svg)}.flag-icon-bg{background-image:url(https://studio.builder.ai/bg.c9c13073359faec8e076.svg)}.flag-icon-bg.flag-icon-squared{background-image:url(https://studio.builder.ai/bg.4f2a9bbb4c1ea18ea4dd.svg)}.flag-icon-bh{background-image:url(https://studio.builder.ai/bh.ec61516daebfebe2cd49.svg)}.flag-icon-bh.flag-icon-squared{background-image:url(https://studio.builder.ai/bh.0cfc56195412f09f4c70.svg)}.flag-icon-bi{background-image:url(https://studio.builder.ai/bi.3fce551eeb9f82d29f76.svg)}.flag-icon-bi.flag-icon-squared{background-image:url(https://studio.builder.ai/bi.5adb744e68bc13f75956.svg)}.flag-icon-bj{background-image:url(https://studio.builder.ai/bj.e8591ed7d23999de96ef.svg)}.flag-icon-bj.flag-icon-squared{background-image:url(https://studio.builder.ai/bj.fb3d1c01b8a808e6fe13.svg)}.flag-icon-bl{background-image:url(https://studio.builder.ai/bl.6a6bc7f183b774316b63.svg)}.flag-icon-bl.flag-icon-squared{background-image:url(https://studio.builder.ai/bl.669bbb820754f1cc0ce4.svg)}.flag-icon-bm{background-image:url(https://studio.builder.ai/bm.e2aa572a02963b087e48.svg)}.flag-icon-bm.flag-icon-squared{background-image:url(https://studio.builder.ai/bm.7dd1b92ad42d2f9d69dd.svg)}.flag-icon-bn{background-image:url(https://studio.builder.ai/bn.ad7aafa9a29894397b43.svg)}.flag-icon-bn.flag-icon-squared{background-image:url(https://studio.builder.ai/bn.5fd8c65274736a1b6af4.svg)}.flag-icon-bo{background-image:url(https://studio.builder.ai/bo.1155c3da4861424ea8ff.svg)}.flag-icon-bo.flag-icon-squared{background-image:url(https://studio.builder.ai/bo.ee5938f07b3324e9af6d.svg)}.flag-icon-bq{background-image:url(https://studio.builder.ai/bq.8ff78ac28371e9069bfb.svg)}.flag-icon-bq.flag-icon-squared{background-image:url(https://studio.builder.ai/bq.6e5b96f6104d2ff9977a.svg)}.flag-icon-br{background-image:url(https://studio.builder.ai/br.5ec13287c2da0d77a7e7.svg)}.flag-icon-br.flag-icon-squared{background-image:url(https://studio.builder.ai/br.b3663866f502ec386f0e.svg)}.flag-icon-bs{background-image:url(https://studio.builder.ai/bs.5497678a4578b848e08d.svg)}.flag-icon-bs.flag-icon-squared{background-image:url(https://studio.builder.ai/bs.a9ddb124f725485b9445.svg)}.flag-icon-bt{background-image:url(https://studio.builder.ai/bt.eed19cbfd0dc809d6886.svg)}.flag-icon-bt.flag-icon-squared{background-image:url(https://studio.builder.ai/bt.1372873ed65891680a2d.svg)}.flag-icon-bv{background-image:url(https://studio.builder.ai/bv.b789f839eda2bce4b0e3.svg)}.flag-icon-bv.flag-icon-squared{background-image:url(https://studio.builder.ai/bv.adee14dc818c2a37dbd9.svg)}.flag-icon-bw{background-image:url(https://studio.builder.ai/bw.8a35721e3f5ff275ace8.svg)}.flag-icon-bw.flag-icon-squared{background-image:url(https://studio.builder.ai/bw.0acc600b67ac7165e38c.svg)}.flag-icon-by{background-image:url(https://studio.builder.ai/by.ed1fb53394827e144c8a.svg)}.flag-icon-by.flag-icon-squared{background-image:url(https://studio.builder.ai/by.da99aaa559633b439aa3.svg)}.flag-icon-bz{background-image:url(https://studio.builder.ai/bz.4eb2d29f4fcc586ae3e2.svg)}.flag-icon-bz.flag-icon-squared{background-image:url(https://studio.builder.ai/bz.7826f0d58900985ad312.svg)}.flag-icon-ca{background-image:url(https://studio.builder.ai/ca.d348137a99e6d528c5b7.svg)}.flag-icon-ca.flag-icon-squared{background-image:url(https://studio.builder.ai/ca.102b45b24a03abdaeae6.svg)}.flag-icon-cc{background-image:url(https://studio.builder.ai/cc.200233c98efe5d026e98.svg)}.flag-icon-cc.flag-icon-squared{background-image:url(https://studio.builder.ai/cc.27d55bfa0a8b66542f74.svg)}.flag-icon-cd{background-image:url(https://studio.builder.ai/cd.e5fd4d1225cc6c53b73d.svg)}.flag-icon-cd.flag-icon-squared{background-image:url(https://studio.builder.ai/cd.d44809aaad5d32f91a56.svg)}.flag-icon-cf{background-image:url(https://studio.builder.ai/cf.617adc02abcee400496d.svg)}.flag-icon-cf.flag-icon-squared{background-image:url(https://studio.builder.ai/cf.eb50c5ecfa556ddba5a7.svg)}.flag-icon-cg{background-image:url(https://studio.builder.ai/cg.440e321a39cf550b0bec.svg)}.flag-icon-cg.flag-icon-squared{background-image:url(https://studio.builder.ai/cg.862f4608de0f8e9d213c.svg)}.flag-icon-ch{background-image:url(https://studio.builder.ai/ch.7a52ef5e31b7f5e08a01.svg)}.flag-icon-ch.flag-icon-squared{background-image:url(https://studio.builder.ai/ch.1113c7e9162d605ca580.svg)}.flag-icon-ci{background-image:url(https://studio.builder.ai/ci.b1030b2b5315547c7fbe.svg)}.flag-icon-ci.flag-icon-squared{background-image:url(https://studio.builder.ai/ci.6f06682eaf98960662af.svg)}.flag-icon-ck{background-image:url(https://studio.builder.ai/ck.65a80cb3a138985c22dc.svg)}.flag-icon-ck.flag-icon-squared{background-image:url(https://studio.builder.ai/ck.d76f3968d6f25ed0bc7d.svg)}.flag-icon-cl{background-image:url(https://studio.builder.ai/cl.b9ff305a088060fd040a.svg)}.flag-icon-cl.flag-icon-squared{background-image:url(https://studio.builder.ai/cl.303f56a616afb6bae962.svg)}.flag-icon-cm{background-image:url(https://studio.builder.ai/cm.7578267e8568b1490427.svg)}.flag-icon-cm.flag-icon-squared{background-image:url(https://studio.builder.ai/cm.0dcbc4f1fe098b1b8725.svg)}.flag-icon-cn{background-image:url(https://studio.builder.ai/cn.7977e12a9afade492c93.svg)}.flag-icon-cn.flag-icon-squared{background-image:url(https://studio.builder.ai/cn.f5a6f048eb8367343bd4.svg)}.flag-icon-co{background-image:url(https://studio.builder.ai/co.59ec93f7d718ebed3779.svg)}.flag-icon-co.flag-icon-squared{background-image:url(https://studio.builder.ai/co.4c87d079860a09479706.svg)}.flag-icon-cr{background-image:url(https://studio.builder.ai/cr.6f2d7bb05d9edb1089ec.svg)}.flag-icon-cr.flag-icon-squared{background-image:url(https://studio.builder.ai/cr.ebed46008265a3777565.svg)}.flag-icon-cu{background-image:url(https://studio.builder.ai/cu.ff35f996902731bad287.svg)}.flag-icon-cu.flag-icon-squared{background-image:url(https://studio.builder.ai/cu.1452c504ef675071dcdf.svg)}.flag-icon-cv{background-image:url(https://studio.builder.ai/cv.434373304db5970887de.svg)}.flag-icon-cv.flag-icon-squared{background-image:url(https://studio.builder.ai/cv.1ddd34244b91f9c46e1d.svg)}.flag-icon-cw{background-image:url(https://studio.builder.ai/cw.8e4cecbf86c9e4b2df3a.svg)}.flag-icon-cw.flag-icon-squared{background-image:url(https://studio.builder.ai/cw.3fc4503762b62953af04.svg)}.flag-icon-cx{background-image:url(https://studio.builder.ai/cx.b9b5e6cd65826aab60c6.svg)}.flag-icon-cx.flag-icon-squared{background-image:url(https://studio.builder.ai/cx.dda4107fd05b8081ae62.svg)}.flag-icon-cy{background-image:url(https://studio.builder.ai/cy.70de54e68d8683969410.svg)}.flag-icon-cy.flag-icon-squared{background-image:url(https://studio.builder.ai/cy.bdc1fde27ba14b2afa3b.svg)}.flag-icon-cz{background-image:url(https://studio.builder.ai/cz.8ef2bc6a4d5bad23e284.svg)}.flag-icon-cz.flag-icon-squared{background-image:url(https://studio.builder.ai/cz.1b3452b8ce83987fb494.svg)}.flag-icon-de{background-image:url(https://studio.builder.ai/de.7e82f4c71df5fc78abbb.svg)}.flag-icon-de.flag-icon-squared{background-image:url(https://studio.builder.ai/de.11d88d2b77e6abe5ebb1.svg)}.flag-icon-dj{background-image:url(https://studio.builder.ai/dj.76f4cdf5eb6411038bc5.svg)}.flag-icon-dj.flag-icon-squared{background-image:url(https://studio.builder.ai/dj.278a5a5fce9a6090ce80.svg)}.flag-icon-dk{background-image:url(https://studio.builder.ai/dk.f4e8fc5376a202f1d771.svg)}.flag-icon-dk.flag-icon-squared{background-image:url(https://studio.builder.ai/dk.c2e570fa503242ab4c3e.svg)}.flag-icon-dm{background-image:url(https://studio.builder.ai/dm.466757644ba07a8bbf78.svg)}.flag-icon-dm.flag-icon-squared{background-image:url(https://studio.builder.ai/dm.dc3455775ad035d0926c.svg)}.flag-icon-do{background-image:url(https://studio.builder.ai/do.c05850db8e87e53a1268.svg)}.flag-icon-do.flag-icon-squared{background-image:url(https://studio.builder.ai/do.64a9810e7d07e3af7412.svg)}.flag-icon-dz{background-image:url(https://studio.builder.ai/dz.945a413c6ba8e484b7b1.svg)}.flag-icon-dz.flag-icon-squared{background-image:url(https://studio.builder.ai/dz.2be2fee6433a59e75c3d.svg)}.flag-icon-ec{background-image:url(https://studio.builder.ai/ec.3ea7f906eaf807123a28.svg)}.flag-icon-ec.flag-icon-squared{background-image:url(https://studio.builder.ai/ec.7be6ca137c0a396154ac.svg)}.flag-icon-ee{background-image:url(https://studio.builder.ai/ee.887a78f0eb107b3ce616.svg)}.flag-icon-ee.flag-icon-squared{background-image:url(https://studio.builder.ai/ee.7b6b8abcf78cfa7f4a77.svg)}.flag-icon-eg{background-image:url(https://studio.builder.ai/eg.b3580df977ae211f31d3.svg)}.flag-icon-eg.flag-icon-squared{background-image:url(https://studio.builder.ai/eg.c6ff8d6c3057865a32f1.svg)}.flag-icon-eh{background-image:url(https://studio.builder.ai/eh.8c8b27438e64065d8542.svg)}.flag-icon-eh.flag-icon-squared{background-image:url(https://studio.builder.ai/eh.905fdd0842d1597c4a27.svg)}.flag-icon-er{background-image:url(https://studio.builder.ai/er.458bc299993e856c309d.svg)}.flag-icon-er.flag-icon-squared{background-image:url(https://studio.builder.ai/er.ff62e2720daee288818f.svg)}.flag-icon-es{background-image:url(https://studio.builder.ai/es.1a25a96e26fcca676c08.svg)}.flag-icon-es.flag-icon-squared{background-image:url(https://studio.builder.ai/es.b3825b28f7a64779d80d.svg)}.flag-icon-et{background-image:url(https://studio.builder.ai/et.cbe354bb4afa8afc62da.svg)}.flag-icon-et.flag-icon-squared{background-image:url(https://studio.builder.ai/et.061591dd14f8c02c150f.svg)}.flag-icon-fi{background-image:url(https://studio.builder.ai/fi.3b522e7f272eee4009b2.svg)}.flag-icon-fi.flag-icon-squared{background-image:url(https://studio.builder.ai/fi.eb793b740dd4fa0f8b63.svg)}.flag-icon-fj{background-image:url(https://studio.builder.ai/fj.f3d86add9fe9ed672274.svg)}.flag-icon-fj.flag-icon-squared{background-image:url(https://studio.builder.ai/fj.55dd1c6e9a323130d8e7.svg)}.flag-icon-fk{background-image:url(https://studio.builder.ai/fk.ddc6bd174c1e6603e323.svg)}.flag-icon-fk.flag-icon-squared{background-image:url(https://studio.builder.ai/fk.fe8e733a5a44d9626de2.svg)}.flag-icon-fm{background-image:url(https://studio.builder.ai/fm.3bfd96ee5faa59b8017a.svg)}.flag-icon-fm.flag-icon-squared{background-image:url(https://studio.builder.ai/fm.1579e5b6f7e79e751445.svg)}.flag-icon-fo{background-image:url(https://studio.builder.ai/fo.f284df39e89f9ed508ad.svg)}.flag-icon-fo.flag-icon-squared{background-image:url(https://studio.builder.ai/fo.8b4db68d6e0717fe940e.svg)}.flag-icon-fr{background-image:url(https://studio.builder.ai/fr.81d43a151d8bc64145f2.svg)}.flag-icon-fr.flag-icon-squared{background-image:url(https://studio.builder.ai/fr.c88df3297cffe49852ae.svg)}.flag-icon-ga{background-image:url(https://studio.builder.ai/ga.4257c8ec8a129da794b2.svg)}.flag-icon-ga.flag-icon-squared{background-image:url(https://studio.builder.ai/ga.dec832634c40be902627.svg)}.flag-icon-gb{background-image:url(https://studio.builder.ai/gb.ba1c7f5df0dd4173c951.svg)}.flag-icon-gb.flag-icon-squared{background-image:url(https://studio.builder.ai/gb.35dbacd736781608964a.svg)}.flag-icon-gd{background-image:url(https://studio.builder.ai/gd.b446a44dff915db18869.svg)}.flag-icon-gd.flag-icon-squared{background-image:url(https://studio.builder.ai/gd.1b313417e54a6f4446ee.svg)}.flag-icon-ge{background-image:url(https://studio.builder.ai/ge.98cf9dc189b05e67103c.svg)}.flag-icon-ge.flag-icon-squared{background-image:url(https://studio.builder.ai/ge.7ccc29e2355cf25d55c5.svg)}.flag-icon-gf{background-image:url(https://studio.builder.ai/gf.695a47d62497dc584667.svg)}.flag-icon-gf.flag-icon-squared{background-image:url(https://studio.builder.ai/gf.74219f32e778ea33b181.svg)}.flag-icon-gg{background-image:url(https://studio.builder.ai/gg.6b23b5b1092e831766f9.svg)}.flag-icon-gg.flag-icon-squared{background-image:url(https://studio.builder.ai/gg.30f47622e942430014e8.svg)}.flag-icon-gh{background-image:url(https://studio.builder.ai/gh.d060e231aa94a98e78d9.svg)}.flag-icon-gh.flag-icon-squared{background-image:url(https://studio.builder.ai/gh.286f4413bbf14d667ea8.svg)}.flag-icon-gi{background-image:url(https://studio.builder.ai/gi.345b700f04babfed53e1.svg)}.flag-icon-gi.flag-icon-squared{background-image:url(https://studio.builder.ai/gi.e73af10429f00dc293ea.svg)}.flag-icon-gl{background-image:url(https://studio.builder.ai/gl.84ac5572fd0727fd850e.svg)}.flag-icon-gl.flag-icon-squared{background-image:url(https://studio.builder.ai/gl.68756f324152d0ada90c.svg)}.flag-icon-gm{background-image:url(https://studio.builder.ai/gm.cdfdf8bcb862134ab9fe.svg)}.flag-icon-gm.flag-icon-squared{background-image:url(https://studio.builder.ai/gm.65c86e0a8df296521d90.svg)}.flag-icon-gn{background-image:url(https://studio.builder.ai/gn.bf5b087387ce93eddfac.svg)}.flag-icon-gn.flag-icon-squared{background-image:url(https://studio.builder.ai/gn.7bf7a35a82ae814ed25d.svg)}.flag-icon-gp{background-image:url(https://studio.builder.ai/gp.092b6bf958cd4a1f76c9.svg)}.flag-icon-gp.flag-icon-squared{background-image:url(https://studio.builder.ai/gp.30b1d26cfe9f458611e2.svg)}.flag-icon-gq{background-image:url(https://studio.builder.ai/gq.c2cb1adba91b64af03bc.svg)}.flag-icon-gq.flag-icon-squared{background-image:url(https://studio.builder.ai/gq.89421f59da9e40d8cfcc.svg)}.flag-icon-gr{background-image:url(https://studio.builder.ai/gr.e2d0116790bdfda46fb4.svg)}.flag-icon-gr.flag-icon-squared{background-image:url(https://studio.builder.ai/gr.c51a52c416ea428fe41f.svg)}.flag-icon-gs{background-image:url(https://studio.builder.ai/gs.c19adcdd5855af626a3c.svg)}.flag-icon-gs.flag-icon-squared{background-image:url(https://studio.builder.ai/gs.a96857cd4e8cd95734f9.svg)}.flag-icon-gt{background-image:url(https://studio.builder.ai/gt.ccfc27d34052eec1eb6e.svg)}.flag-icon-gt.flag-icon-squared{background-image:url(https://studio.builder.ai/gt.3d87ccc4e82ef502f1dd.svg)}.flag-icon-gu{background-image:url(https://studio.builder.ai/gu.459831ea94ce2f15eede.svg)}.flag-icon-gu.flag-icon-squared{background-image:url(https://studio.builder.ai/gu.35820090ead0219b998c.svg)}.flag-icon-gw{background-image:url(https://studio.builder.ai/gw.f29eedfe431a60cae11e.svg)}.flag-icon-gw.flag-icon-squared{background-image:url(https://studio.builder.ai/gw.f647ba54d53db3f2e3a4.svg)}.flag-icon-gy{background-image:url(https://studio.builder.ai/gy.49a30b4ff82716f3aadd.svg)}.flag-icon-gy.flag-icon-squared{background-image:url(https://studio.builder.ai/gy.43c003e277ed5a4d0ca0.svg)}.flag-icon-hk{background-image:url(https://studio.builder.ai/hk.c0a93c089256c99bf337.svg)}.flag-icon-hk.flag-icon-squared{background-image:url(https://studio.builder.ai/hk.5a1122079f786b82c2ed.svg)}.flag-icon-hm{background-image:url(https://studio.builder.ai/hm.fdd5197f75474534c518.svg)}.flag-icon-hm.flag-icon-squared{background-image:url(https://studio.builder.ai/hm.8b4c33d4098f83d3cddd.svg)}.flag-icon-hn{background-image:url(https://studio.builder.ai/hn.f53ee3d65d19c9dd755e.svg)}.flag-icon-hn.flag-icon-squared{background-image:url(https://studio.builder.ai/hn.ebef2cd564ca07f12aa1.svg)}.flag-icon-hr{background-image:url(https://studio.builder.ai/hr.00a76e1b588a62b0fad9.svg)}.flag-icon-hr.flag-icon-squared{background-image:url(https://studio.builder.ai/hr.f3f2e25c45a219c68654.svg)}.flag-icon-ht{background-image:url(https://studio.builder.ai/ht.3af38bff509f443ef70e.svg)}.flag-icon-ht.flag-icon-squared{background-image:url(https://studio.builder.ai/ht.663996cf665e8ab764d5.svg)}.flag-icon-hu{background-image:url(https://studio.builder.ai/hu.bcbd277021f4a8f5a059.svg)}.flag-icon-hu.flag-icon-squared{background-image:url(https://studio.builder.ai/hu.7ae2a1f04ec537fbba4b.svg)}.flag-icon-id{background-image:url(https://studio.builder.ai/id.e2afd171e6a62816237b.svg)}.flag-icon-id.flag-icon-squared{background-image:url(https://studio.builder.ai/id.0b7fa609d99165dc5377.svg)}.flag-icon-ie{background-image:url(https://studio.builder.ai/ie.5ecf710f14d859cbceb6.svg)}.flag-icon-ie.flag-icon-squared{background-image:url(https://studio.builder.ai/ie.1b0ac4e772c2e62aef2f.svg)}.flag-icon-il{background-image:url(https://studio.builder.ai/il.4c70e23214e9da6a56eb.svg)}.flag-icon-il.flag-icon-squared{background-image:url(https://studio.builder.ai/il.3bc4ce048568d30c327f.svg)}.flag-icon-im{background-image:url(https://studio.builder.ai/im.b21ce587e66db16e0428.svg)}.flag-icon-im.flag-icon-squared{background-image:url(https://studio.builder.ai/im.d637f63b68f97839a27b.svg)}.flag-icon-in{background-image:url(https://studio.builder.ai/in.e5926cb75dcbb15638da.svg)}.flag-icon-in.flag-icon-squared{background-image:url(https://studio.builder.ai/in.e626d1bb4e16e732e1dd.svg)}.flag-icon-io{background-image:url(https://studio.builder.ai/io.e31ca9aa9209d9b76a0b.svg)}.flag-icon-io.flag-icon-squared{background-image:url(https://studio.builder.ai/io.c32d7f9e59460fb90af6.svg)}.flag-icon-iq{background-image:url(https://studio.builder.ai/iq.5cd51d2bbb7385580434.svg)}.flag-icon-iq.flag-icon-squared{background-image:url(https://studio.builder.ai/iq.e549011efede8b5ba38b.svg)}.flag-icon-ir{background-image:url(https://studio.builder.ai/ir.12e7432b428f8d631eb5.svg)}.flag-icon-ir.flag-icon-squared{background-image:url(https://studio.builder.ai/ir.c945dfdfaee26ad2861c.svg)}.flag-icon-is{background-image:url(https://studio.builder.ai/is.2dfa14d19684fbe061e4.svg)}.flag-icon-is.flag-icon-squared{background-image:url(https://studio.builder.ai/is.1842f1a952e8f0d4ca47.svg)}.flag-icon-it{background-image:url(https://studio.builder.ai/it.290f2fec799fabdf2a85.svg)}.flag-icon-it.flag-icon-squared{background-image:url(https://studio.builder.ai/it.9938f4b9588502f93b20.svg)}.flag-icon-je{background-image:url(https://studio.builder.ai/je.7a0b4850d933dbc21d75.svg)}.flag-icon-je.flag-icon-squared{background-image:url(https://studio.builder.ai/je.e1bb30f3c6be27ba0bc4.svg)}.flag-icon-jm{background-image:url(https://studio.builder.ai/jm.6bb96bbc99218d9f84f7.svg)}.flag-icon-jm.flag-icon-squared{background-image:url(https://studio.builder.ai/jm.74ccffca23e5a91356de.svg)}.flag-icon-jo{background-image:url(https://studio.builder.ai/jo.f41fe7d26b69dec06fef.svg)}.flag-icon-jo.flag-icon-squared{background-image:url(https://studio.builder.ai/jo.e678dae866ec74e6a939.svg)}.flag-icon-jp{background-image:url(https://studio.builder.ai/jp.19c631c1498ba5517cd5.svg)}.flag-icon-jp.flag-icon-squared{background-image:url(https://studio.builder.ai/jp.980c12c54fe225923434.svg)}.flag-icon-ke{background-image:url(https://studio.builder.ai/ke.74aaf58557811d8e79ab.svg)}.flag-icon-ke.flag-icon-squared{background-image:url(https://studio.builder.ai/ke.9ea890912ffd2f80e7a3.svg)}.flag-icon-kg{background-image:url(https://studio.builder.ai/kg.1fe994c1e99757dce023.svg)}.flag-icon-kg.flag-icon-squared{background-image:url(https://studio.builder.ai/kg.4ad89b3a703d225e1f6d.svg)}.flag-icon-kh{background-image:url(https://studio.builder.ai/kh.7b33804c913e2285c538.svg)}.flag-icon-kh.flag-icon-squared{background-image:url(https://studio.builder.ai/kh.695ec7a1a39090e600d5.svg)}.flag-icon-ki{background-image:url(https://studio.builder.ai/ki.de100d3095b62260166f.svg)}.flag-icon-ki.flag-icon-squared{background-image:url(https://studio.builder.ai/ki.32000b051bb6bb9ee785.svg)}.flag-icon-km{background-image:url(https://studio.builder.ai/km.93ef5e214ae093b8adc8.svg)}.flag-icon-km.flag-icon-squared{background-image:url(https://studio.builder.ai/km.4c4fa2a75b7c9360ac5f.svg)}.flag-icon-kn{background-image:url(https://studio.builder.ai/kn.a4e974e81853186f1522.svg)}.flag-icon-kn.flag-icon-squared{background-image:url(https://studio.builder.ai/kn.091a5508172f8eee28f2.svg)}.flag-icon-kp{background-image:url(https://studio.builder.ai/kp.8d10def41b377b1163c5.svg)}.flag-icon-kp.flag-icon-squared{background-image:url(https://studio.builder.ai/kp.2e79afa21a3e610e5551.svg)}.flag-icon-kr{background-image:url(https://studio.builder.ai/kr.939387c390531d01a687.svg)}.flag-icon-kr.flag-icon-squared{background-image:url(https://studio.builder.ai/kr.9406f22f1237e7e4059d.svg)}.flag-icon-kw{background-image:url(https://studio.builder.ai/kw.2dce482defe9d86d0596.svg)}.flag-icon-kw.flag-icon-squared{background-image:url(https://studio.builder.ai/kw.a3a60802b9df1ea679ac.svg)}.flag-icon-ky{background-image:url(https://studio.builder.ai/ky.ef8e18776eff1caf6b64.svg)}.flag-icon-ky.flag-icon-squared{background-image:url(https://studio.builder.ai/ky.c311ddba04238d23214d.svg)}.flag-icon-kz{background-image:url(https://studio.builder.ai/kz.7194851eb720d3fdb3ad.svg)}.flag-icon-kz.flag-icon-squared{background-image:url(https://studio.builder.ai/kz.f528d1705766032d8237.svg)}.flag-icon-la{background-image:url(https://studio.builder.ai/la.8d6ad26b7061bc058892.svg)}.flag-icon-la.flag-icon-squared{background-image:url(https://studio.builder.ai/la.80cf2b55ad4d86b51967.svg)}.flag-icon-lb{background-image:url(https://studio.builder.ai/lb.75479923a75562bb3dbe.svg)}.flag-icon-lb.flag-icon-squared{background-image:url(https://studio.builder.ai/lb.940cc75a55e4b18f510a.svg)}.flag-icon-lc{background-image:url(https://studio.builder.ai/lc.c6488de9494a4e151cc4.svg)}.flag-icon-lc.flag-icon-squared{background-image:url(https://studio.builder.ai/lc.0d361ba543e6cd2404e1.svg)}.flag-icon-li{background-image:url(https://studio.builder.ai/li.69a1d60ca3996705d91f.svg)}.flag-icon-li.flag-icon-squared{background-image:url(https://studio.builder.ai/li.572f90277090beca0d31.svg)}.flag-icon-lk{background-image:url(https://studio.builder.ai/lk.593078c9718a2a7a20d6.svg)}.flag-icon-lk.flag-icon-squared{background-image:url(https://studio.builder.ai/lk.93412c6fbb52d5bb809b.svg)}.flag-icon-lr{background-image:url(https://studio.builder.ai/lr.3a7c494b08f2d0e36a4f.svg)}.flag-icon-lr.flag-icon-squared{background-image:url(https://studio.builder.ai/lr.74dcec3fec3f73e24a0a.svg)}.flag-icon-ls{background-image:url(https://studio.builder.ai/ls.0de0f907e70c37b2e86e.svg)}.flag-icon-ls.flag-icon-squared{background-image:url(https://studio.builder.ai/ls.cddead61f832a10065e9.svg)}.flag-icon-lt{background-image:url(https://studio.builder.ai/lt.4c19d3a9f8cb00a45baa.svg)}.flag-icon-lt.flag-icon-squared{background-image:url(https://studio.builder.ai/lt.2ea82cfcd24756f9d718.svg)}.flag-icon-lu{background-image:url(https://studio.builder.ai/lu.adc8f77e99b53bd83b54.svg)}.flag-icon-lu.flag-icon-squared{background-image:url(https://studio.builder.ai/lu.b843e6436ac12254b9d2.svg)}.flag-icon-lv{background-image:url(https://studio.builder.ai/lv.9a5d132cec13c3e033f0.svg)}.flag-icon-lv.flag-icon-squared{background-image:url(https://studio.builder.ai/lv.2ce7f836390f846b1359.svg)}.flag-icon-ly{background-image:url(https://studio.builder.ai/ly.0ea8dfcec5cc820043a4.svg)}.flag-icon-ly.flag-icon-squared{background-image:url(https://studio.builder.ai/ly.9d867c1b9d3b76652858.svg)}.flag-icon-ma{background-image:url(https://studio.builder.ai/ma.363a4f79da72a6e74be0.svg)}.flag-icon-ma.flag-icon-squared{background-image:url(https://studio.builder.ai/ma.3b79aff17ae55b760333.svg)}.flag-icon-mc{background-image:url(https://studio.builder.ai/mc.a2634c60fa92f9ff20f0.svg)}.flag-icon-mc.flag-icon-squared{background-image:url(https://studio.builder.ai/mc.082fc1558b4cf726b613.svg)}.flag-icon-md{background-image:url(https://studio.builder.ai/md.4d08e48ef4cfb7c192dc.svg)}.flag-icon-md.flag-icon-squared{background-image:url(https://studio.builder.ai/md.efdfab01385b30e73986.svg)}.flag-icon-me{background-image:url(https://studio.builder.ai/me.0b785614513a0b99de04.svg)}.flag-icon-me.flag-icon-squared{background-image:url(https://studio.builder.ai/me.4c8b84af010134d56b90.svg)}.flag-icon-mf{background-image:url(https://studio.builder.ai/mf.2d96a80bd05aca4ef711.svg)}.flag-icon-mf.flag-icon-squared{background-image:url(https://studio.builder.ai/mf.c02a78fb2738ceb5eece.svg)}.flag-icon-mg{background-image:url(https://studio.builder.ai/mg.f9101073ea57c9f7664c.svg)}.flag-icon-mg.flag-icon-squared{background-image:url(https://studio.builder.ai/mg.5bdc14fe1aa439d1a0b7.svg)}.flag-icon-mh{background-image:url(https://studio.builder.ai/mh.c0b2e372c1a8cb36930e.svg)}.flag-icon-mh.flag-icon-squared{background-image:url(https://studio.builder.ai/mh.7ec670b4d72f8a614957.svg)}.flag-icon-mk{background-image:url(https://studio.builder.ai/mk.31ba11ec4d4cdae74ebc.svg)}.flag-icon-mk.flag-icon-squared{background-image:url(https://studio.builder.ai/mk.c370fe88a49ab3c18701.svg)}.flag-icon-ml{background-image:url(https://studio.builder.ai/ml.18083e46073cc9f5f58f.svg)}.flag-icon-ml.flag-icon-squared{background-image:url(https://studio.builder.ai/ml.d11c30638f3d7b1766dc.svg)}.flag-icon-mm{background-image:url(https://studio.builder.ai/mm.6f93c6d0ec04077b61c7.svg)}.flag-icon-mm.flag-icon-squared{background-image:url(https://studio.builder.ai/mm.7068544f07c5b683b67a.svg)}.flag-icon-mn{background-image:url(https://studio.builder.ai/mn.5e4557f7ed743f19592c.svg)}.flag-icon-mn.flag-icon-squared{background-image:url(https://studio.builder.ai/mn.291814d605941d58335f.svg)}.flag-icon-mo{background-image:url(https://studio.builder.ai/mo.ac9b1701934ac6845610.svg)}.flag-icon-mo.flag-icon-squared{background-image:url(https://studio.builder.ai/mo.8d4848888f2e8b825545.svg)}.flag-icon-mp{background-image:url(https://studio.builder.ai/mp.394b0c91d8212a6cb6db.svg)}.flag-icon-mp.flag-icon-squared{background-image:url(https://studio.builder.ai/mp.b0a5ed44db6410228f23.svg)}.flag-icon-mq{background-image:url(https://studio.builder.ai/mq.e82d6df9e99c87fb655b.svg)}.flag-icon-mq.flag-icon-squared{background-image:url(https://studio.builder.ai/mq.09c19f656772c8f93989.svg)}.flag-icon-mr{background-image:url(https://studio.builder.ai/mr.3642790a35ff100e55f7.svg)}.flag-icon-mr.flag-icon-squared{background-image:url(https://studio.builder.ai/mr.7211bfd49f97a5ae1253.svg)}.flag-icon-ms{background-image:url(https://studio.builder.ai/ms.9474f8cf128ce6813e2d.svg)}.flag-icon-ms.flag-icon-squared{background-image:url(https://studio.builder.ai/ms.8f7c204278ae1cdcd35c.svg)}.flag-icon-mt{background-image:url(https://studio.builder.ai/mt.c91049a111e0a4dc2611.svg)}.flag-icon-mt.flag-icon-squared{background-image:url(https://studio.builder.ai/mt.0c23ea353ac917d9e4d4.svg)}.flag-icon-mu{background-image:url(https://studio.builder.ai/mu.97beced41b168e88e8fb.svg)}.flag-icon-mu.flag-icon-squared{background-image:url(https://studio.builder.ai/mu.d7d71f034d81a7105373.svg)}.flag-icon-mv{background-image:url(https://studio.builder.ai/mv.0329f53cf8f786716fe4.svg)}.flag-icon-mv.flag-icon-squared{background-image:url(https://studio.builder.ai/mv.91b2c27c9c550f558607.svg)}.flag-icon-mw{background-image:url(https://studio.builder.ai/mw.b4d805efda655aef8b6e.svg)}.flag-icon-mw.flag-icon-squared{background-image:url(https://studio.builder.ai/mw.6807c4fdd0370b23d239.svg)}.flag-icon-mx{background-image:url(https://studio.builder.ai/mx.bc63d25be57acf721e56.svg)}.flag-icon-mx.flag-icon-squared{background-image:url(https://studio.builder.ai/mx.05c8d69783e68aaad2f4.svg)}.flag-icon-my{background-image:url(https://studio.builder.ai/my.0d298a9e4566332f8a84.svg)}.flag-icon-my.flag-icon-squared{background-image:url(https://studio.builder.ai/my.848fbf91865a8d191263.svg)}.flag-icon-mz{background-image:url(https://studio.builder.ai/mz.dac5f7ee4f2a02e79de2.svg)}.flag-icon-mz.flag-icon-squared{background-image:url(https://studio.builder.ai/mz.dcf8977ee74002921810.svg)}.flag-icon-na{background-image:url(https://studio.builder.ai/na.e241f81665d5aa3bcd02.svg)}.flag-icon-na.flag-icon-squared{background-image:url(https://studio.builder.ai/na.27bc2313a9535106015c.svg)}.flag-icon-nc{background-image:url(https://studio.builder.ai/nc.5681de45e8340741e312.svg)}.flag-icon-nc.flag-icon-squared{background-image:url(https://studio.builder.ai/nc.046cebb8a66efa64641c.svg)}.flag-icon-ne{background-image:url(https://studio.builder.ai/ne.6fd3ccdef1a91e8be5ae.svg)}.flag-icon-ne.flag-icon-squared{background-image:url(https://studio.builder.ai/ne.64f5ff142997ea42d42e.svg)}.flag-icon-nf{background-image:url(https://studio.builder.ai/nf.7a4f3d1b34fa49f5a098.svg)}.flag-icon-nf.flag-icon-squared{background-image:url(https://studio.builder.ai/nf.7c3216dcabd2a393fa48.svg)}.flag-icon-ng{background-image:url(https://studio.builder.ai/ng.b69ed1e58b69dcadbf0e.svg)}.flag-icon-ng.flag-icon-squared{background-image:url(https://studio.builder.ai/ng.caaf41205a6fde2a1853.svg)}.flag-icon-ni{background-image:url(https://studio.builder.ai/ni.d30c03773b8ce5412033.svg)}.flag-icon-ni.flag-icon-squared{background-image:url(https://studio.builder.ai/ni.52cfeebfb0f78f395c13.svg)}.flag-icon-nl{background-image:url(https://studio.builder.ai/nl.21eb77dcfa38c6d7bb81.svg)}.flag-icon-nl.flag-icon-squared{background-image:url(https://studio.builder.ai/nl.f9d570ec865ab2c1e9d4.svg)}.flag-icon-no{background-image:url(https://studio.builder.ai/no.6df96bb22557028a5f77.svg)}.flag-icon-no.flag-icon-squared{background-image:url(https://studio.builder.ai/no.266dbd6fc3e66414aa3c.svg)}.flag-icon-np{background-image:url(https://studio.builder.ai/np.ecc31e52fb6b958eb681.svg)}.flag-icon-np.flag-icon-squared{background-image:url(https://studio.builder.ai/np.f7885aa646996a2aa6e0.svg)}.flag-icon-nr{background-image:url(https://studio.builder.ai/nr.dcf2ea3a8e5dbf8a9b80.svg)}.flag-icon-nr.flag-icon-squared{background-image:url(https://studio.builder.ai/nr.1f7cfffb6cb01e5215ad.svg)}.flag-icon-nu{background-image:url(https://studio.builder.ai/nu.770e6779515b496ac3b6.svg)}.flag-icon-nu.flag-icon-squared{background-image:url(https://studio.builder.ai/nu.9deebec59d90dece17fc.svg)}.flag-icon-nz{background-image:url(https://studio.builder.ai/nz.4dedf09b8933ec6f4390.svg)}.flag-icon-nz.flag-icon-squared{background-image:url(https://studio.builder.ai/nz.37be84f4206a0eae405b.svg)}.flag-icon-om{background-image:url(https://studio.builder.ai/om.716feea54634c16f406a.svg)}.flag-icon-om.flag-icon-squared{background-image:url(https://studio.builder.ai/om.09e65f88432f6b938338.svg)}.flag-icon-pa{background-image:url(https://studio.builder.ai/pa.8788ab50de263793f74b.svg)}.flag-icon-pa.flag-icon-squared{background-image:url(https://studio.builder.ai/pa.69b3b90501ccfc42beff.svg)}.flag-icon-pe{background-image:url(https://studio.builder.ai/pe.9e2ec84ad461c170e9e5.svg)}.flag-icon-pe.flag-icon-squared{background-image:url(https://studio.builder.ai/pe.83c26459858b4334c435.svg)}.flag-icon-pf{background-image:url(https://studio.builder.ai/pf.296e94595f307817fc2b.svg)}.flag-icon-pf.flag-icon-squared{background-image:url(https://studio.builder.ai/pf.fbd548e641a7199e969d.svg)}.flag-icon-pg{background-image:url(https://studio.builder.ai/pg.dcb8c4ab032af81620bd.svg)}.flag-icon-pg.flag-icon-squared{background-image:url(https://studio.builder.ai/pg.9ebf0bb36bfe656e7aba.svg)}.flag-icon-ph{background-image:url(https://studio.builder.ai/ph.596b9b66d026fa222c2d.svg)}.flag-icon-ph.flag-icon-squared{background-image:url(https://studio.builder.ai/ph.374bb0d60bc777e60d0f.svg)}.flag-icon-pk{background-image:url(https://studio.builder.ai/pk.8f9276eb2e7dc3eac94d.svg)}.flag-icon-pk.flag-icon-squared{background-image:url(https://studio.builder.ai/pk.0e17f31b0f156316ef20.svg)}.flag-icon-pl{background-image:url(https://studio.builder.ai/pl.7ea4b5b2df865bf73b06.svg)}.flag-icon-pl.flag-icon-squared{background-image:url(https://studio.builder.ai/pl.9400273de5d060652ce7.svg)}.flag-icon-pm{background-image:url(https://studio.builder.ai/pm.c5a64f87b2370f6a2ae3.svg)}.flag-icon-pm.flag-icon-squared{background-image:url(https://studio.builder.ai/pm.7582c30f04bd66a4e73c.svg)}.flag-icon-pn{background-image:url(https://studio.builder.ai/pn.0911eddaa4bb5cbf54b8.svg)}.flag-icon-pn.flag-icon-squared{background-image:url(https://studio.builder.ai/pn.ab7259a94ec182c05827.svg)}.flag-icon-pr{background-image:url(https://studio.builder.ai/pr.7845ecd77b3b58e3c8a5.svg)}.flag-icon-pr.flag-icon-squared{background-image:url(https://studio.builder.ai/pr.836bcb814711de3da206.svg)}.flag-icon-ps{background-image:url(https://studio.builder.ai/ps.77489c5e7455703ed84f.svg)}.flag-icon-ps.flag-icon-squared{background-image:url(https://studio.builder.ai/ps.451101efffc43d2b1ae6.svg)}.flag-icon-pt{background-image:url(https://studio.builder.ai/pt.b89a5b80ca1a71c3b96a.svg)}.flag-icon-pt.flag-icon-squared{background-image:url(https://studio.builder.ai/pt.5697f2973616282e4c76.svg)}.flag-icon-pw{background-image:url(https://studio.builder.ai/pw.5f3d8d8e8473f6439a21.svg)}.flag-icon-pw.flag-icon-squared{background-image:url(https://studio.builder.ai/pw.666cd05f03955ea01aa5.svg)}.flag-icon-py{background-image:url(https://studio.builder.ai/py.51b0bef3321042c04717.svg)}.flag-icon-py.flag-icon-squared{background-image:url(https://studio.builder.ai/py.b19bb0ae9ad5d553a146.svg)}.flag-icon-qa{background-image:url(https://studio.builder.ai/qa.90240e607800ce7ed1bd.svg)}.flag-icon-qa.flag-icon-squared{background-image:url(https://studio.builder.ai/qa.c08921ec8cdc1b1a0e8e.svg)}.flag-icon-re{background-image:url(https://studio.builder.ai/re.f05b5f1673afe6db0760.svg)}.flag-icon-re.flag-icon-squared{background-image:url(https://studio.builder.ai/re.7e8577e98f035e765e59.svg)}.flag-icon-ro{background-image:url(https://studio.builder.ai/ro.ea966c3dc0adf3d08a00.svg)}.flag-icon-ro.flag-icon-squared{background-image:url(https://studio.builder.ai/ro.51182fc9671cbaa10989.svg)}.flag-icon-rs{background-image:url(https://studio.builder.ai/rs.51e6180ced2cf59fd51e.svg)}.flag-icon-rs.flag-icon-squared{background-image:url(https://studio.builder.ai/rs.3b67d7bed888271edff6.svg)}.flag-icon-ru{background-image:url(https://studio.builder.ai/ru.f1c2ba49b3ccc06ba58a.svg)}.flag-icon-ru.flag-icon-squared{background-image:url(https://studio.builder.ai/ru.f760036294e1fff52a9a.svg)}.flag-icon-rw{background-image:url(https://studio.builder.ai/rw.26854553b660fa5e4982.svg)}.flag-icon-rw.flag-icon-squared{background-image:url(https://studio.builder.ai/rw.02a8a07e06e4ae9c0122.svg)}.flag-icon-sa{background-image:url(https://studio.builder.ai/sa.b9a346574cdc8950dd34.svg)}.flag-icon-sa.flag-icon-squared{background-image:url(https://studio.builder.ai/sa.dbdc272cb217fd407ff8.svg)}.flag-icon-sb{background-image:url(https://studio.builder.ai/sb.2c405bb603253b6e2040.svg)}.flag-icon-sb.flag-icon-squared{background-image:url(https://studio.builder.ai/sb.00988e025b134db97443.svg)}.flag-icon-sc{background-image:url(https://studio.builder.ai/sc.9ba013463b785efeb6be.svg)}.flag-icon-sc.flag-icon-squared{background-image:url(https://studio.builder.ai/sc.8357ba15f90dbaaeec2a.svg)}.flag-icon-sd{background-image:url(https://studio.builder.ai/sd.090d0e106e0c7fd28b23.svg)}.flag-icon-sd.flag-icon-squared{background-image:url(https://studio.builder.ai/sd.cb3da007630d3b35d1ca.svg)}.flag-icon-se{background-image:url(https://studio.builder.ai/se.22333e71c0c3e3d8da11.svg)}.flag-icon-se.flag-icon-squared{background-image:url(https://studio.builder.ai/se.4984ae470ed69178af1d.svg)}.flag-icon-sg{background-image:url(https://studio.builder.ai/sg.e6a27ad3fc2dedabca8b.svg)}.flag-icon-sg.flag-icon-squared{background-image:url(https://studio.builder.ai/sg.9751741f84e6e5263a40.svg)}.flag-icon-sh{background-image:url(https://studio.builder.ai/sh.c5ab8c6e3ffc963e14fb.svg)}.flag-icon-sh.flag-icon-squared{background-image:url(https://studio.builder.ai/sh.acd7b6efcbb9ea9ca7e6.svg)}.flag-icon-si{background-image:url(https://studio.builder.ai/si.7f576d8798a8732afa46.svg)}.flag-icon-si.flag-icon-squared{background-image:url(https://studio.builder.ai/si.d38938fcbf4ff9430856.svg)}.flag-icon-sj{background-image:url(https://studio.builder.ai/sj.4952c9a6d03f7d9caa08.svg)}.flag-icon-sj.flag-icon-squared{background-image:url(https://studio.builder.ai/sj.bf11a7596686324ffe17.svg)}.flag-icon-sk{background-image:url(https://studio.builder.ai/sk.be58e557507f14689689.svg)}.flag-icon-sk.flag-icon-squared{background-image:url(https://studio.builder.ai/sk.563985765998ec7428e9.svg)}.flag-icon-sl{background-image:url(https://studio.builder.ai/sl.4fd17d63688a1b300bca.svg)}.flag-icon-sl.flag-icon-squared{background-image:url(https://studio.builder.ai/sl.f1772cd4436de4f4535a.svg)}.flag-icon-sm{background-image:url(https://studio.builder.ai/sm.7e23c95234800a7c7e1e.svg)}.flag-icon-sm.flag-icon-squared{background-image:url(https://studio.builder.ai/sm.b57f66050d777f87e0a5.svg)}.flag-icon-sn{background-image:url(https://studio.builder.ai/sn.1ce79520b54b680dcc8e.svg)}.flag-icon-sn.flag-icon-squared{background-image:url(https://studio.builder.ai/sn.a03bc309423c9052891a.svg)}.flag-icon-so{background-image:url(https://studio.builder.ai/so.d1a7d3e18523bf69f2eb.svg)}.flag-icon-so.flag-icon-squared{background-image:url(https://studio.builder.ai/so.34b037a702aae22a7534.svg)}.flag-icon-sr{background-image:url(https://studio.builder.ai/sr.690504905775fc1b1480.svg)}.flag-icon-sr.flag-icon-squared{background-image:url(https://studio.builder.ai/sr.4ee190817d3b7c7862ca.svg)}.flag-icon-ss{background-image:url(https://studio.builder.ai/ss.e4bf9bb42bd5d25190fe.svg)}.flag-icon-ss.flag-icon-squared{background-image:url(https://studio.builder.ai/ss.2ad5a2bbc138690704ad.svg)}.flag-icon-st{background-image:url(https://studio.builder.ai/st.72697a87cfc011963be4.svg)}.flag-icon-st.flag-icon-squared{background-image:url(https://studio.builder.ai/st.342a4d3c791c89ec3103.svg)}.flag-icon-sv{background-image:url(https://studio.builder.ai/sv.3bb132d79aef68d7fe41.svg)}.flag-icon-sv.flag-icon-squared{background-image:url(https://studio.builder.ai/sv.f4b3314001ea3a7cf1d0.svg)}.flag-icon-sx{background-image:url(https://studio.builder.ai/sx.aafb13f61b6688f41a14.svg)}.flag-icon-sx.flag-icon-squared{background-image:url(https://studio.builder.ai/sx.ce647f25cbbcdb00ed0d.svg)}.flag-icon-sy{background-image:url(https://studio.builder.ai/sy.6529aa17e46f775a3931.svg)}.flag-icon-sy.flag-icon-squared{background-image:url(https://studio.builder.ai/sy.9d13beb594ee208a6864.svg)}.flag-icon-sz{background-image:url(https://studio.builder.ai/sz.d62f5eab640be40355e8.svg)}.flag-icon-sz.flag-icon-squared{background-image:url(https://studio.builder.ai/sz.5d494168348fddfa3aeb.svg)}.flag-icon-tc{background-image:url(https://studio.builder.ai/tc.f4f865830e706c26ef44.svg)}.flag-icon-tc.flag-icon-squared{background-image:url(https://studio.builder.ai/tc.0d16f864a483488586df.svg)}.flag-icon-td{background-image:url(https://studio.builder.ai/td.230eddd3b5d97166b70e.svg)}.flag-icon-td.flag-icon-squared{background-image:url(https://studio.builder.ai/td.ad4b4469031fb72bd98f.svg)}.flag-icon-tf{background-image:url(https://studio.builder.ai/tf.cf4959c4339d5b123093.svg)}.flag-icon-tf.flag-icon-squared{background-image:url(https://studio.builder.ai/tf.aaea08de295f296f0bba.svg)}.flag-icon-tg{background-image:url(https://studio.builder.ai/tg.f97c4ebe662df8683fde.svg)}.flag-icon-tg.flag-icon-squared{background-image:url(https://studio.builder.ai/tg.4abbb52870d11bce293d.svg)}.flag-icon-th{background-image:url(https://studio.builder.ai/th.b6ade2beba225ed5f2b5.svg)}.flag-icon-th.flag-icon-squared{background-image:url(https://studio.builder.ai/th.2ca3db46e2b26412705d.svg)}.flag-icon-tj{background-image:url(https://studio.builder.ai/tj.b32f7c017787f0d8579b.svg)}.flag-icon-tj.flag-icon-squared{background-image:url(https://studio.builder.ai/tj.e97716cafb6e3b770d5b.svg)}.flag-icon-tk{background-image:url(https://studio.builder.ai/tk.54b9e3f941cb3083e2a3.svg)}.flag-icon-tk.flag-icon-squared{background-image:url(https://studio.builder.ai/tk.e3d850fb9644bf50d891.svg)}.flag-icon-tl{background-image:url(https://studio.builder.ai/tl.503b7926732b784efbed.svg)}.flag-icon-tl.flag-icon-squared{background-image:url(https://studio.builder.ai/tl.c7a146dc0d916983f8dd.svg)}.flag-icon-tm{background-image:url(https://studio.builder.ai/tm.6de6696b70775fd30f3b.svg)}.flag-icon-tm.flag-icon-squared{background-image:url(https://studio.builder.ai/tm.442986488503d5356e80.svg)}.flag-icon-tn{background-image:url(https://studio.builder.ai/tn.6cd8c9a453cd0fc5e761.svg)}.flag-icon-tn.flag-icon-squared{background-image:url(https://studio.builder.ai/tn.8b09464a7524dff3fa47.svg)}.flag-icon-to{background-image:url(https://studio.builder.ai/to.65dda6ec6f9719bbd784.svg)}.flag-icon-to.flag-icon-squared{background-image:url(https://studio.builder.ai/to.aaa24511e1160314531a.svg)}.flag-icon-tr{background-image:url(https://studio.builder.ai/tr.2880fc8e0e28f4a11a8d.svg)}.flag-icon-tr.flag-icon-squared{background-image:url(https://studio.builder.ai/tr.c3d773f3ebbea061e963.svg)}.flag-icon-tt{background-image:url(https://studio.builder.ai/tt.b9a6939e2ab09927d190.svg)}.flag-icon-tt.flag-icon-squared{background-image:url(https://studio.builder.ai/tt.4252a958aa98bb3ef5f7.svg)}.flag-icon-tv{background-image:url(https://studio.builder.ai/tv.99618ffc3d126b12802f.svg)}.flag-icon-tv.flag-icon-squared{background-image:url(https://studio.builder.ai/tv.c87adc622981a557f7a5.svg)}.flag-icon-tw{background-image:url(https://studio.builder.ai/tw.83324ef79fd96b77a609.svg)}.flag-icon-tw.flag-icon-squared{background-image:url(https://studio.builder.ai/tw.a72a85cb06aca393b4c6.svg)}.flag-icon-tz{background-image:url(https://studio.builder.ai/tz.2218434d34c055a29fdf.svg)}.flag-icon-tz.flag-icon-squared{background-image:url(https://studio.builder.ai/tz.20af2614818e325d953d.svg)}.flag-icon-ua{background-image:url(https://studio.builder.ai/ua.67a46bf793e26237ace0.svg)}.flag-icon-ua.flag-icon-squared{background-image:url(https://studio.builder.ai/ua.2dd397cb920452449aca.svg)}.flag-icon-ug{background-image:url(https://studio.builder.ai/ug.83f4207b3f42150d667b.svg)}.flag-icon-ug.flag-icon-squared{background-image:url(https://studio.builder.ai/ug.983dd591c56af488af96.svg)}.flag-icon-um{background-image:url(https://studio.builder.ai/um.0f5d59d436cb8d91444b.svg)}.flag-icon-um.flag-icon-squared{background-image:url(https://studio.builder.ai/um.c3e06b4d7dfec14653ce.svg)}.flag-icon-us{background-image:url(https://studio.builder.ai/us.3cc0d38b3e8d93132c90.svg)}.flag-icon-us.flag-icon-squared{background-image:url(https://studio.builder.ai/us.c95087e1a852cf730acc.svg)}.flag-icon-uy{background-image:url(https://studio.builder.ai/uy.4c3f85c5401c3a3875ee.svg)}.flag-icon-uy.flag-icon-squared{background-image:url(https://studio.builder.ai/uy.091841c8018480091fae.svg)}.flag-icon-uz{background-image:url(https://studio.builder.ai/uz.6e16292aee6b5262a693.svg)}.flag-icon-uz.flag-icon-squared{background-image:url(https://studio.builder.ai/uz.ba79d2974850ade2d036.svg)}.flag-icon-va{background-image:url(https://studio.builder.ai/va.6d6a5ae672030a7e351f.svg)}.flag-icon-va.flag-icon-squared{background-image:url(https://studio.builder.ai/va.555e01bd279c6bbc28c4.svg)}.flag-icon-vc{background-image:url(https://studio.builder.ai/vc.e19034240ae39be40a4c.svg)}.flag-icon-vc.flag-icon-squared{background-image:url(https://studio.builder.ai/vc.2614017538c99c0f2ea7.svg)}.flag-icon-ve{background-image:url(https://studio.builder.ai/ve.b8bb0477d02228d82ffb.svg)}.flag-icon-ve.flag-icon-squared{background-image:url(https://studio.builder.ai/ve.125ee9246eea1cb1b662.svg)}.flag-icon-vg{background-image:url(https://studio.builder.ai/vg.7bc5c83294392b4386af.svg)}.flag-icon-vg.flag-icon-squared{background-image:url(https://studio.builder.ai/vg.76c17dc332a16129789a.svg)}.flag-icon-vi{background-image:url(https://studio.builder.ai/vi.bad0002a368d6bca0956.svg)}.flag-icon-vi.flag-icon-squared{background-image:url(https://studio.builder.ai/vi.1ae3b627580608e32c99.svg)}.flag-icon-vn{background-image:url(https://studio.builder.ai/vn.2301f6f466f2e744e48a.svg)}.flag-icon-vn.flag-icon-squared{background-image:url(https://studio.builder.ai/vn.25540177a9e64be64b71.svg)}.flag-icon-vu{background-image:url(https://studio.builder.ai/vu.25acc79729c1d8a104b6.svg)}.flag-icon-vu.flag-icon-squared{background-image:url(https://studio.builder.ai/vu.87d69c1826cf7245c2d8.svg)}.flag-icon-wf{background-image:url(https://studio.builder.ai/wf.e9a373c6bcbf8ea5021f.svg)}.flag-icon-wf.flag-icon-squared{background-image:url(https://studio.builder.ai/wf.55c63880d97978216450.svg)}.flag-icon-ws{background-image:url(https://studio.builder.ai/ws.a6817aa95b8cdf652ba6.svg)}.flag-icon-ws.flag-icon-squared{background-image:url(https://studio.builder.ai/ws.81cbff3db85ab05a4ac8.svg)}.flag-icon-ye{background-image:url(https://studio.builder.ai/ye.f62afcddf3ac8b1dfd3e.svg)}.flag-icon-ye.flag-icon-squared{background-image:url(https://studio.builder.ai/ye.2289a38ef27f51f7e88a.svg)}.flag-icon-yt{background-image:url(https://studio.builder.ai/yt.5c77b04743aada260f6b.svg)}.flag-icon-yt.flag-icon-squared{background-image:url(https://studio.builder.ai/yt.bf9663aea16580e485d0.svg)}.flag-icon-za{background-image:url(https://studio.builder.ai/za.83099da26ad6804ed7a5.svg)}.flag-icon-za.flag-icon-squared{background-image:url(https://studio.builder.ai/za.3c71a2a22271a414dd3d.svg)}.flag-icon-zm{background-image:url(https://studio.builder.ai/zm.79a41234f024ca5ab0a9.svg)}.flag-icon-zm.flag-icon-squared{background-image:url(https://studio.builder.ai/zm.a303f51a36999e85ed3b.svg)}.flag-icon-zw{background-image:url(https://studio.builder.ai/zw.f5ceeff7d65d0b5e33b7.svg)}.flag-icon-zw.flag-icon-squared{background-image:url(https://studio.builder.ai/zw.2840e62aaca37d36b327.svg)}.flag-icon-es-ca{background-image:url(https://studio.builder.ai/es-ca.2b2d073d58c4747e322e.svg)}.flag-icon-es-ca.flag-icon-squared{background-image:url(https://studio.builder.ai/es-ca.a03129ff81e9f5633e75.svg)}.flag-icon-es-ga{background-image:url(https://studio.builder.ai/es-ga.23a30d01d4c6338e7f5c.svg)}.flag-icon-es-ga.flag-icon-squared{background-image:url(https://studio.builder.ai/es-ga.405f191245cb5d0085d7.svg)}.flag-icon-eu{background-image:url(https://studio.builder.ai/eu.db2e50ad0bf5ecccc0ca.svg)}.flag-icon-eu.flag-icon-squared{background-image:url(https://studio.builder.ai/eu.1019087b8a58ac24c4ea.svg)}.flag-icon-gb-eng{background-image:url(https://studio.builder.ai/gb-eng.1fa89df2764a3f107c34.svg)}.flag-icon-gb-eng.flag-icon-squared{background-image:url(https://studio.builder.ai/gb-eng.ebbd69accf16823ad684.svg)}.flag-icon-gb-nir{background-image:url(https://studio.builder.ai/gb-nir.8ad03581959bce8c3da0.svg)}.flag-icon-gb-nir.flag-icon-squared{background-image:url(https://studio.builder.ai/gb-nir.f9fcc604971f0e53b88d.svg)}.flag-icon-gb-sct{background-image:url(https://studio.builder.ai/gb-sct.4743f1b0f3ffe8d16ba5.svg)}.flag-icon-gb-sct.flag-icon-squared{background-image:url(https://studio.builder.ai/gb-sct.bea4865f11865ef56465.svg)}.flag-icon-gb-wls{background-image:url(https://studio.builder.ai/gb-wls.a69b6bb076d89808e064.svg)}.flag-icon-gb-wls.flag-icon-squared{background-image:url(https://studio.builder.ai/gb-wls.77f90d8e620af4d9604d.svg)}.flag-icon-un{background-image:url(https://studio.builder.ai/un.4c0a34afb0c02cd13b3d.svg)}.flag-icon-un.flag-icon-squared{background-image:url(https://studio.builder.ai/un.19c1ad320e901a90c0e3.svg)}.flag-icon-xk{background-image:url(https://studio.builder.ai/xk.12d1409638442c96c8b9.svg)}.flag-icon-xk.flag-icon-squared{background-image:url(https://studio.builder.ai/xk.48269c0b55c2532ccb76.svg)}.tailwind .hover\:bg-buildergreen-a5:hover{--tw-bg-opacity:1;background-color:rgb(0 200 83/var(--tw-bg-opacity))}.tailwind .hover\:to-bluegray-3:hover{--tw-gradient-to:#dfe0e6}.tailwind .focus\:border:focus{border-width:1px}.tailwind .focus\:border-gray-8:focus{--tw-border-opacity:1;border-color:rgb(89 89 89/var(--tw-border-opacity))}.tailwind .focus\:outline-none:focus{outline:2px solid transparent;outline-offset:2px}.tailwind .peer:checked~.peer-checked\:border-builderpurple-a2{--tw-border-opacity:1;border-color:rgb(179 136 255/var(--tw-border-opacity))}.tailwind .peer:checked~.peer-checked\:bg-builderpurple-a2{--tw-bg-opacity:1;background-color:rgb(179 136 255/var(--tw-bg-opacity))}.tailwind .peer:checked~.peer-checked\:bg-builderpurple-a5{--tw-bg-opacity:1;background-color:rgb(98 0 234/var(--tw-bg-opacity))}.tailwind .peer:checked~.peer-checked\:bg-opacity-10{--tw-bg-opacity:0.1}.tailwind .peer:checked~.peer-checked\:text-gray-1{--tw-text-opacity:1;color:rgb(255 255 255/var(--tw-text-opacity))}@media (min-width:320px){.tailwind .\32xs\:grid-cols-2{grid-template-columns:repeat(2,minmax(0,1fr))}.tailwind .\32xs\:flex-row{flex-direction:row}.tailwind .\32xs\:flex-nowrap{flex-wrap:nowrap}.tailwind .\32xs\:gap-0{gap:0}.tailwind .\32xs\:rounded-r-none{border-bottom-right-radius:0;border-top-right-radius:0}.tailwind .\32xs\:rounded-l-none{border-bottom-left-radius:0;border-top-left-radius:0}.tailwind .\32xs\:border-l-0{border-left-width:0}}@media (min-width:640px){.tailwind .sm\:max-w-\[90\%\]{max-width:90%}.tailwind .sm\:max-w-\[80\%\]{max-width:80%}.tailwind .sm\:grid-cols-3{grid-template-columns:repeat(3,minmax(0,1fr))}.tailwind .sm\:flex-row{flex-direction:row}.tailwind .sm\:gap-4{gap:1rem}}@media (min-width:1024px){.tailwind .lg\:mt-8{margin-top:2rem}.tailwind .lg\:text-2xl{font-size:1.75rem;letter-spacing:-.03em;line-height:2rem}}`;function pt(e){return ht(e)}var ba=(e,t,a,i,r)=>{if(!pt(e))return p``;if(ht(e))return fa(e,a,t,i,r)};function pa(e,t,a,i,r,s){let o=document.createElement("div");if(o.innerHTML=ba(t,i,a,r,s),e.appendChild(o),i){let n=e.querySelector("[name='CompanySize']");n&&n.removeAttribute("required");let c=e.querySelector('[data-form-step="about-your-idea"]');c&&c.remove();let h=e.querySelector("[data-what-best-describes-you-container]");h&&h.remove();let g=e.querySelector("[data-newsletter-container]");g&&g.remove();let x=e.querySelector("[name='Phone']");if(x&&x.removeAttribute("required"),new URL(window.location.href).pathname==="/events/uts-2023"){let b=e.querySelector("[name='CompanyName']");b&&b.removeAttribute("required")}}}var xe=[{name:"FirstName",ACID:"firstname"},{name:"LastName",ACID:"lastname"},{name:"CountryCode",ACID:"field[361]"},{name:"Phone",ACID:"phone"},{name:"Email",ACID:"email"},{name:"StageOfIdea",ACID:"field[357]"},{name:"ProductIdea",ACID:"field[364]"},{name:"CompanyName",ACID:"customer_account"},{name:"CompanySize",ACID:"field[365]"},{name:"WhatBestDescribesYou",ACID:"field[358]"},{name:"Budget",ACID:"field[359]"},{name:"Country",ACID:"field[355]"},{name:"BuilderAIRepresentative",ACID:"field[383]"},{name:"Stage",ACID:"field[389]"},{name:"UTMSource",ACID:"field[117]"},{name:"UTMCampaign",ACID:"field[119]"},{name:"UTMMedium",ACID:"field[121]"},{name:"UTMContent",ACID:"field[127]"},{name:"UTMTerm",ACID:"field[144]"},{name:"PageURL",ACID:"field[204]"},{name:"GCLID",ACID:"field[317]"},{name:"RedditCID"},{name:"FacebookClickID"},{name:"FacebookBrowserID"},{name:"GAClientID"},{name:"BuilderCookieID"},{name:"BuilderSessionID"},{name:"SegmentAnonymousID"},{name:"LinkedinClickID"},{name:"HubspotUserToken"},{name:"FormType",ACID:"field[349]"},{name:"StudioStoreAppType",ACID:"field[350]"},{name:"Referrer",ACID:"field[85]"},{name:"SegmentUserAnonymousID",ACID:"field[385]"},{name:"VWOCampaignID",ACID:"field[391]"},{name:"VWOCampaignName",ACID:"field[392]"},{name:"VWOVariationID",ACID:"field[393]"},{name:"VWOVariationName",ACID:"field[394]"},{name:"VWOTest",ACID:"field[395]"},{name:"FormRef",ACID:"field[445]"},{name:"RedirectURL",ACID:"field[446]"},{name:"NewsletterSignup",ACID:"field[441]"},{name:"AISummitCheckbox",ACID:""},{name:"AtEventBuilderAIRepresentative",ACID:"field[442]"},{name:"AtEventBuilderAIRepresentativeSFID",ACID:"field[443]"},{name:"Notes",ACID:"field[444]"},{name:"WhatBroughtYouToTheStand",ACID:""},{name:"AboutToReceiveADemoAtEvent",ACID:""},{name:"EventYouWillBeAttending",ACID:""},{name:"City",ACID:""},{name:"CityFromIPAddress",ACID:""},{name:"AppCategory",ACID:""},{name:"IndustryExperiment",ACID:""},{name:"ShouldAirIndiaBuildThisApp",ACID:"field[451]"},{name:"Funding",ACID:"field[452]"},{name:"StageOfBusiness",ACID:"field[455]"},{name:"ReferralCode",ACID:"field[456]"},{name:"FormBackend",ACID:"field[457]"},{name:"ExperianPhoneConfidenceLevel",ACID:"field[462]"},{name:"ExperianPhoneType",ACID:"field[463]"},{name:"ExperianEmailConfidenceLevel",ACID:"field[464]"},{name:"ExperianEmailConfidenceLevelVerbose",ACID:"field[465]"},{name:"AnnualRevenue",ACID:""}];function W(e){if(window.localStorage)try{let t=window.localStorage.getItem(e);return t===null&&(t=""),t}catch(t){return console.error(t),""}return""}var Vi=["B01","UTS","AISUMMIT","DAVOS2024PANELDISCUSSIONRSVP","STUDIO4WAITLIST","CODEGENWAITLIST","MENAInsurtechSummit2024AppathonInterest","Startup Grind Global Conference 2025"];function ht(e){for(let t of Vi)if(e===t)return!0;return!1}var pe=(e="e.g. John")=>{let t=L("FirstName");return p`
        <div data-form-element="FirstName">
            <label
                data-at-event-asterisk
                class="font-rubik text block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                First Name
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none focus:border-gray-8"
                type="text"
                id="${t}"
                name="FirstName"
                data-ac-name="firstname"
                placeholder="${e}"
                required
            />
        </div>
    `},he=(e="e.g. Doe")=>{let t=L("LastName");return p`
        <div data-form-element="LastName">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                Last Name
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8"
                type="text"
                id="${t}"
                name="LastName"
                data-ac-name="lastname"
                placeholder="${e}"
                required
            />
        </div>
    `},K=(e="name@company.com",t="Business Email")=>{let a=L("Email");return p`
        <div data-form-element="Email">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${a}"
            >
                ${t}
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8"
                type="email"
                id="${a}"
                name="Email"
                data-ac-name="email"
                placeholder="${e}"
                required
            />
        </div>
    `},Ki=e=>{let t="";for(let a of ga)t=t+p`<option
                data-country-name="${a.name}"
                data-country-code="${a.code}"
                data-country-ref="${a.ref}"
                value="+${a.code}"
            >
                +${a.code} ${a.name}
            </option>`,p`
            <li class="font-flex flex-row flex-nowrap gap-1">
                <span class="flag-icon flag-icon-squared flag-icon-${a.ref}"></span>
                ${a.name}
                <span class="font-rubik countryCode">+${a.code}</span>
            </li>
        `;return t};var Ve=e=>{let t=L("CountryCode");return p`
        <div data-form-element="CountryCode">
            <label class="font-rubik sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${t}">
                Country Code
            </label>
            <div class="inline-block relative w-full">
                <span class="flag-icon flag-icon-squared pointer-events-none absolute inset-y-0 inset-x-2"></span>
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded 2xs:rounded-r-none py-3 pl-8 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="CountryCode"
                    data-ac-name="field[361]"
                    id="${t}"
                    required
                >
                    ${Ki(e)}
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},Ke=()=>{let e=L("Phone");return p`
        <div data-form-element="Phone">
            <label
                class="font-rubik sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="grid-last-name"
            >
                Phone Number
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border-y border-x 2xs:border-l-0 border-bluegray-6 rounded 2xs:rounded-l-none py-3 px-4 leading-tight focus:outline-none  focus:border-gray-8 focus:border"
                type="tel"
                minlength="6"
                maxlength="80"
                id="${e}"
                name="Phone"
                data-ac-name="phone"
                required
                autocomplete="off"
            />
        </div>
    `},Yi=(e=!0)=>{let t=L("City");return p`
        <div data-form-element="City" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                City
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8"
                type="text"
                id="${t}"
                name="City"
                placeholder="Which city do you live in?"
                ${e?"required":""}
            />
        </div>
    `},Ji=(e=!0)=>{let t=L("CompanyName");return p`
        <div data-form-element="CompanyName" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                Name of business
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8"
                type="text"
                id="${t}"
                name="CompanyName"
                data-ac-name="customer_account"
                placeholder="If you have an existing business, enter its name"
                ${e?"required":""}
            />
        </div>
    `},ha=(e=!0)=>{let t=L("CompanyName");return p`
        <div data-form-element="CompanyName" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                Company (or project) name
            </label>
            <input
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8"
                type="text"
                id="${t}"
                name="CompanyName"
                data-ac-name="customer_account"
                placeholder="e.g. Company"
                ${e?"required":""}
            />
        </div>
    `},Qi=()=>{let e=L("CompanySize"),t=W("CompanySize"),a=(i,r)=>`<option ${t===i?"selected":""} value="${i}">${r}</option>`;return p`
        <div data-form-element="CompanySize" class="w-full">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                Company size
            </label>
            <div class="inline-block relative w-full">
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="CompanySize"
                    data-ac-name="field[365]"
                    id="${e}"
                    required
                >
                    <option ${t?"":"selected"}></option>
                    ${a("Self-employed","Self-employed")} ${a("1-10 employees","1 - 10")}
                    ${a("11-50 employees","11 - 50")} ${a("51-200 employees","51 - 200")}
                    ${a("201-500 employees","201 - 500")} ${a("501-1000 employees","501 - 1000")}
                    ${a("1001-5000 employees","1001+")}

                    <!--
                    <option value="Self-employed">Self-employed</option>
                    <option value="1-10 employees">1-10</option>
                    <option value="11-50 employees">11-50</option>
                    <option value="51-200 employees">51-200</option>
                    <option value="201-500 employees">201-500</option>
                    <option value="501-1000 employees">501-1000</option>
                    <option value="1001-5000 employees">1001-5000</option>
                    <option value="5001-10,000 employees">5001-10,000</option>
                    <option value="10,001+ employees">10,001+</option>
                    -->
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},Se=()=>{let e=L("WhereDidYouHearAboutUs");return p`
        <div data-form-element="WhereDidYouHearAboutUs" class="w-full">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                How did you first hear about us?
            </label>
            <div class="inline-block relative w-full">
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="WhereDidYouHearAboutUs"
                    id="${e}"
                    required
                >
                    <option selected></option>
                    <option value="Google/Bing Search">Google/Bing Search</option>
                    <option value="Linkedin">Linkedin</option>
                    <option value="Instagram/Facebook">Instagram/Facebook</option>
                    <option value="Bark">Bark</option>
                    <option value="Colleague/Friend">Colleague/Friend</option>
                    <option value="Event/Webinar">Event/Webinar</option>
                    <option value="Brands ads">Brand ads (Billboards, Print ad, TV, etc.)</option>
                    <option value="Media/Press">Media/Press</option>
                    <option value="Review sites">Review sites (G2, Capterra, etc)</option>
                    <option value="Other">Other</option>
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},Ye=()=>p`
        <div class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2">Job title</span>
            <!-- grid grid-cols-1 2xs:grid-cols-2 sm:grid-cols-3 -->
            <div class="mt-2" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(162px, 1fr));">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="Solo entrepreneur"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Entrepreneur</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="Manager"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Manager</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="Director"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Director</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="CEO"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">C-Level</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="Student"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Student</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="WhatBestDescribesYou"
                            value="Other"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Other</span>
                    </label>
                </div>
            </div>
        </div>
    `;var Zi=()=>p`
        <div data-form-element="NewsletterSignup" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >Interested in our monthly email newsletter?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="form-control font-rubik inline-flex items-start cursor-pointer">
                        <input
                            name="NewsletterSignup"
                            type="checkbox"
                            class="form-checkbox h-6 w-6 accent-builderpurple-a5 bg-gray-1 cursor-pointer"
                        />
                        <span class="ml-3 font-rubik text-lg cursor-pointer text-gray-10 text-left"
                            >I would like to receive the newsletter</span
                        >
                    </label>
                </div>
            </div>
        </div>
    `;var Xi=()=>p`
        <div data-form-element="AISummitCheckbox" class="font-rubik block">
            <div class="mt-2">
                <div class="mt-1">
                    <label class="form-control font-rubik inline-flex items-start cursor-pointer">
                        <input
                            name="AISummitCheckbox"
                            type="checkbox"
                            class="form-checkbox h-6 w-6 accent-builderpurple-a5 bg-gray-1 cursor-pointer"
                        />
                        <span class="ml-3 font-rubik text-lg cursor-pointer text-gray-10 text-left"
                            >Yes, I’m interested in artificial intelligence and happy for Builder.ai to contact me about
                            it.</span
                        >
                    </label>
                </div>
            </div>
        </div>
    `,Je=()=>p`
        <div data-form-element="StageOfIdea" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >Stage of your idea</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="I don&#039;t yet have an idea"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I don&#039;t yet have an idea</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Just exploring - need more info"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Just exploring and need more information</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Need help picking features"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >I have an idea but I'm not sure where to start</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Ready to build now"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I'm ready to build my idea now</span>
                    </label>
                </div>
            </div>
        </div>
    `,vt=()=>p`
        <div data-form-element="StageOfIdea" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >Stage of your idea</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Ready to build now"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Ready to build now</span>
                    </label>
                </div>

                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Need help picking features"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Need help picking features</span>
                    </label>
                </div>

                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Just exploring - need more info"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Just exploring and need more information</span
                        >
                    </label>
                </div>

                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="I don&#039;t yet have an idea"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I don’t want a website or an app</span>
                    </label>
                </div>
            </div>
        </div>
    `,ka=()=>p`
        <div data-form-element="StageOfIdea" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >How can we help?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Get a prototype or proof of concept"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Get a prototype or proof of concept</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Build a new app"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Build a new app</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Solve an internal business problem"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Solve an internal business problem</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Other"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Other</span>
                    </label>
                </div>
            </div>
        </div>
    `,wa=()=>p`
        <div data-form-element="StageOfIdea" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >How can we help?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Get a prototype or proof of concept"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Get a prototype or proof of concept</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Build new software"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Build new software</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Solve an internal business problem"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Solve an internal business problem</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Replace or update existing software"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Replace or update existing software</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfIdea"
                            value="Other"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Other</span>
                    </label>
                </div>
            </div>
        </div>
    `;var va=()=>{let e=L("ProductIdea");return p`
        <div data-form-element="ProductIdea" style="display: none;">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                What is your product idea?
            </label>
            <div class="inline-block relative w-full">
                <textarea
                    style="height: 100px"
                    id="${e}"
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="ProductIdea"
                    data-ac-name="field[364]"
                    placeholder="I want to build an app or website like..."
                ></textarea>
            </div>
        </div>
    `},eo=e=>{let t="";for(let a of e)t=t+p`<option value="${a.email}">${a.email}</option>`;return t},to=e=>{let t=L("AtEventBuilderAIRepresentative");return p`
        <div data-form-element="AtEventBuilderAIRepresentative" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                Builder.ai representative
            </label>
            <div class="inline-block relative w-full">
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="AtEventBuilderAIRepresentative"
                    data-ac-name="field[442]"
                    id="${t}"
                >
                    <option selected></option>
                    ${eo(e)}
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},ao=()=>{let e=L("AboutToReceiveADemoAtEvent");return p`
        <div data-form-element="AboutToReceiveADemoAtEvent" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${e}"
            >
                Are they about to receive a demo at the event?
            </label>
            <div class="inline-block relative w-full">
                <select
                    required
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="AboutToReceiveADemoAtEvent"
                    data-ac-name="field[442]"
                    id="${e}"
                >
                    <option selected></option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},io=()=>{let e=new URL(window.location.href),t=M&&e.searchParams.get("event")==="msft-round-table-event-2024---hyderabad",a=L("WhatBroughtYouToTheStand");return p`
        <div data-form-element="WhatBroughtYouToTheStand" class="w-full">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${a}"
            >
                What brought you to the stand?
            </label>
            <div class="inline-block relative w-full">
                <select
                    required
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="WhatBroughtYouToTheStand"
                    data-ac-name="field[442]"
                    id="${a}"
                >
                    <option ${t?"":"selected"}></option>
                    <option value="Free coffee">Free coffee</option>
                    <option value="Master class session">Master class session</option>
                    <option value="Have a need to build an app">Have a need to build an app</option>
                    <option value="Wanted to find out more about building an app">
                        Wanted to find out more about building an app
                    </option>
                    <option value="Exploring partnerships">Exploring partnerships</option>
                    <option value="The stand looked cool">The stand looked cool</option>
                    <option value="I got dragged in by a Builder team member">
                        I got dragged in by a Builder team member
                    </option>
                    <option value="Guest Invite" ${t?"selected":""}>Guest Invite</option>
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},oo=e=>{let t=L("EventYouWillBeAttending"),a=new Date,i=!1,r=!1,s=e?6048e5:0,o=(c,h,g)=>{if(a>new Date(Number(new Date(c))+s))return"";r=!0;let x=se===h.trim().toLowerCase().replace(/ +/g,"-");return x&&(i=!0),`<option value="${h}" ${x?"selected":""}>${g}</option>`},n=`
    ${o("09/21/2023","TechCrunch Disrupt 2023","Sep 19-21 TechCrunch Disrupt")}
    ${o("09/23/2023","TechSparks 2023","Sep 21-23 Techsparks")}
    ${o("10/13/2023","Cloud Expo Asia 2023","Oct 11-12 Cloud Expo Asia")}
    ${o("10/21/2023","GITEX GLOBAL 2023","Oct 16-20 GITEX GLOBAL")}
    ${e?o("10/21/2023","GITEX GLOBAL 2023 (Etisalat Stand)","Oct 16-20 GITEX GLOBAL (Etisalat Stand)"):""}
    ${o("11/17/2023","Web Summit 2023","Nov 14-16 Web Summit")}
    ${o("11/17/2023","Black Hat MEA 2023","Nov 14-16 Black Hat")}
    ${o("11/19/2023","Huddle Global 2023","Nov 17-18 Huddle Global")}
    ${o("11/24/2023","London Business Show 2023","Nov 22-23 The Business Show")}
    ${o("12/09/2023","DATE 2023","Nov 23-08 DATE 2023")}
    ${o("12/01/2023","YourStory Techsparks 2023","Nov 29-30 YourStory Techsparks")}
    ${o("12/02/2023","Bengaluru Tech Summit 2023","Nov 29 - Dec 1 Bengaluru Tech Summit")}
    ${o("12/04/2023","FitExpo 2023","Dec 01-03 FitExpo")}
    ${o("01/20/2024","Davos 2024","Jan 15-19 World Economic Forum")}
    ${o("01/20/2024","Convergence India 2024","Jan 17-19 Convergence India")}
    ${o("01/22/2024","WeWork Labs Jumpstart 2024","Jan 20-21 WeWork Labs Jumpstart India 2024")}
    ${o("01/26/2024","Zurich Ai Event","Jan 25 Zurich Ai Event")}
    ${o("02/01/2024","Envision Mumbai 2024","Jan 31 Envision Mumbai")}
    ${o("02/24/2024","Gulfood2024","Feb 19-23 Gulfood2024")}
    ${o("02/25/2024","Venator 2024","Feb 24 Venator 2024")}
    ${o("03/01/2024","Web Summit Qatar 2024","Feb 26-29 Web Summit Qatar 2024")}
    ${o("02/29/2024","India Digital Summit","Feb 27-28 India Digital Summit")}
    ${o("03/02/2024","YourStory TechSparks Mumbai","Feb 29 - Mar 1 YourStory TechSparks Mumbai")}
    ${o("03/08/2024","LEAP Riyadh 2024","Mar 4-7 LEAP Riyadh 2024")}
    ${o("03/13/2024","Envision Paris 2024","Mar 12 Envision Paris")}
    ${o("03/21/2024","Startup Mahakumbh 2024","Mar 18-20 Startup Mahakumbh 2024")}
    ${o("04/25/2024","Startup Grind Global Conference 2024","Apr 22-24 Startup Grind Global Conference")}
    ${o("05/09/2024","Milken Global Conference 2024","Milken Global Conference")}
    ${o("05/14/2024","MENA Insurtech Summit 2024","MENA Insurtech Summit")}
    ${o("05/25/2024","Future of X","May 22-24 Future of X")}
    ${o("05/26/2024","VivaTech Paris 2024","May 22-25 VivaTech Paris 2024")}
    ${o("05/24/2024","Digital Transformation Summit Philippines 2024","May 23 Digital Transformation Summit Philippines")}
    ${o("06/01/2024","GITEX Africa 2024","May 29-31 GITEX Africa 2024")}
    ${o("06/22/2024","TNW Conference 2024","Jun 20-21 TNW Conference 2024")}
    ${o("08/10/2024","Techsauce Global Summit","7-9 Aug Techsauce Global Summit")}
    ${o("08/16/2024","TECHSPO Sydney 2024","Aug 14-15 TECHSPO Sydney 2024")}
    ${o("08/22/2024","TECHSPO Melbourne 2024","Aug 20-21 TECHSPO Melbourne 2024")}
    ${o("08/24/2024","UTS NY 2024","Aug 22-23 UTS NY 2024")}
    ${o("09/27/2024","TECHSPO Delhi 2024","Sep 25-26 TECHSPO Delhi 2024")}
    ${o("08/29/2024","MSFT Round Table Event 2024 - Hyderabad","Aug 28 MSFT Round Table Event 2024 - Hyderabad")}
    ${o("09/14/2024","CIO 100 Symposium","Sep 11-13 CIO 100 Symposium & Awards September")}
    ${o("09/28/2024","SMC Sales and Tech Summit Asia","Sep 24-27 SMC Sales and Tech Summit Asia")}
    ${o("09/29/2024","Yourstory Techsparks 2024","Sep 26-28 Yourstory Techsparks")}
    ${o("10/11/2024","Cloud Expo Asia 2024","Oct 9-10 Cloud Expo Asia")}
    ${o("10/19/2024","GITEX GLOBAL 2024","Oct 14-18 Gitex Global")}
    ${o("10/11/2024","The Business Show LA 2024","Oct 9-10 The Business Show LA")}
    ${o("10/31/2024","TechCrunch Disrupt 2024","Oct 28-30 TechCrunch Disrupt 2024")}
    ${o("11/15/2024","Web Summit Lisbon 2024","Nov 11-14 Web Summit Lisbon 2024")}
    ${o("12/11/2024","Eagle Labs Dec24","10 Dec Eagle Labs")}
    ${o("01/31/2025","microsoft-ai-tour-newyork","Jan 30 Microsoft AI Tour New York")}
    ${o("02/07/2025","AI Everything Global 2025","Feb 05-06 AI Everything Global")}
    ${o("02/13/2025","LEAP Riyadh 2025","Feb 09-12 LEAP Riyadh 2025")}
    ${o("02/14/2025","Crayon Connect- Sydney 2025","Feb 11-13 Crayon Connect Sydney")}
    ${o("02/26/2025","Application Strategy Summit- Sydney 20","Feb 25 Application Strategy Summit Sydney")}
  ${o("02/27/2025","Web Summit- Qatar","Feb 23-26 Web Summit Qatar")}
`;return r?p`
        <div data-form-element="EventYouWillBeAttending" class="w-full mb-4">
            <label
                data-at-event-asterisk
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${t}"
            >
                ${e?"Event":"Event you'll be attending"}
            </label>
            <div class="inline-block relative w-full">
                <select
                    required
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="EventYouWillBeAttending"
                    data-ac-name="field[442]"
                    id="${t}"
                >
                    <option ${i?"":"selected"}></option>
                    ${n}
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `:""},ro=()=>{let e=L("Notes");return p`
        <div data-form-element="Notes">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                Builder.ai representative notes
            </label>
            <div class="inline-block relative w-full">
                <textarea
                    style="height: 150px"
                    id="${e}"
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="Notes"
                    data-ac-name="field[444]"
                    placeholder=""
                ></textarea>
            </div>
        </div>
    `},yt=()=>{let e=L("ProductIdea");return p`
        <div data-form-element="ProductIdea">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                Can you tell us more (optional)
            </label>
            <div class="inline-block relative w-full">
                <textarea
                    style="height: 80px"
                    id="${e}"
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="ProductIdea"
                    placeholder=""
                ></textarea>
            </div>
        </div>
    `};var kt=()=>p`
        <div data-form-element="StageOfBusiness" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >Which best describes your business?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="I have an established business"
                            data-CompanyName="hide"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I have an established business</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="Startup or entrepreneur with backing, investment or funding"
                            data-CompanyName="hide"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Startup or entrepreneur with backing, investment or funding</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="Entrepreneur without funding but with a great idea"
                            data-CompanyName="show"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >Entrepreneur without funding but with a great idea</span
                        >
                    </label>
                </div>
            </div>
        </div>
    `,wt=()=>p`
        <div data-form-element="StageOfBusiness" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >Stage of your business</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="I don't have a business"
                            data-CompanyName="hide"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I don't have a business</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="Starting a new business"
                            data-CompanyName="hide"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Starting a new business</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="I want a website/app for my business"
                            data-CompanyName="show"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >I want a website/app for my business</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="I sell on marketplaces and want my own website/app"
                            data-CompanyName="show"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >I sell on marketplaces and want my own website/app</span
                        >
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="StageOfBusiness"
                            value="I am exploring and need more information"
                            data-CompanyName="show"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10"
                            >I am exploring and need more information</span
                        >
                    </label>
                </div>
            </div>
        </div>
    `,_a=()=>{let e=L("OtherAppCategory");return p`
        <div data-form-element="OtherAppCategory" style="display: none;">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${e}">
                Tell us a bit about your software project
            </label>
            <div class="inline-block relative w-full">
                <textarea
                    style="height: 100px"
                    id="${e}"
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="OtherAppCategory"
                    placeholder=""
                ></textarea>
            </div>
        </div>
    `},xa=()=>{let e=W("AppCategory"),t=(i,r)=>`<option ${e===i?"selected":""} value="${i}">${r}</option>`,a=L("AppCategory");return p`
        <div data-form-element="AppCategory" class="w-full">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${a}">
                What industry best classifies your business?
            </label>
            <div class="inline-block relative w-full">
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="AppCategory"
                    id="${a}"
                    required
                >
                    <option ${e?"":"selected"}></option>
                    ${t("Business & finance","Business & finance")}
                    ${t("Education","Education")}
                    ${t("Entertainment & music","Entertainment & music")}
                    ${t("Events","Events")}
                    ${t("Food & drink","Food & drink")}
                    ${t("Health & fitness","Health & fitness")}
                    ${t("Lifestyle","Lifestyle")}
                    ${t("Medical","Medical")}
                    ${t("Navigation","Navigation")}
                    ${t("News","News")}
                    ${t("Photo & video","Photo & video")}
                    ${t("Productivity","Productivity")}
                    ${t("Retail & e-commerce","Retail & ecommerce")}
                    ${t("Shopping","Shopping")}
                    ${t("Social","Social Media")}
                    ${t("Sports","Sports")}
                    ${t("Travel","Travel")}
                    ${t("Utilities","Utilities")}
                    ${t("Gaming (not available)","Gaming")}
                    ${t("Crypto","Crypto")} ${t("Other","Other")}
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},_t=()=>{let e=W("IndustryExperiment"),t=(i,r)=>`<option ${e===i?"selected":""} value="${i}">${r}</option>`,a=L("IndustryExperiment");return p`
        <div data-form-element="IndustryExperiment" class="w-full">
            <label class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2" for="${a}">
                What industry best classifies your business?
            </label>
            <div class="inline-block relative w-full">
                <select
                    class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                    name="IndustryExperiment"
                    id="${a}"
                    required
                >
                    <option ${e?"":"selected"}></option>
                    ${t("Construction","Construction")}
                    ${t("Education","Education")}
                    ${t("Energy & Utilities","Energy & Utilities")}
                    ${t("Financial Services","Financial Services")}
                    ${t("Government & Non-Profit","Government & Non-Profit")}
                    ${t("Healthcare","Healthcare")}
                    ${t("Hospitality","Hospitality")}
                    ${t("IT & Telecom","IT & Telecom")}
                    ${t("Manufacturing","Manufacturing")}
                    ${t("Media & Entertainment","Media & Entertainment")}
                    ${t("Professional Services","Professional Services")}
                    ${t("Retail & Wholesale","Retail & Wholesale")}
                    ${t("Transportation & Logistics","Transportation & Logistics")}
                    ${t("Other","Other")}
                </select>
                <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                    </svg>
                </div>
            </div>
        </div>
    `},Qe=()=>{let e=[{US:["Less than \u20B9400,000 (templated build)"],IN:["Less than \u20B9400,000 (templated build)"],GB:["Less than \u20B9400,000 (templated build)"],AE:["Less than \u20B9400,000 (templated build)"]},{US:["More than \u20B9400,000 (customised build)"],IN:["More than \u20B9400,000 (customised build)"],GB:["More than \u20B9400,000 (customised build)"],AE:["More than \u20B9400,000 (customised build)"]},{US:["I don\u2019t have any budget"],IN:["I don\u2019t have any budget"],GB:["I don\u2019t have any budget"],AE:["I don\u2019t have any budget"]},{US:["I need guidance from a professional"],IN:["I need guidance from a professional"],GB:["I need guidance from a professional"],AE:["I need guidance from a professional"]}],t="US";try{let r=document.getElementById("context");if(r){let s=JSON.parse(r.innerText);s&&s.country&&(t=s.country)}}catch{}["US","IN","GB","AE"].includes(t)===!1&&(t="US"),e=[{US:["Less than $5000","Less than $5,000"],IN:["Less than \u20B9400,000","Less than $5,000"],GB:["Less than \xA35000","Less than $5,000"],AE:["Less than AED 18,000","Less than $5,000"]},{US:["$5000 to $25,000","$5,000 to $25,000"],IN:["\u20B9400,000 to \u20B92,000,000","$5,000 to $25,000"],GB:["\xA35000 to \xA320,000","$5,000 to $25,000"],AE:["AED 18,000 to AED 90,000","$5,000 to $25,000"]},{US:["$25,000 to $50,000","$25,000 to $50,000"],IN:["\u20B92,000,000 to \u20B94,000,000","$25,000 to $50,000"],GB:["\xA320,000 to \xA340,000","$25,000 to $50,000"],AE:["AED 90,000 to AED 180,000","$25,000 to $50,000"]},{US:["Over $50,000","$50,0000+"],IN:["Over \u20B94,000,000","$50,0000+"],GB:["Over \xA340,000","$50,0000+"],AE:["Over AED 180,000","$50,0000+"]},{US:["I need guidance from a professional"],IN:["I need guidance from a professional"],GB:["I need guidance from a professional"],AE:["I need guidance from a professional"]}];let a="HowMuchDoYouExpectToSpend",i=W("QuizExpectedBudget");return p`
        <div data-form-element="${a}" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >What is your budget?</span
            >
            <div class="mt-2">
                ${[0,1,2,3,4,5,6,7,8,9].slice(0,e.length).map(r=>{if(e.length<r+1)return;let s=e[r][t];if(s[0]===""||!s[0])return;let o=s.length>1?s[1]:s[0],n=!1,c=e[r].US[0];return i&&(["$0","I'm looking for free solution"].includes(i)&&c==="I'm looking for free solution"||["$5000","$10000","$15000","$5000 to $25,000"].includes(i)&&c==="$5000 to $25,000"||["$20000","$25000","$25,000 to $50,000"].includes(i)&&c==="$25,000 to $50,000")&&(n=!0),`<div class="mt-1">
                <label class="font-rubik form-control cursor-pointer">
                    <input
                        required
                        type="radio"
                        class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                        name="${a}"
                        value="${o}"
                        ${n?"checked":""}
                    />
                    <span class="ml-3 text-lg cursor-pointer text-gray-10"
                        >${s[0]}</span
                    >
                </label>
            </div>`}).join(`
`)}
            </div>
        </div>
    `},xt=()=>{let e="US";try{let i=document.getElementById("context");if(i){let r=JSON.parse(i.innerText);r&&r.country&&(e=r.country)}}catch{}["US","IN","GB","AE"].includes(e)===!1&&(e="US");let t=[{US:["Less than $500k","0 - $500k"],IN:["Less than $500k (\u20B94 cr)","0 - $500k"],GB:["Less than $500k (\xA3400k)","0 - $500k"],AE:["Less than $500k (1.8m AED)","0 - $500k"]},{US:["$500k \u2013 $10M","$500k \u2013 $10M"],IN:["$500k \u2013 $10M (\u20B94 cr \u2013 \u20B984 cr)","$500k \u2013 $10M"],GB:["$500k \u2013 $10M (\xA3400k \u2013 \xA38m)","$500k \u2013 $10M"],AE:["$500k \u2013 $10M (1.8m \u2013 3.6m AED)","$500k \u2013 $10M"]},{US:["$10M \u2013 $100M","$10M \u2013 $100M"],IN:["$10M \u2013 $100M (\u20B984 cr \u2013 \u20B9840 cr)","$10M \u2013 $100M"],GB:["$10M \u2013 $100M (\xA38m \u2013 \xA380m)","$10M \u2013 $100M"],AE:["$10M \u2013 $100M (3.6 \u2013 36m AED)","$10M \u2013 $100M"]},{US:["$100M \u2013 $1B","$100M \u2013 $1B"],IN:["$100M \u2013 $1B (\u20B9840 cr \u2013 \u20B98400 cr)","$100M \u2013 $1B"],GB:["$100M \u2013 $1B (\xA380m \u2013 \xA3800m)","$100M \u2013 $1B"],AE:["$100M \u2013 $1B (36m \u2013 360m AED)","$100M \u2013 $1B"]},{US:["More than $1B",">$1B"],IN:["More than $1B (\u20B98400 cr)",">$1B"],GB:["More than $1B (\xA3800m)",">$1B"],AE:["More than $1B (360m AED)",">$1B"]}],a=W("AnnualRevenue");return p`
        <div data-form-element="AnnualRevenue" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >What is your Annual Revenue?</span
            >
            <div class="mt-2">
                ${[0,1,2,3,4,5,6,7,8,9].slice(0,t.length).map(i=>{if(t.length<i+1)return;let r=t[i][e];return r[0]===""||!r[0]?void 0:`<div class="mt-1">
                <label class="font-rubik form-control cursor-pointer">
                    <input
                        required
                        type="radio"
                        class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                        name="AnnualRevenue"
                        value="${r.length>1?r[1]:r[0]}"
                        ${!1?"checked":""}
                    />
                    <span class="ml-3 text-lg cursor-pointer text-gray-10"
                        >${r[0]}</span
                    >
                </label>
            </div>`}).join(`
`)}
            </div>
        </div>
    `},Sa=()=>p`
        <div data-form-element="TimelineExperiment" class="font-rubik block">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >How soon will you start working to build your website/app?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="TimelineExperiment"
                            value="Within a week/immediately"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Within a week/immediately</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="TimelineExperiment"
                            value="Within a month"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Within a month</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="TimelineExperiment"
                            value="Within 3 months"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Within 3 months</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="TimelineExperiment"
                            value="After 3 months"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">After 3 months</span>
                    </label>
                </div>
            </div>
        </div>
    `,no=()=>{let e=L("ReferralCode");return p`
        <div data-form-element="ReferralCode" class="w-full">
            <label
                style="color: #83889E"
                class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                for="${e}"
            >
                Referral code
            </label>
            <input
                style="background-color: #ECEDF0"
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-8 border border-bluegray-6 rounded py-3 px-4 my-1 leading-tight focus:outline-none  focus:border-gray-8 placeholder:text-bluegray-8"
                type="text"
                id="${e}"
                name="ReferralCode"
                data-ac-name="referral_code"
                placeholder="e.g. 123456"
            />
        </div>
    `},ya=()=>p`
        <div data-form-element="Funding" class="font-rubik block" style="display: none;">
            <span class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                >How are you planning on funding your project?</span
            >
            <div class="mt-2">
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            required
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="Funding"
                            value="I don't currently have budget"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I don't currently have budget</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="Funding"
                            value="I am using budget from savings"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I am using budget from savings</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="Funding"
                            value="I am using budget from investors"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">I am using budget from investors</span>
                    </label>
                </div>
                <div class="mt-1">
                    <label class="font-rubik form-control cursor-pointer">
                        <input
                            type="radio"
                            class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                            name="Funding"
                            value="Other"
                        />
                        <span class="ml-3 text-lg cursor-pointer text-gray-10">Other</span>
                    </label>
                </div>
            </div>
        </div>
    `,so=()=>{let e=L("WhatBroughtYouToTheStand");return p`<div data-form-element="WhatBroughtYouToTheStand" class="w-full">
        <label
            data-at-event-asterisk
            class="font-rubik block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
            for="${e}"
        >
            I'm interested in
        </label>
        <div class="inline-block relative w-full">
            <select
                required
                class="font-rubik appearance-none block w-full bg-gray-1 text-gray-10 border border-bluegray-6 rounded py-3 px-4 pr-8 leading-tight focus:outline-none focus:border-gray-8"
                name="WhatBroughtYouToTheStand"
                data-ac-name="field[442]"
                id="${e}"
            >
                <option value=""></option>
                <option value="Master class session">Free masterclass</option>
                <option value="AI demo of my idea">AI demo of my idea</option>
                <option value="Exploring partnerships">Partnerships</option>
            </select>
            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-bluegray-6">
                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" alt="">
                    <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z" />
                </svg>
            </div>
        </div>
    </div>`},fa=(e,t,a,i,r)=>{if(e==="AISUMMIT"){let o=p`
            <fieldset data-form-step="about-you" class="">
                <legend class="font-rubik text-xl-heading lg:text-4xl-heading font-medium"></legend>
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    ${K("","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your demo call.
                    </div>
                </div>
            </fieldset>
        `;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${o}

                        <div data-aisummitcheckbox-container class="">${Xi()}</div>

                        <div class="">
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}if(e==="CODEGENWAITLIST"){let o=p`
            <fieldset data-form-step="about-you" class="">
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    ${K("name@company.com","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your signup.
                    </div>
                </div>
                <div class="my-4">
                    <label
                        data-at-event-asterisk
                        class="font-rubik not-sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                        >Phone Number</label
                    >
                    <div class="flex flex-col gap-4 2xs:gap-0 2xs:flex-row 2xs:flex-nowrap">
                        <div class="min-w-[100px] max-w-[120px] flex-grow">${Ve(t)}</div>
                        <div class="min-w-[10em] max-w-full sm:max-w-[80%] flex-grow">${Ke()}</div>
                    </div>
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    ></div>
                </div>
            </fieldset>
        `;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${o}

                        <div class="">
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}if(e==="STUDIO4WAITLIST"){let o=p`
            <fieldset data-form-step="about-you" class="">
                <div data-id="title" class=" pb-3 font-rubik font-semibold">Join the waitlist</div>
                <legend class="font-rubik text-xl-heading lg:text-4xl-heading font-medium"></legend>
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    ${K("","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your signup.
                    </div>
                </div>
            </fieldset>
        `;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${o}

                        <div class="">
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >,
                                    <a class="font-rubik underline" target="_blank" href="/terms/nda-product-preview"
                                        >NDA</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}if(e==="UTS"){let o=()=>p`
                <div data-form-element="PromotionalTermsAcceptance" class="font-rubik block">
                    <span class="font-rubik block tracking-wide text-gray-10 text-md font-bold mb-1 mt-2"
                        >I am happy to travel to LA for the event on either July 21, 22 or 23</span
                    >
                    <div class="mt-2">
                        <div class="mt-1">
                            <label class="form-control font-rubik inline-flex items-start cursor-pointer">
                                <input
                                    required
                                    name="PromotionalTermsAcceptance"
                                    type="checkbox"
                                    class="form-checkbox h-6 w-6 accent-builderpurple-a5 bg-gray-1 cursor-pointer"
                                />
                                <span class="ml-3 font-rubik text-lg cursor-pointer text-gray-10 text-left">Yes</span>
                            </label>
                        </div>
                    </div>
                </div>
            `,n=p`
            <fieldset data-form-step="about-you" class="">
                <legend class="font-rubik text-xl-heading lg:text-4xl-heading font-medium">
                    Enter our ticket raffle
                </legend>
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    <label
                        data-at-event-asterisk
                        class="font-rubik not-sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                        >Phone Number</label
                    >
                    <div class="flex flex-col gap-4 2xs:gap-0 2xs:flex-row 2xs:flex-nowrap">
                        <div class="min-w-[100px] max-w-[120px] flex-grow">${Ve(t)}</div>
                        <div class="min-w-[10em] max-w-full sm:max-w-[80%] flex-grow">${Ke()}</div>
                    </div>
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        It will help you have direct contact with your expert after your demo.
                    </div>
                </div>
                <div class="my-4">
                    ${K("name@company.com","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your demo call.
                    </div>
                </div>
            </fieldset>
        `,c=p`<div class="">${o()}</div>`;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${n} ${c}

                        <div class="">
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}if(e==="DAVOS2024PANELDISCUSSIONRSVP"){let o=()=>p`
                <div data-form-element="PromotionalTermsAcceptance" class="font-rubik block">
                    <span class="font-rubik tracking-wide text-gray-10 text-md font-bold mb-1 mt-2">RSVP</span>
                    <div class="mt-2">
                        <div class="mt-1">
                            <label class="form-control font-rubik inline-flex items-start cursor-pointer">
                                <input
                                    required
                                    name="PromotionalTermsAcceptance"
                                    type="checkbox"
                                    class="form-checkbox h-6 w-6 accent-builderpurple-a5 bg-gray-1 cursor-pointer"
                                />
                                <span class="ml-3 font-rubik text-lg cursor-pointer text-gray-10 text-left">Yes</span>
                            </label>
                        </div>
                    </div>
                </div>
            `,n=p`
            <fieldset data-form-step="about-you" class="">
                <legend class="font-rubik text-xl-heading lg:text-4xl-heading font-medium"></legend>
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    ${K("name@company.com","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your demo call.
                    </div>
                </div>
            </fieldset>
        `,c=p`<div class="">${o()}</div>`;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${n}
                        <div class="">${ha()}</div>
                        <div data-what-best-describes-you-container class="my-4">${Ye()}</div>
                        ${c}

                        <div class="">
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}if(e==="Startup Grind Global Conference 2025"){let o=()=>p`
                <div class="font-rubik block">
                    <span class="font-rubik block tracking-wide text-gray-10 text-md font-bold mb-1 mt-2"
                        >Would you be interested in attending InsurTech Summit in Doha on 12 or 13th May in
                        person?</span
                    >
                    <!-- grid grid-cols-1 2xs:grid-cols-2 sm:grid-cols-3 -->
                    <div
                        class="mt-2"
                        style="display: grid; grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));"
                    >
                        <div class="mt-1">
                            <label class="font-rubik form-control cursor-pointer">
                                <input
                                    required
                                    type="radio"
                                    class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                                    name="PromotionalTermsAcceptance"
                                    value="Yes"
                                />
                                <span class="ml-3 text-lg cursor-pointer text-gray-10">Yes</span>
                            </label>
                        </div>
                        <div class="mt-1">
                            <label class="font-rubik form-control cursor-pointer">
                                <input
                                    required
                                    type="radio"
                                    class="font-rubik form-radio h-6 w-6 accent-builderpurple-a5 cursor-pointer bg-gray-1"
                                    name="PromotionalTermsAcceptance"
                                    value="No"
                                />
                                <span class="ml-3 text-lg cursor-pointer text-gray-10">No</span>
                            </label>
                        </div>
                    </div>
                </div>
            `,n="",c=()=>p`
                <div data-form-element="PromotionalTermsAcceptance" class="font-rubik block">
                    <span class="font-rubik block tracking-wide text-gray-10 text-md font-bold mb-1 mt-2"
                        >Would you be interested in attending InsurTech Summit in Doha on 12 or 13th May in
                        person?</span
                    >
                    <div class="mt-2">
                        <div class="mt-1">
                            <label class="form-control font-rubik inline-flex items-start cursor-pointer">
                                <input
                                    required
                                    name="PromotionalTermsAcceptance"
                                    type="checkbox"
                                    value="Yes"
                                    class="form-checkbox h-6 w-6 accent-builderpurple-a5 bg-gray-1 cursor-pointer"
                                />
                                <span class="ml-3 font-rubik text-lg cursor-pointer text-gray-10 text-left">Yes</span>
                            </label>
                        </div>
                    </div>
                </div>
            `,h=p`
            <fieldset data-form-step="about-you" class="">
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe()}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he()}</div>
                </div>
                <div class="my-4">
                    ${K("name@company.com","Email")}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    ></div>
                </div>
                <div class="my-4">
                    <label
                        data-at-event-asterisk
                        class="font-rubik not-sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                        >Phone Number</label
                    >
                    <div class="flex flex-col gap-4 2xs:gap-0 2xs:flex-row 2xs:flex-nowrap">
                        <div class="min-w-[100px] max-w-[120px] flex-grow">${Ve(t)}</div>
                        <div class="min-w-[10em] max-w-full sm:max-w-[80%] flex-grow">${Ke()}</div>
                    </div>
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    ></div>
                </div>
                <div class="my-4">${Yi()}</div>
                <div class="my-4">${Ji(!1)}</div>
            </fieldset>
        `;return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${h} ${""} ${n}

                        <div class="">
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >
                                </p>
                            </div>
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}let s=new URL(window.location.href);if(e==="B01"){let o=["/events/gitex24","/events/web-summit-24"].includes(s.pathname),n=s.pathname==="/air-india-prototype",c=n?"e.g. Aditya":"e.g. John",h=n?"e.g. Sharma":"e.g. Doe",g=n?"e.g. aditya@mail.com":"e.g. name@company.com",x=o?so():"",b=p`
            <fieldset data-form-step="about-you" class="">
                <legend class="font-rubik text-builderpurple-a5 font-semibold">About you</legend>
                ${x}
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${pe(c)}</div>
                    <div class="px-2 flex-grow min-w-[50%]">${he(h)}</div>
                </div>
                <div class="my-4">
                    <label
                        data-at-event-asterisk
                        class="font-rubik not-sr-only block tracking-wide text-gray-10 text-sm font-bold mb-1 mt-2"
                        >Phone Number</label
                    >
                    <div class="flex flex-col gap-4 2xs:gap-0 2xs:flex-row 2xs:flex-nowrap">
                        <div class="min-w-[100px] max-w-[120px] flex-grow">${Ve(t)}</div>
                        <div class="min-w-[10em] max-w-full sm:max-w-[80%] flex-grow">${Ke()}</div>
                    </div>
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        It will help you have direct contact with your expert after your demo.
                    </div>
                </div>
                <div class="my-4">
                    ${K(g)}
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        We need this to send you a confirmation of your demo call.
                    </div>
                </div>
            </fieldset>
        `,_=p`
            <fieldset data-form-step="about-your-company" class="">
                <legend data-hidden-in-short-form class="font-rubik text-builderpurple-a5 font-semibold">
                    About your company
                </legend>
                <div
                    data-motivation-micro-copy
                    class="font-rubik"
                    style="display: none; font-size: 10px; margin-top: 4px"
                >
                    It will help us tailor your demo so you can see examples from similar companies.
                </div>
                <div class="flex flex-wrap -mx-2">
                    <div class="px-2 flex-grow min-w-[50%]">${ha()}</div>
                    <div data-hidden-in-short-form class="px-2 flex-grow min-w-[50%]">${Qi()}</div>
                </div>
                ${r.has("data-experiment-store-digital-demo")?"":`<div data-what-best-describes-you-container class="my-4">${Ye()}</div>`}
            </fieldset>
        `,O;r.has("data-experiment-funding-question")?O=p`
                <fieldset data-form-step="about-your-idea" class="">
                    <legend class="font-rubik text-builderpurple-a5 font-semibold">About your idea</legend>
                    <div>${Je()} ${va()} ${ya()}</div>
                </fieldset>
            `:r.has("data-experiment-digital-bant")||r.has("data-experiment-store-digital-demo")?(O=p``,s.searchParams.has("dev-no-bant-form")&&(O=p` <div>${vt()}</div> `)):r.has("data-experiment-stage-of-business-question")?O=p`
                <fieldset data-form-step="about-your-idea" class="">
                    <legend class="font-rubik text-builderpurple-a5 font-semibold">About your business</legend>
                    <div
                        data-motivation-micro-copy
                        class="font-rubik"
                        style="display: none; font-size: 10px; margin-top: 4px"
                    >
                        It will help us ensure your demo is personalised to your goals and needs.
                    </div>
                    <div>${wt()}</div>
                </fieldset>
            `:O=p`
                <fieldset data-form-step="about-your-idea" class="">
                    <legend class="font-rubik text-builderpurple-a5 font-semibold">About your idea</legend>
                    <div>${Je()} ${va()} ${ya()}</div>
                </fieldset>
            `;let w=p`<fieldset data-form-step="referral"></fieldset>`;r.has("data-experiment-referral")&&(w=p`
                <fieldset data-form-step="referral" class="">
                    <div>${no()}</div>
                </fieldset>
            `);let D=p`<fieldset data-form-step="at-event"></fieldset>`;a&&s.pathname!=="/events/uts-2023"&&(D=p`
                <fieldset data-form-step="at-event" class="">
                    <div>
                        ${to(i)}
                        ${io()} ${ao()} ${ro()}
                    </div>
                </fieldset>
            `);let P=p`<div data-newsletter-container class=" my-10">${Zi()}</div>`,q=s.pathname.startsWith("/events/upcoming")&&s.searchParams.has("event")===!1?oo(a):"",V=a&&s.searchParams.get("event")==="uts-ny-2024";return p`
            <style>
                ${ue}
            </style>
            <div class="tailwind">
                <div class="flex justify-center">
                    <div data-form-fields-container class="w-full max-w-lg">
                        <button id="form-back" style="display: none" class="hover:underline  pb-3 font-rubik text-xs">
                            &lt; Back
                        </button>
                        <div data-id="title" style="display: hidden" class=" pb-3 font-rubik font-semibold"></div>
                        <!-- <div data-id="subtitle" style="display: hidden" class=" pb-6 font-rubik"></div> -->

                        ${V?`${b}`:`${q} ${D} ${b} ${_}
                        ${O} ${w}`}

                        <div class="">
                            <div class=" my-4">
                                <p class="font-rubik text-sm">
                                    ${r.has("data-experiment-store-digital-demo")?`By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >,
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    > and <a class="font-rubik underline" target="_blank" href="/terms/studio-store-fair-usage-agreement"
                                        >our Studio Store fair usage agreement</a
                                    >.`:`By proceeding you agree to Builder.ai's
                                    <a class="font-rubik underline" target="_blank" href="/terms/privacy"
                                        >privacy policy</a
                                    >
                                    and
                                    <a class="font-rubik underline" target="_blank" href="/terms/terms-and-conditions"
                                        >terms and conditions</a
                                    >`}
                                </p>
                            </div>
                            <div class=" text-center my-4">
                                <button
                                    id="_form_ac_submit"
                                    type="submit"
                                    class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                >
                                    Submit
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}else return p``};var Z=String.raw;function lo(){window.uetq=window.uetq||[],window.uetq.push("event","submit_lead_form",{})}var te=e=>e==="StudioPro"?"Studio":e==="StudioStore"?"Studio Store":e,St=!1;function ve(e){St=e}async function Ze(e,t){let a=new URL(window.location.href),i=e.target,r=f=>(f.startsWith("dev-")&&(f=f.substring(4)),f.startsWith("data-")&&(f=f.substring(5)),a.searchParams.has(`dev-${f}`)||a.searchParams.has(`data-${f}`)||i.hasAttribute(`data-${f}`)),s=r("bant2"),o=r("bant2-with-product-override");e.preventDefault();let n=i.getAttribute("data-RedirectURL");(!n||n.trim()==="")&&(n=new URL("/thank-you",window.location.href).href);let c=new FormData(this),h=c.get("WhatBestDescribesYou")==="Student",g=le(a),x="";try{let f=document.getElementById("context");if(f){let y=JSON.parse(f.innerText);y&&y.country&&(x=y.country)}}catch{}let b=!1;try{window.sessionStorage&&(window.sessionStorage.setItem("test-value","test"),window.sessionStorage.getItem("test-value")==="test"&&(b=!0))}catch{}let _,O=!1,w=!0,D,P=!1,q=window.statsig;if(console.log(`statsig found: ${q!==void 0}`),q&&!h&&b&&g!=="StudioStore"){let f=q.getLayer("www___form_experiments"),y=f.get("scheduler_version",""),C=f.get("bant_version",""),H=f.get("experiment_name","");console.log({scheduler_version:y,bant_version:C,experiment_name:H}),H==="bant4_versus_bant5_experiment"?P=!0:H==="direct_versus_indirect_scheduler_experiment"&&(O=!0),y==="direct_scheduler"?_=!1:y==="indirect_scheduler"&&(_=!0),C==="bant4"?w=!0:C==="bant5"&&(w=!0,D=!0)}if(t)for(let[f,y]of Object.entries(t))c.set(f,y);let V=this.querySelector("[name='ReferralCode']");V&&V.value&&c.set("ReferralCode",V.value),n=co(c,n),!this.hasAttribute("data-RedirectURL-overwritten")&&g==="StudioStore"&&(n=new URL("/thank-you-studio-store",window.location.href).href);let U=i.querySelector("[data-form-fields-container]");if(!U)throw Error("missing formFieldsContainer");let $=document.createElement("div");$.setAttribute("data-form-step","book-demo"),$.setAttribute("style","display: none"),c.set("RedirectURL",n),await sa({formData:c,target:i});let m=na(c);if(!M){let f=["CompanySize","AppCategory","QuizRecommendedProduct","QuizBusinessNeed","QuizTechComfortLevel","QuizInvolvementPreference","QuizExpectedBudget"];for(let y of f){if(m.has(y))continue;let C=W(y);C&&m.set(y,C)}}let ae=c.get("FormForActiveCampaign");m.delete("FormForActiveCampaign");let l=c.get("FormRef"),u=l==="AC28"||this.hasAttribute("data-is-newsletter-signup-form"),d=l==="AC52"||this.hasAttribute("data-is-popout-form"),v=c.get("CountryCode")??"+91",S=la(v);a.searchParams.has("dev-force-location")&&(S=Re(a.searchParams.get("dev-force-location")?.toUpperCase()));let E=i.getAttribute("data-option")?i.getAttribute("data-option"):"",R=g==="StudioStore"&&a.pathname!=="/studio-store-product/store-field-marketing"||(i.hasAttribute("data-experiment-calendly-for-pro")||a.searchParams.has("dev-experiment-calendly-for-pro")||a.searchParams.has("dev-experiment-digital-bant")||i.hasAttribute("data-experiment-digital-bant")||a.searchParams.has("dev-use-calendly"))&&g==="StudioPro";a.pathname.startsWith("/events/")&&(R=!1);let j=i.getAttribute("data-formtype");for(let f of["free-downloadables","store-digital-demo"])if(j===f){R=!1;break}j&&j.includes("partner")&&(R=!1);let F=m.get("UTMMedium");F&&F.trim().toLowerCase()==="partner"&&(R=!1),R&&h&&(E===""||E.indexOf("demo")>-1)&&(n=new URL("/thank-you-student",window.location.href).href),(M===!0||a.pathname==="/uts"||a.pathname==="/aisummit"||a.pathname==="/new-builder-studio"||a.pathname==="/msft-ai-webinar"||a.pathname==="/turning-your-voice-into-code"||a.pathname==="/events/qic-appathon"||a.pathname==="/events/dreambuilder25"||a.pathname==="/events/web-summit-24"||a.pathname==="/davos-2024-panel-discussion-rsvp"||a.pathname==="/book-a-demo-on-software-creation-with-ai")&&(R=!1);let T=!i.hasAttribute("data-experiment-disable-calendly")&&R&&u===!1&&E.indexOf("video")===-1&&E.indexOf("chat")===-1&&E.indexOf("guide")===-1&&E.indexOf("store-digital-demo")===-1&&E.indexOf("storeDigitalDemo")===-1,I=g==="StudioPro"&&(a.searchParams.has("dev-use-scheduler")||a.searchParams.has("dev-experiment-use-scheduler")||i.hasAttribute("data-experiment-use-scheduler")),A=Promise.resolve(),re=Promise.resolve(),qe=(f,y)=>{let{calendlyURL:C,calendlyTitle:H}=ze(f,y);$.innerHTML=Z`
            <book-demo-calendar
                style="display: block"
                data-url=${C}
                first-name="${m.get("FirstName")}"
                last-name="${m.get("LastName")}"
                email="${m.get("Email")}"
                redirect-url="${new URL(y==="StudioStore"?"/thank-you-appointment":"/thank-you-appointment-pro",window.location.href).href}"
                title="${H}"
            >
            </book-demo-calendar>
        `,A=new Promise((B,ie)=>{$.addEventListener("book_demo_calendar_loaded",async $e=>{await Pe({event:"book_demo_calendar_loaded"}),B(void 0)})}),U.appendChild($)};s===!1&&w===!1&&h===!1&&T&&!I&&qe(S,g);let ke=async()=>{m.set("LeadFormProductType",te(g)),(s||w)&&m.set("ProductType",te(g));let f=!1;try{let C=new URLSearchParams;m.forEach((B,ie)=>C.set(ie,B));let H=await Ge(C)}catch(C){console.error(C),f=!0}if(f)return!0;i.querySelectorAll("[type='submit']").forEach(C=>{C.textContent=C.getAttribute("data-textContent")??"Submit",C.removeAttribute("disabled"),ve(!1)});let y={event:"form_submission",email:m.get("Email"),phone_number:m.get("Phone"),phone_country_code:m.get("CountryCode"),is_student:m.has("WhatBestDescribesYou")?h:void 0,form_field_CompanySize:m.get("CompanySize"),form_field_StageOfIdea:m.get("StageOfIdea"),form_field_WhatBestDescribesYou:m.get("WhatBestDescribesYou"),is_newsletter_signup_form:u,is_popout_form:d};u||lo(),z(window,Xt),z(window,ta),Me&&z(window,Zt),i.hasAttribute("data-qualification-started")?z(window,ia):z(window,aa);try{window.sessionStorage&&window.sessionStorage.setItem("form_submitted","")}catch(C){console.error(C)}re=Pe(y)},tt=!1;(a.searchParams.has("dev-experiment-digital-bant")||i.hasAttribute("data-experiment-digital-bant"))&&(tt=i.getAttribute("data-option")==="book-demo"||i.getAttribute("data-option")==="book-demo-pro"),h&&(tt=!1,T=!1,R=!1);let N=f=>{console.log(f);let y=m.get("LeadFormDebugLog");y?y=`${y}
${f}`:y=`${f}`,m.set("LeadFormDebugLog",y)},ge=w?"4":o?"3":s?"2":"1",Oe=g==="StudioStore",J=!0;if(T&&tt)if(console.log({qualificationStarted:i.hasAttribute("data-qualification-started")}),i.hasAttribute("data-qualification-started")){let f=m.get("WhatBestDescribesYou"),y=m.get("AppCategory"),C=m.get("StageOfIdea"),H=m.get("StageOfBusiness"),B=m.get("BudgetExperiment"),ie=m.get("TimelineExperiment");N(`WhatBestDescribesYou: ${f}`),N(`AppCategory: ${y}`),N(`StageOfIdea: ${C}`),N(`BudgetExperiment: ${B}`);let $e=g==="StudioPro"?"studio":"store",me=B===null||B==="I need guidance from a professional"?"budget_need_guidance":B==="I don\u2019t have any budget"?"no_budget":B==="Less than \u20B9400,000 (templated build)"?"low_budget":B==="More than \u20B9400,000 (customised build)"?"high_budget":"budget_need_guidance",ja=y===null||["Retail & e-commerce","Food & drinks","Education","Health & fitness","Shopping","Medical","Other"].includes(y)?"store_category":"not_store_category",Be=`${$e}__${me}__${ja}`,we={store__high_budget__store_category:"studio__demo_booking",store__high_budget__not_store_category:"studio__demo_booking",store__low_budget__store_category:"store__demo_booking",store__low_budget__not_store_category:"studio__thank_you_page",store__budget_need_guidance__store_category:"store__demo_booking",store__budget_need_guidance__not_store_category:"studio__demo_booking",store__no_budget__store_category:"store__thank_you_page",store__no_budget__not_store_category:"studio__thank_you_page",studio__high_budget__store_category:"studio__demo_booking",studio__high_budget__not_store_category:"studio__demo_booking",studio__low_budget__store_category:"store__demo_booking",studio__low_budget__not_store_category:"studio__thank_you_page",studio__budget_need_guidance__store_category:"studio__demo_booking",studio__budget_need_guidance__not_store_category:"studio__demo_booking",studio__no_budget__store_category:"store__thank_you_page",studio__no_budget__not_store_category:"studio__thank_you_page"};we.store__high_budget__store_category="store__demo_booking",we.store__high_budget__not_store_category="store__demo_booking",we.store__low_budget__not_store_category="store__demo_booking",we.store__budget_need_guidance__not_store_category="store__demo_booking",we.store__no_budget__not_store_category="store__thank_you_page";let To=["studio__low_budget__store_category"].includes(Be),Ha=["studio__low_budget__store_category"].includes(Be),_e=we[Be];N(`bant input: ${Be}`),N(`bant decision: ${_e}`);let Dt=["I don't have a business","I don't yet have an idea","I don't want a website or an app"],Ce=!1;f==="Student"?(Ce=!0,N("override_disqualify_authority: Student")):(H||C)&&Dt.includes(H)||Dt.includes(C)?(Ce=!0,N(`override_disqualify_need: ${H??C}`)):B==="I don\u2019t have any budget"?(Ce=!0,N(`override_disqualify_budget: ${B}`)):(y==="Gaming (not available)"||y==="Gaming"||y==="Crypto")&&(Ce=!0,N(`override_disqualify_need: ${y}`)),Ce&&(J=!1,_e=_e.replace("demo_booking","thank_you_page"));let Ft=!1;if(s||w){let X=_e.startsWith("store")?"StudioStore":_e.startsWith("studio")?"StudioPro":void 0;o?X&&X!==g?(N(`Product changed from ${te(g)} to ${te(X)} during BANT questioning`),g=X):N(`Product not changed from ${te(g)} during BANT questioning`):X&&X!==g?(N(`Product would have changed from ${te(g)} to ${te(X)} during BANT questioning, but BANT product-switching was disabled`),Ft=!0,J=!1):N(`Product not changed from ${te(g)} during BANT questioning`),_e.includes("thank_you_page")&&(J=!1)}else(ie==="After 3 months"||g==="StudioPro"&&B==="Less than \u20B9400,000 (templated build)"||g==="StudioStore"&&B==="More than \u20B9400,000 (customised build)")&&(J=!1);let Tt=!1,Lt=J?`bant_${ge}_passed`:`bant_${ge}_failed`;!J&&Ft&&(Tt=!0,Lt=`bant_${ge}_failed_wrong_product`),m.set("LeadFormPreviousStep","main_details"),m.set("LeadFormCurrentStep",Lt),P&&m.set("Experiment",D?"bant4-versus-bant5-experiment-variant-complete":"bant4-versus-bant5-experiment-control-complete"),O&&m.set("Experiment",_?"direct-versus-indirect-scheduler-experiment-variant":"direct-versus-indirect-scheduler-experiment-control");let be;if(J?I&&g==="StudioPro"?be="demo_booking_scheduler":be="demo_booking_calendly":be="thank_you_page",m.set("LeadFormNextStep",Oe?"thank_you_page":be),!J){let X=m.get("BudgetExperiment");if(f==="Student"){let Mt=new URL("/thank-you-page",window.location.href);Mt.searchParams.set("student",""),n=Mt.href}else this.hasAttribute("data-RedirectURL-overwritten")||(s||w?Tt?g==="StudioStore"?n=new URL("/thank-you-studio-store",window.location.href).href:g==="StudioPro"&&Ha&&(n=new URL("/thank-you",window.location.href).href):n=new URL("/thank-you-page",window.location.href).href:g==="StudioStore"?X==="More than \u20B9400,000 (customised build)"?n=new URL("/thank-you",window.location.href).href:n=new URL("/thank-you-studio-store",window.location.href).href:g==="StudioPro"&&X==="Less than \u20B9400,000 (templated build)"?n=new URL("/thank-you-studio-store",window.location.href).href:n=new URL("/thank-you-page",window.location.href).href);N(`Redirecting to ${n}`)}if(await ke()){console.log("error, reloading"),window.location.reload();return}i.children[0].style.display="block",i.children[1].remove()}else{if(N(ge==="1"?`bant version ${ge} (for ${te(g)})`:`bant version ${ge} (product agnostic)`),He){let me=te(He);m.set("LeadFormUserProductChoice",me),N(`LeadFormUserProductChoice: ${me}`)}m.set("LeadFormPreviousStep",i.hasAttribute("data-option")&&i.hasAttribute("data-getting-started-skipped")?"get_started_options":""),m.set("LeadFormCurrentStep","main_details"),m.set("LeadFormNextStep",`bant_${ge}`);let f=m.get("CompanySize"),y=["Self-employed","1-10 employees","11-50 employees"].includes(f);P&&m.set("Experiment",D?"bant4-versus-bant5-experiment-variant":"bant4-versus-bant5-experiment-control");let C=a.searchParams.has("from")?new URL(a.searchParams.get("from"),window.location.href):a,H=void 0;if(H!==void 0&&m.set("Experiment",H?"bant-where-did-you-hear-about-us-variant":"bant-where-did-you-hear-about-us-control"),await ke()){console.log("error, reloading"),window.location.reload();return}i.firstChild.style.display="none";let ie=a.searchParams.has("dev-no-bant-form"),$e=At(!0,w,D,y,a,i,g,!1,ie,H);if(ie){let me=$e.querySelector('[type="submit"]');me&&(i.style.display="none",i.hasAttribute("data-submit-once")||(i.setAttribute("data-submit-once",""),window.setInterval(()=>{me.click()},160)))}return}else{let f;if(T?I&&g==="StudioPro"?f="demo_booking_scheduler":f="demo_booking_calendly":f="thank_you_page",m.set("LeadFormPreviousStep",i.hasAttribute("data-option")?"get_started_options":""),m.set("LeadFormCurrentStep","main_details"),m.set("LeadFormNextStep",Oe?"thank_you_page":f),await ke()){console.log("error, reloading"),window.location.reload();return}}let Ee=!1;if(T&&J&&U&&$&&(I&&g==="StudioPro"&&(Ee=!0),!Ee&&!Oe)){for((s||w)&&qe(S,g);U.firstElementChild&&U.firstElementChild!==$;)U.removeChild(U.firstElementChild);U.setAttribute("style","width: 100%; max-width: unset;"),U.setAttribute("class",""),$.setAttribute("style","display: block"),$.scrollIntoView();let f=new Promise((C,H)=>{$.addEventListener("book_demo_calendar_time_selected",async B=>{await Pe({event:"book_demo_calendar_time_selected"}),C(void 0)})}),y=new Promise((C,H)=>{$.addEventListener("book_demo_calendar_booked",async B=>{B.preventDefault(),n=B.detail.redirectURL,$.scrollIntoView(),await Pe({event:"book_demo_calendar_booked"}),new URL(window.location.href).searchParams.has("dev-disable-redirect")&&await new Promise(ie=>setTimeout(ie,1e7)),C(void 0)})});await Promise.all([f,y])}if(Oe&&(Ee=!1),await re,u)i.innerHTML=Z` <p class="_form-thank-you">Thanks for signing up.</p> `;else if(l==="UTS"){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">
                Thank you, we've received your raffle entry.
            </p>
            <p class="text-md-copy">The draw will take place on July 17.</p>
        `;return}else if(l!==null&&["AISUMMIT","STUDIO4WAITLIST","CODEGENWAITLIST"].includes(l)){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">Thank you.</p>
            <p class="text-md-copy"></p>
        `;return}else if(l==="DAVOS2024PANELDISCUSSIONRSVP"){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">Thank you.</p>
            <p class="text-md-copy"></p>
        `;return}else if(M&&a.pathname==="/events/uts-2023"){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">
                Success. Please refresh the page to submit the form again.
            </p>
        `;return}else if(M&&a.pathname.startsWith("/events/upcoming")){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">
                Success. Please refresh the page to submit the form again.
            </p>
        `,i.style.scrollMarginTop="80px",i.scrollIntoView();return}else if(a.pathname==="/msft-ai-webinar"){i.innerHTML=Z`
            <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">
                Thank you for registering with us, you will receive a mail shortly
            </p>
        `,i.style.scrollMarginTop="80px",i.scrollIntoView();return}else if(l==="MENAInsurtechSummit2024AppathonInterest"&&m.get("PromotionalTermsAcceptance")!=="Yes"){i.innerHTML=Z` <p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">Thank you</p> `,i.style.scrollMarginTop="80px",i.scrollIntoView();return}else if(l==="Startup Grind Global Conference 2025"){i.innerHTML=Z`<p class="text-xl-heading lg:text-4xl-heading font-medium mb-5">
            You're officially in Dream Builder '25!<br /><br />
            Entries are now open —
            <u
                ><a href="/events/dreambuilder-25-share-your-app-idea"
                    >share your idea today or check out the questions</a
                ></u
            >. You have until Dec 15 to enter.
        </p>`,i.style.scrollMarginTop="80px",i.scrollIntoView();return}else{if(window.sessionStorage)for(let f of["FirstName","LastName","CountryCode","Phone","Email","CompanyName"]){let y=m.get(f);y&&window.sessionStorage.setItem(f,y)}if(Ee){let f=new URL("/scheduler",window.location.href);m.has("LeadFormNextStep")?f.searchParams.set("current-step",m.get("LeadFormNextStep")):f.searchParams.set("previous-step","demo_booking"),m.has("LeadFormCurrentStep")&&f.searchParams.set("previous-step",m.get("LeadFormCurrentStep")),g&&f.searchParams.set("product",g),m.has("FirstName")&&f.searchParams.set("firstname",m.get("FirstName")),m.has("LastName")&&f.searchParams.set("lastname",m.get("LastName")),m.has("Email")&&f.searchParams.set("email",m.get("Email")),m.has("Phone")&&f.searchParams.set("phone",`${m.get("CountryCode")}${m.get("Phone")}`.replace(/\s/g,"")),m.has("CompanyName")&&f.searchParams.set("company",m.get("CompanyName")??"Unknown"),m.has("ProductIdea")&&f.searchParams.set("project_idea",m.get("ProductIdea")??""),a.searchParams.has("environment")&&f.searchParams.set("environment",f.searchParams.get("environment")),n&&f.searchParams.set("fallback",n),_&&(console.log(`schedulerURL: ${f.href}`),window.sessionStorage.setItem("schedulerURL",f.href),f=new URL("/thank-you-appointment-scheduler",window.location.href)),n=f.href}if(n&&n.includes("/store-natasha-dls")){let f=a.hostname!=="www.builder.ai",y=new URL(f?"https://staging.engineer.ai/home":"https://studio.builder.ai/home");y.searchParams.set("reason","store-natasha-dls"),y.searchParams.set("product","store"),y.searchParams.set("name",`${m.get("FirstName")} ${m.get("LastName")}`.trim()),m.has("Email")&&y.searchParams.set("email",m.get("Email")),m.has("Phone")&&y.searchParams.set("phone_number",`${m.get("CountryCode")??""}-${m.get("Phone").replace(/\s/g,"")}`);let C=f?"https://staging.engineer.ai/apps/e-commerce-app-website?exp=global_beta&is_dls_store_flow=true":"https://studio.builder.ai/apps/e-commerce-app-website?exp=global_beta&is_dls_store_flow=true";y.searchParams.set("redirection_url",C),n=y.href}console.log(`redirecting to: ${n}`),window.location.href=n}}function uo(e){let t=e.get("WhatBestDescribesYou"),a=e.get("CompanySize");if(t==="Solo entrepreneur")return"entrepreneur";for(let i of["Self-employed","1-10 employees","11-50 employees","51-200 employees","201-500 employees"])if(a.trim()===i.trim())return"smb";return"enterprise"}function co(e,t){let a="/create-software/app-with-us",i=new URL(window.location.href),r=i.pathname===a,s=i.host==="builder-dev.webflow.io";if(!r)return t;let o=!1;for(let h of["c1","c2","v1","v2"])if(i.searchParams.has(h)){o=!0;break}if(!o)return t;let n=uo(e),c;if(i.searchParams.has("c1"))c="/thank-you-c1";else if(i.searchParams.has("c2"))c="/thank-you-c2";else if(i.searchParams.has("v1"))if(n==="entrepreneur")c=`/thank-you-${n}`;else return t;else if(i.searchParams.has("v2"))c=`/thank-you-${n}`;else return t;return new URL(c,window.location.href).href}var Aa=!1;function Ia(e,t){window.hj||(window.hj=window.hj||function(){(hj.q=hj.q||[]).push(arguments)}),t&&(Aa||(Aa=!0,window.hj("event","start_hotjar"))),window.hj("event",e)}function At(e,t,a,i,r,s,o,n=!1,c=!1,h=void 0){s.setAttribute("data-qualification-started","");let g=document.createElement("div");c&&(g.style.display="none");let x=o==="StudioPro"?Je:wt;(e||t)&&(x=vt);let b=o==="StudioPro"||e||t?"":Sa(),_="Book a demo";r.searchParams.has("continue")&&(_="Book a demo"),h===!0?Ia("bant-where-did-you-hear-about-us-control",!0):h===!1&&Ia("bant-where-did-you-hear-about-us-variant",!0);let O=`
        ${n?K():""}
        ${xa()}
        ${n?Ye():""}
        ${_a()}
        ${Qe()}
        ${b}
        ${x()}
        ${h?Se():""}
    `;a?i?O=`
                ${n?K():""}
                ${_t()}
                ${kt()}
                ${Qe()}
                ${h?Se():""}
            `:O=`
                ${n?K():""}
                ${_t()}
                ${xt()}
                ${h?Se():""}
            `:t&&(i?O=`
                ${n?K():""}
                ${ka()}
                ${yt()}
                ${kt()}
                ${Qe()}
                ${h?Se():""}
            `:O=`
                ${n?K():""}
                ${wa()}
                ${yt()}
                ${xt()}
                ${h?Se():""}
            `),g.innerHTML=Z`<style>
            [data-form-element] {
                padding-bottom: 8px;
            }
        </style>
        <div class="tailwind">
            <div class="flex justify-center">
                <div class="w-full max-w-lg">
                    <div data-id="title" class="mx-3 pb-3 font-rubik font-semibold">${_}</div>
                    <!--<div data-id="subtitle" class="mx-3 pb-6 font-rubik">Subtitle...</div>-->

                    <fieldset data-form-step="about-your-idea" class="mx-3 my-2">
                        <!-- <legend class="font-rubik text-builderpurple-a5 font-semibold">Section...</legend> -->
                        <div>${c?"":O}</div>
                    </fieldset>
                    <div class="my-8">
                        <div class="mx-3 text-center my-4">
                            <button
                                type="submit"
                                class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                            >
                                ${_}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>`,o==="StudioStore"&&g.querySelectorAll("[data-remove-option-on-store-form]").forEach(P=>P.remove()),g.querySelectorAll("[data-is-required]").forEach((P,q)=>{P.setAttribute("required","")}),s.appendChild(g);let w=s.querySelector('[data-form-element="AppCategory"] select'),D=s.querySelector('[data-form-element="OtherAppCategory"]');if(w&&D){let P=()=>{w.options[w.selectedIndex].value==="Other"?(D.querySelector("textarea").setAttribute("required",""),D.style.display="block"):(D.querySelector("textarea").removeAttribute("required"),D.style.display="none")};window.toggle=P,P(),w.addEventListener("change",P)}return g.scrollIntoView(),g}function Ea(e){let t=e.getAttribute("data-FormRef"),a=t==="AC28"||e.hasAttribute("data-is-newsletter-signup-form"),i=t==="AC52"||e.hasAttribute("data-is-popout-form");e.addEventListener("focusout",function(r){let o=r.target.getAttribute("name");if(o){for(let n of xe)if(n.name===o){k({event:"form_interaction",form_field_name:o,is_newsletter_signup_form:a,is_popout_form:i}),z(window,Yt),z(window,ea);break}}})}var oe=String.raw,Ca=oe`
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 22 22" fill="transparent" stroke="transparent">
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M1.62671 5.625C1.62671 4.79657 2.29828 4.125 3.12671 4.125H18.8767C19.7051 4.125 20.3767 4.79657 20.3767 5.625V18.875C20.3767 19.7034 19.7051 20.375 18.8767 20.375H3.12671C2.29828 20.375 1.62671 19.7034 1.62671 18.875V5.625Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M1.62671 9.125H20.3767"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M6.62671 6V1.625"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M15.3767 6V1.625"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
`,rn=oe` <svg
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5"
    viewBox="0 0 22 20"
    fill="transparent"
    stroke="transparent"
>
    <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4.57083 11.2307H4.56167C2.84488 11.6122 1.62378 13.1354 1.625 14.8941V15.6357C1.625 15.9673 1.7567 16.2852 1.99112 16.5196C2.22554 16.754 2.54348 16.8857 2.875 16.8857H6C6.69036 16.8857 7.25 16.3261 7.25 15.6357V15.6357C7.25 14.9454 7.80964 14.3857 8.5 14.3857H13.5C14.1904 14.3857 14.75 14.9454 14.75 15.6357V15.6357C14.75 16.3261 15.3096 16.8857 16 16.8857H19.125C19.8154 16.8857 20.375 16.3261 20.375 15.6357V14.8941C20.375 13.1364 19.1542 11.6145 17.4383 11.2332H17.4292C13.1826 10.4107 8.81772 10.4099 4.57083 11.2307V11.2307Z"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M11 7.51074V3.13574"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M6.625 7.51074L4.75 4.38574"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
    <path
        d="M15.375 7.51074L17.25 4.38574"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
    />
</svg>`,Da=oe`
    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 22 22" fill="transparent" stroke="transparent">
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M1.625 3.125C1.625 2.29657 2.29657 1.625 3.125 1.625H18.875C19.7034 1.625 20.375 2.29657 20.375 3.125V18.875C20.375 19.7034 19.7034 20.375 18.875 20.375H3.125C2.29657 20.375 1.625 19.7034 1.625 18.875V3.125Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M9.53167 14.05C9.31055 14.1602 9.04812 14.1482 8.838 14.0182C8.62789 13.8882 8.50001 13.6587 8.5 13.4116V8.5883C8.50001 8.34122 8.62789 8.11174 8.838 7.98173C9.04812 7.85172 9.31055 7.83971 9.53167 7.94997L14.3558 10.3625C14.5975 10.4831 14.7501 10.7299 14.7501 11C14.7501 11.27 14.5975 11.5169 14.3558 11.6375L9.53167 14.05Z"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
`,nn=oe`
    <svg
        xmlns="http://www.w3.org/2000/svg"
        class="h-5 w-5"
        viewBox="0 0 22 22"
        fill="transparent"
        stroke="transparent"
    ></svg>
`,go=oe`
    <svg
        xmlns="http://www.w3.org/2000/svg"
        class="h-5 w-5"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="transparent"
        stroke="transparent"
    >
        <path
            d="M12.001 3.75V15.75"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M7.50101 11.25L12.001 15.75L16.501 11.25"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
        <path
            d="M23.251 15.75V17.25C23.251 18.9069 21.9079 20.25 20.251 20.25H3.75101C2.09415 20.25 0.751007 18.9069 0.751007 17.25V15.75"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
        />
    </svg>
`,mo=oe`
    <svg
        xmlns="http://www.w3.org/2000/svg"
        xml:space="preserve"
        style="enable-background:new 0 0 22 22"
        viewBox="0 0 22 22"
        class="h-5 w-5"
        width="24"
        height="24"
        fill="transparent"
        stroke="transparent"
    >
        <path
            fill="none"
            d="M1.6 3.1c0-.8.7-1.5 1.5-1.5h15.8c.8 0 1.5.7 1.5 1.5v15.8c0 .8-.7 1.5-1.5 1.5H3.1c-.8 0-1.5-.7-1.5-1.5V3.1z"
            style="fill-rule:evenodd;clip-rule:evenodd;fill-opacity:0;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round"
        />
        <path
            fill="none"
            d="m5.4 11 3.8 3.8 7.5-7.5"
            style="fill-opacity:0;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round"
        />
    </svg>
`;function et(e,t=!1){for(let s of["about-your-idea"]){let o=e.querySelector(`[data-form-step="${s}"]`);o&&(o.style.display="none")}let a=e.querySelector('[data-id="title"]');a&&a.remove(),e.querySelectorAll("[name='CompanySize'], [name='StageOfBusiness'], [name='StageOfIdea']").forEach(function(s){s.removeAttribute("required")}),e.querySelectorAll("[data-hidden-in-short-form]").forEach(function(s){s.style.display="none"});let r=e.querySelector("[name='CompanyName']");if(r&&(r.previousElementSibling.style.marginTop="-8px"),t){let s=e.querySelector("[data-what-best-describes-you-container]");s&&s.remove()}}function bo(e){for(let r of["about-your-idea"]){let s=e.querySelector(`[data-form-step="${r}"]`);s&&(s.style.display="none")}let t=e.querySelector('[data-id="title"]');t&&t.remove(),e.querySelectorAll("[name='CompanySize'], [name='StageOfBusiness'], [name='StageOfIdea'], [name='WhatBestDescribesYou']").forEach(function(r){r.removeAttribute("required")}),e.querySelectorAll("[data-hidden-in-short-form],[data-what-best-describes-you-container]").forEach(function(r){r.style.display="none"});let i=e.querySelector("[name='CompanyName']");i&&(i.previousElementSibling.style.marginTop="-8px")}function Fa(e){let t=e.getAttribute("data-FormRef");return pt(t)?t:"AC27"}var Ta=!1,La=!1,Xe=!1;function fo(e){let t=e.parentElement,a=e._form;t.innerHTML=a;let i=t?.querySelector("form");for(let{name:r,value:s}of e.attributes)r.startsWith("data-")&&i.setAttribute(r,s);return e.hasAttribute("autocomplete")&&i.setAttribute("autocomplete",e.getAttribute("autocomplete")),i._form=a,i.removeAttribute("data-forms-get-started"),i}function ca(){let e="";try{let t=document.getElementById("context");if(t){let a=JSON.parse(t.innerText).phoneCode;a&&typeof a=="string"&&(e=a)}}catch{console.log("frontend context missing or not parsed")}return e=e.trim(),e?(e.startsWith("+")===!1&&(e=`+${e}`),e):null}function po(e){let t="UNKNOWN";try{let a=document.getElementById("context");if(a){let i=JSON.parse(a.innerText).country;i&&typeof i=="string"&&(t=i)}}catch{console.log("frontend context missing or not parsed")}return e.searchParams.has("dev-force-location")&&(console.log(t),t=e.searchParams.get("dev-force-location").toUpperCase(),console.log(t)),t}var Ma=!1;function Et(e,t=void 0,a=!1){e._form===void 0&&(e._form=e.parentElement.innerHTML);let i=new URL(window.location.href),r=le(i),s=po(i),o=l=>(l.startsWith("dev-")&&(l=l.substring(4)),l.startsWith("data-")&&(l=l.substring(5)),i.searchParams.has(`dev-${l}`)||i.searchParams.has(`data-${l}`)||e.hasAttribute(`data-${l}`)),n=void 0,c=void 0,h=o("skip-getting-started");h=!0;let g=o("skip-to-bant")||i.pathname==="/scheduler"&&i.searchParams.has("continue");if(i.pathname!=="/builder-studio-product/create-app"&&i.pathname.startsWith("/builder-studio-product/create-app")&&(h=!0),i.pathname==="/scheduler"){let l=i.searchParams.get("current-step");if(!l)return;if(h=!0,l.startsWith("bant"))e.setAttribute("data-experiment-digital-bant",""),r==="StudioPro"?(e.setAttribute("data-experiment-digital-bant",""),e.setAttribute("data-experiment-calendly-for-pro",""),e.setAttribute("data-experiment-use-scheduler","")):(e.setAttribute("data-experiment-digital-bant",""),l.startsWith("bant_3")&&(e.setAttribute("data-experiment-calendly-for-pro",""),e.setAttribute("data-experiment-use-scheduler",""))),l.startsWith("bant_2")?e.setAttribute("data-bant2",""):l.startsWith("bant_3")&&(e.setAttribute("data-bant2",""),e.setAttribute("data-bant2-with-product-override",""));else if(l.startsWith("demo_booking"))if(r==="StudioPro")e.setAttribute("data-experiment-calendly-for-pro",""),e.setAttribute("data-experiment-use-scheduler","");else{e.parentElement.innerHTML="<book-demo-calendar></book-demo-calendar>";return}}else(s==="IN"||!0)&&(e.getAttribute("data-formtype")&&e.getAttribute("data-formtype").includes("partner")||i.pathname.startsWith("/events/upcoming")||i.pathname.startsWith("/contact-us")||(r==="StudioPro"?(e.setAttribute("data-experiment-digital-bant",""),e.setAttribute("data-experiment-calendly-for-pro",""),e.setAttribute("data-experiment-use-scheduler","")):(e.setAttribute("data-experiment-digital-bant",""),i.pathname==="/builder-studio-product/create-app3"&&(e.setAttribute("data-experiment-calendly-for-pro",""),e.setAttribute("data-experiment-use-scheduler",""))),e.setAttribute("data-bant2","")));if(g&&window.sessionStorage&&i.searchParams.has("email")){let l=i.searchParams.get("email");l&&(l=l.replace("%20","%2B"),window.sessionStorage.setItem("Email",l))}Ma||(Ma=!0,r==="StudioPro"?(document.addEventListener("popup-form-open",function(l){k({event:"get_started_pro_multipleoptions_opened"})},{once:!0}),document.addEventListener("popup-form-close",function(l){k({event:"get_started_pro_multipleoptions_closed"})},{once:!0})):r==="StudioStore"&&(document.addEventListener("popup-form-open",function(l){k({event:"get_started_store_multipleoptions_opened"})},{once:!0}),document.addEventListener("popup-form-close",function(l){k({event:"get_started_store_multipleoptions_closed"})},{once:!0}))),Fa(e)==="AC28"||i.pathname==="/entrepreneur"||e.setAttribute("data-FormRef","B01"),i.pathname.startsWith("/formsb/")&&e.setAttribute("data-FormRef","B01"),e.getAttribute("data-formtype")==="book-demo"&&window.sessionStorage&&window.sessionStorage.getItem("data-store-digital-demo")!==null&&e.setAttribute("data-store-digital-demo","");let x=e.hasAttribute("data-store-digital-demo")||i.searchParams.has("dev-store-digital-demo");if(x){window.sessionStorage&&window.sessionStorage.setItem("data-store-digital-demo",""),e.setAttribute("data-RedirectURL-overwritten",""),e.setAttribute("data-RedirectURL","/store-natasha-dls"),e.setAttribute("data-formtype","store-digital-demo"),e.setAttribute("data-submitcta","Take a free tour"),e.setAttribute("data-formtitle","Take a free tour");let l=document.body.querySelector("#formtitle");l&&(l.innerText="Take a free tour")}if(i.pathname.startsWith("/events/upcoming")){let l=document.body.querySelector("#formtitle"),u="Book now";i.searchParams.get("event")==="uts-ny-2024"&&(u="Submit"),l&&(l.innerText=u)}document.body.hasAttribute("data-disable-forms-get-started")&&(document.body.removeAttribute("data-disable-forms-get-started"),e.setAttribute("data-disable-forms-get-started","")),g&&e.setAttribute("data-disable-forms-get-started",""),(!e.getAttribute("data-formtype")||e.getAttribute("data-formtype")&&e.getAttribute("data-formtype").includes("partner")===!1)&&i.searchParams.has("at-event")===!1&&i.searchParams.has("dev-disable-forms-get-started")===!1&&e.hasAttribute("data-disable-forms-get-started")===!1&&e.getAttribute("data-FormRef")!=="AC28"&&!i.pathname.startsWith("/guidebook/")&&i.pathname!=="/gartnermq2021"&&i.pathname!=="/brex"&&i.pathname!=="/the-right-vendor"&&i.pathname!=="/gartner-multiexperience-development-platform"&&i.pathname!=="/gartner-how-innovation-will-transform-the-software-engineering-life-cycle"&&i.pathname!=="/uts"&&i.pathname!=="/aisummit"&&i.pathname!=="/new-builder-studio"&&i.pathname!=="/msft-ai-webinar"&&i.pathname!=="/turning-your-voice-into-code"&&i.pathname!=="/events/qic-appathon"&&i.pathname!=="/events/dreambuilder25"&&i.pathname!=="/davos-2024-panel-discussion-rsvp"&&(r==="StudioPro"&&i.pathname!=="/formsb/download-guide"&&i.pathname!=="/microsoft-for-startups"&&i.pathname!=="/studio-store-product/partnership-with-mastercard"&&!i.pathname.includes("partner")&&!i.pathname.startsWith("/events")||r==="StudioStore"&&i.pathname!=="/formsb/download-guide-studio-store"&&i.pathname!=="/studio-store-product/partnership-with-idfc"&&i.pathname!=="/studio-store-product/partnership-with-idfc/restaurant"&&i.pathname!=="/studio-store-product/store-field-marketing"&&!i.pathname.startsWith("/events"))&&(e.setAttribute("data-forms-get-started",""),e.setAttribute("data-FormRef","B01"));let b;if(e.hasAttribute("data-forms-get-started")&&!a&&!e.hasAttribute("data-chosen")){b=document.createElement("div"),b.style.display="none";let l=[{text:"Book a 1:1 demo with an expert",option:"book-demo",svg:Ca},{text:"Watch a Builder.ai video",option:"watch-video",svg:Da},{text:"Get our free guide on how to sell online and make your app a success",option:"download-guide-store",svg:go}];["/studio-store-product/one-stop-ecommerce-shop"].includes(i.pathname)&&(l[1].text="Watch ecommerce product demo"),x&&(l[2].text="Take a free tour",l[2].option="store-digital-demo",l=[l[0],l[2],l[1]]),r==="StudioPro"&&(l=[{text:"Request a free demo from an expert",option:"book-demo-pro",svg:Ca},{text:"Watch a 2-min Builder.ai demo ",option:"watch-video-pro",svg:Da},{text:"Get matched to the right Builder.ai product for you",option:"take-quiz",svg:mo}]);let u=F=>{let T=L(F.option);return oe`
                    <li class="mx-3 grid grid-cols-1 items-center">
                        <input
                            aria-hidden="true"
                            class="peer sr-only"
                            type="radio"
                            value="${F.text}"
                            name="option"
                            id="${T}"
                        />
                        <label
                            tabindex="0"
                            data-option="${F.option}"
                            style="margin-bottom: 0"
                            for="${T}"
                            class="col-span-full row-start-1 h-full w-full cursor-pointer rounded-lg border border-bluegray-2 bg-gray-1 py-6 pl-16 pr-4 hover:to-bluegray-3 peer-checked:border-builderpurple-a2 peer-checked:bg-builderpurple-a2 peer-checked:bg-opacity-10 text-bluegray-9"
                            >${F.text}</label
                        >
                        <div
                            aria-hidden="true"
                            class="pointer pointer-events-none col-span-full row-start-1 mx-3 mb-0 h-min w-min rounded-full bg-gray-2 p-3 text-bluegray-9 peer-checked:bg-builderpurple-a5 peer-checked:text-gray-1"
                        >
                            ${F.svg}
                        </div>
                    </li>
                `};b.innerHTML=oe`
                <div class="tailwind">
                    <div class="flex justify-center">
                        <div class="w-full max-w-lg">
                            <div style="font-size: 24px" class="mx-3 font-rubik font-semibold text-xl">Hello!</div>
                            <br />
                            <div class="mx-3 font-rubik text-builderpurple-a5 font-semibold">
                                How would you like to get started?
                            </div>

                            <ul class="py-4 grid w-full gap-2">
                                ${u(l[0])} ${u(l[1])} ${u(l[2])}
                            </ul>

                            <div class="my-8">
                                <div class="mx-3 text-center my-4">
                                    <button
                                        type="submit"
                                        class="_submit font-rubik  bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"
                                    >
                                        Confirm
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `,e.parentElement.insertBefore(b,e),e.style.display="none";let d="",v=i.searchParams.has("dev-experiment-digital-bant")||e.hasAttribute("data-experiment-digital-bant"),S={"book-demo":{title:"Book a demo",subtitle:void 0,formType:"store-demo",submitCTA:v?"Submit":"Book a 1:1 demo"},"book-demo-pro":{title:"Request a free demo from an expert",subtitle:"Answer a few questions and pick a date and time to speak with our expert on a 15 min call",formType:"pro-demo",submitCTA:v?"Submit":"Book a 1:1 demo"},"download-guide-store":{title:"Talk to us over live chat",subtitle:void 0,formType:"store-download-guide",submitCTA:"Download guide"},"store-digital-demo":{title:"Take a free tour",subtitle:void 0,formType:"store-digital-demo",submitCTA:"Take a free tour"},"download-guide":{title:"Download the guide",subtitle:void 0,formType:"pro-download-guide",submitCTA:"Download guide"},"take-quiz":{title:"Get matched",subtitle:void 0,formType:"pro-take-quiz",submitCTA:"Get matched"},"watch-video":{title:"Watch a Builder.ai explainer video to learn more",subtitle:void 0,formType:"store-explainer-video",submitCTA:"Watch Builder.ai demo"},"watch-video-pro":{title:"Watch a Builder.ai explainer video to learn more",subtitle:void 0,formType:"pro-explainer-video",submitCTA:"Watch Builder.ai demo"}},E=b.querySelector("button"),R=()=>{if(!d){e.removeAttribute("data-chosen");return}e=e.update(!0);let F=S[d].submitCTA;["/builder-studio-product/make-app-form-mena","/builder-studio-product/app-development-form-mena","/builder-studio-product/app-development-form-india","/builder-studio-product/software-development-form-mena","/builder-studio-product/software-development-form-uk","/builder-studio-product/create-app-form-uk","/builder-studio-product/create-app-form-india","/builder-studio-product/create-app-form-anz","/builder-studio-product/make-app-form-uk","/builder-studio-product/enterprise-resource-planning-uk","/builder-studio-product/startup-seedlist-uk","/builder-studio-product/micro-smb-usa","/builder-studio-product/software-development-form-india","/builder-studio-product/software-development-form-anz","/builder-studio-product/micro-smb-india"].includes(i.pathname)&&(F="Get my product demo"),e.setAttribute("data-chosen",""),e.setAttribute("data-SubmitCTA",F),Ra(e,F),e.setAttribute("data-option",d);let T=e.querySelector("[data-id='title']");if(T?(T.innerHTML=S[d].title,T.style.display="block"):console.log("form title missing"),e.hasAttribute("data-experiment-calendly-for-pro")||i.searchParams.has("dev-experiment-calendly-for-pro")){let I=e.querySelector("[data-id='subtitle']"),A=S[d].subtitle;I&&A&&(I.innerHTML=A,I.style.display="block")}if(S[d].formType&&e.setAttribute("data-FormType",S[d].formType),(i.searchParams.has("dev-shorten-form")||e.hasAttribute("data-experiment-shorten-form"))&&["download-guide-store","download-guide"].includes(d)&&et(e),d==="watch-video"||d==="watch-video-pro")if(e.setAttribute("data-RedirectURL-overwritten",""),e.setAttribute("data-original-RedirectURL",e.getAttribute("data-RedirectURL")??""),d==="watch-video"){let I=i.searchParams.has("dev-old-store-ecommerce-video")||e.hasAttribute("data-old-store-ecommerce-video");e.setAttribute("data-RedirectURL",I?"/studio-store-product/explainer-video":"/studio-store-product/explainer-video?ecommerce")}else d==="watch-video-pro"&&e.setAttribute("data-RedirectURL","/video-explainer");else d==="store-digital-demo"&&e.setAttribute("data-RedirectURL","/store-natasha-dls");if(h===!1&&(d==="book-demo-pro"?k({event:"get_started_pro_demo_selected"}):d==="watch-video-pro"?k({event:"get_started_pro_video_selected"}):d==="download-guide"?k({event:"get_started_pro_guide_selected"}):d==="take-quiz"?k({event:"get_started_pro_quiz_selected"}):d==="book-demo"?k({event:"get_started_store_demo_selected"}):d==="download-guide-store"?k({event:"get_started_store_guide_selected"}):d==="watch-video"?k({event:"get_started_store_video_selected"}):d==="store-digital-demo"&&k({event:"get_started_store_digital_demo_selected"})),window.sessionStorage)try{r==="StudioPro"?window.sessionStorage.setItem("get_started","get_started_pro"):r==="StudioStore"&&window.sessionStorage.setItem("get_started","get_started_store")}catch(I){console.log(I)}if(d==="download-guide"||d==="download-guide-store"||d==="take-quiz"){e.style.visibility="hidden",e.style.display="none",e.remove(),d==="download-guide"?i.pathname="/formsb/download-guide":d==="download-guide-store"?i.pathname="/formsb/download-guide-studio-store":d==="take-quiz"&&(i.pathname="/quiz"),window.location.href=i.href;return}if(e.hasAttribute("data-experiment-motivation-micro-copy")&&d==="book-demo"){e.style.visibility="hidden",e.style.display="none",e.remove(),i.pathname="/formsb/studio-store-1",window.location.href=i.href;return}e.style.display="block",b.remove(),h===!1&&(d==="book-demo-pro"?document.addEventListener("popup-form-closed",function(I){k({event:"get_started_pro_demo_formclosed"})}):d==="watch-video-pro"?document.addEventListener("popup-form-closed",function(I){k({event:"get_started_pro_video_formclosed"})}):d==="book-demo"?document.addEventListener("popup-form-closed",function(I){k({event:"get_started_store_demo_formclosed"})}):d==="watch-video"?document.addEventListener("popup-form-closed",function(I){k({event:"get_started_store_video_formclosed"})}):d==="store-digital-demo"&&document.addEventListener("popup-form-closed",function(I){k({event:"get_started_store_digital_demo_formclosed"})}),e.addEventListener("focusout",function(I){let re=I.target.getAttribute("name");if(re){for(let qe of xe)if(qe.name===re){let ke=e.getAttribute("data-option");ke==="book-demo-pro"?k({event:"get_started_pro_demo_forminteracted"}):ke==="watch-video-pro"?k({event:"get_started_pro_video_forminteracted"}):d==="book-demo"?k({event:"get_started_store_demo_forminteracted"}):d==="watch-video"?k({event:"get_started_store_video_forminteracted"}):d==="store-digital-demo"&&k({event:"get_started_store_digital_demo_forminteracted"});break}}},{once:!0}),e.addEventListener("submit",function(I){let A=e.getAttribute("data-option");A==="book-demo-pro"?k({event:"get_started_pro_demo_formsubmitted"}):A==="watch-video-pro"?k({event:"get_started_pro_video_formsubmitted"}):d==="book-demo"?k({event:"get_started_store_demo_formsubmitted"}):d==="watch-video"?k({event:"get_started_store_video_formsubmitted"}):d==="store-digital-demo"&&k({event:"get_started_store_digital_demo_formsubmitted"})}),d==="book-demo-pro"?k({event:"get_started_pro_demo_formviewed"}):d==="watch-video-pro"?k({event:"get_started_pro_video_formviewed"}):d==="book-demo"?k({event:"get_started_store_demo_formviewed"}):d==="watch-video"?k({event:"get_started_store_video_formviewed"}):d==="store-digital-demo"&&k({event:"get_started_store_digital_demo_formviewed"}))};E.addEventListener("click",R);let j=b.querySelectorAll("[data-option");j.forEach((F,T)=>{F.addEventListener("click",I=>{d=F.getAttribute("data-option")})}),h?(d=j[0].getAttribute("data-option"),window.setTimeout(()=>{e.setAttribute("data-getting-started-skipped",""),R()},1)):b.style.display="block"}if(e.setAttribute("method","POST"),e.hasAttribute("data-FormRef")){if(Me&&e.setAttribute("data-FormRef","B01"),M&&(e.setAttribute("data-FormRef","B01"),e.setAttribute("autocomplete","off")),new URL(window.location.href).searchParams.has("dev-new-form-design")&&e.setAttribute("data-FormRef","B01"),e.getAttribute("data-FormRef").startsWith("AC")&&e.setAttribute("class","_form_ac_ _inline-form  _dark"),e.getAttribute("data-FormRef").startsWith("B")){e.setAttribute("class","");let l=document.querySelector(".d-form-wrapper-pop-up"),u=e.closest(".form-grid-wrapper");u&&(u.style.display="block");let d=document.querySelector("#slide-in-form-title");d&&e.hasAttribute("data-forms-get-started")&&d.remove()}new URL(window.location.href).pathname==="/make-your-mother-proud"&&e.setAttribute("data-FormType","mothers_day_campaign_india"),new URL(window.location.href).pathname==="/make-your-mother-proud-usa"&&e.setAttribute("data-FormType","mothers_day_campaign_usa")}new URL(window.location.href).pathname==="/events/emerge2022"?e.setAttribute("data-FormType","emerge2022"):new URL(window.location.href).pathname==="/forms/emerge2022-event"&&e.setAttribute("data-FormType","emerge2022-event"),new URL(window.location.href).pathname==="/events/comex2022"?e.setAttribute("data-FormType","comex2022"):new URL(window.location.href).pathname==="/forms/comex2022-event"&&e.setAttribute("data-FormType","comex2022-event"),new URL(window.location.href).pathname==="/events/asiatech2022"?e.setAttribute("data-FormType","asiatech2022"):new URL(window.location.href).pathname==="/forms/asiatech2022-event"&&e.setAttribute("data-FormType","asiatech2022-event"),e.getAttribute("data-FormRef")==="AC28"&&e.setAttribute("style","margin-left: 0px; margin-right: 0px;");let _=e.getAttribute("data-RedirectURL");(!_||_.trim()==="")&&(_="/thank-you"),M&&(i.pathname==="/events/uts-2023"?_="/thank-you":_=`/at-event#${se}`),_=new URL(_,window.location.href).href,e.setAttribute("data-RedirectURL",_),i.pathname==="/uts"?(e.setAttribute("data-formref","UTS"),e.setAttribute("data-RedirectURL","/thank-you-uts"),h=!0):i.pathname==="/aisummit"?(e.setAttribute("data-formref","AISUMMIT"),e.setAttribute("data-RedirectURL","/thank-you-aisummit"),h=!0):i.pathname==="/davos-2024-panel-discussion-rsvp"?(e.setAttribute("data-formref","DAVOS2024PANELDISCUSSIONRSVP"),e.setAttribute("data-RedirectURL","/thank-you"),h=!0):i.pathname==="/new-builder-studio"?(e.setAttribute("data-formref","STUDIO4WAITLIST"),e.setAttribute("data-formtype","waitlist-campaign-studio4")):i.pathname==="/turning-your-voice-into-code"?(e.setAttribute("data-formref","CODEGENWAITLIST"),e.setAttribute("data-formtype","waitlist-campaign-codegen")):i.pathname==="/events/qic-appathon"?(e.setAttribute("data-formref","MENAInsurtechSummit2024AppathonInterest"),e.setAttribute("data-formtype","MENAInsurtechSummit2024AppathonInterest")):i.pathname==="/events/dreambuilder25"&&(e.setAttribute("data-formref","Startup Grind Global Conference 2025"),e.setAttribute("data-formtype","dreambuilder25-preregistration"));let O=Fa(e),w=[];if(M)for(let l of Ue)(i.pathname.startsWith("/events/upcoming")||l.event.includes(se))&&w.push(l);w.sort((l,u)=>l.email.localeCompare(u.email)),je.sort((l,u)=>l.email.localeCompare(u.email)),w=je.concat(w);let D=new URLSearchParams;for(let l=0;l<e.attributes.length;l++){let u=e.attributes[l].name,d=e.attributes[l].value;u.startsWith("data-experiment")&&D.set(u,d)}x&&D.set("data-experiment-store-digital-demo",""),i.searchParams.has("dev-experiment-digital-bant")||e.hasAttribute("data-experiment-digital-bant")?D.set("data-experiment-digital-bant",""):r==="StudioStore"&&D.set("data-experiment-stage-of-business-question","");let P=!1;for(let l of["/quiz","/entrepreneur","/smb","/about-us","/compare"])if(i.pathname===l){P=!0;break}if(!P){for(let l of["/blog","/app-builder"])if(i.pathname.includes(l)){P=!0;break}i.pathname.includes("builder-studio-product")&&i.pathname!=="/builder-studio-product/create-app"&&(P=!0)}if(r==="StudioStore"&&(P=!1),P&&oa(),new URL(window.location.href).pathname==="/ref"){D.set("data-experiment-referral","");let l=!1;for(let u of[1e3,3e3,5e3,1e4])window.setTimeout(()=>{if(l)return;let d=new URL(window.location.href).searchParams.get("code");if(!d)return;let v=e.querySelector("[name='ReferralCode']");v&&(v.value=d,v.setAttribute("disabled",""),v.style.color="#83889E",l=!0)},u)}t||(t=e.getAttribute("data-phone-code"),t.startsWith("+")||(t=`+${t}`)),pa(e,O,t,M,w,D);let q=!0;if((g||M||i.pathname==="/aisummit"||i.pathname==="/new-builder-studio"||i.pathname==="/davos-2024-panel-discussion-rsvp")&&(q=!1),e.setAttribute("data-experiment-form-validation",""),i.searchParams.has("dev-disable-experian")&&(q=!1),i.searchParams.has("dev-enable-experian")&&(q=!0),q&&e.getAttribute("data-FormRef")!=="AC28"&&e.hasAttribute("data-experiment-form-validation")||i.searchParams.has("dev-form-validation")){let{validatePhone:l,validateEmail:u}=Ba(e,!0);e.addEventListener("submit",async d=>{if(d.preventDefault(),St)return;let v=e.querySelectorAll("[type='submit']").forEach(A=>{A.setAttribute("data-textContent",A.textContent),A.textContent="Please wait",A.setAttribute("disabled",""),ve(!0)}),[[S,{ExperianPhoneConfidenceLevel:E,ExperianPhoneType:R}],[j,{ExperianEmailConfidenceLevel:F,ExperianEmailConfidenceLevelVerbose:T}]]=await Promise.all([l(5),u(5)]);if(console.log({phoneIsValid:S,emailIsValid:j}),!S){e.querySelectorAll("[type='submit']").forEach(A=>{A.textContent=A.getAttribute("data-textContent")??"Submit",A.removeAttribute("disabled"),ve(!1)}),e.querySelector('input[type="tel"]').focus();return}if(!j){e.querySelectorAll("[type='submit']").forEach(A=>{A.textContent=A.getAttribute("data-textContent")??"Submit",A.removeAttribute("disabled"),ve(!1)}),e.querySelector('input[type="email"]').focus();return}let I={ExperianPhoneConfidenceLevel:E,ExperianPhoneType:R,ExperianEmailConfidenceLevel:F,ExperianEmailConfidenceLevelVerbose:T};i.searchParams.has("dev-experian")?console.log(I):await Ze.call(e,d,I)})}else if(e.getAttribute("data-FormRef")!=="AC28"&&(q||i.searchParams.has("dev-experian-fields"))){let{validatePhone:l,validateEmail:u}=Ba(e,!1);e.addEventListener("submit",async d=>{d.preventDefault();let v=e.querySelectorAll("[type='submit']").forEach(A=>{A.setAttribute("data-textContent",A.textContent),A.textContent="Please wait",A.setAttribute("disabled",""),ve(!0)}),[[S,{ExperianPhoneConfidenceLevel:E,ExperianPhoneType:R}],[j,{ExperianEmailConfidenceLevel:F,ExperianEmailConfidenceLevelVerbose:T}]]=await Promise.all([l(5),u(5)]);M&&S!==!0&&(E=void 0);let I={ExperianPhoneConfidenceLevel:E,ExperianPhoneType:R,ExperianEmailConfidenceLevel:F,ExperianEmailConfidenceLevelVerbose:T};i.searchParams.has("dev-experian")?console.log(I):await Ze.call(e,d,I)})}else e.addEventListener("submit",l=>{let u=e.querySelectorAll("[type='submit']").forEach(d=>{d.setAttribute("data-textContent",d.textContent),d.textContent="Please wait",d.setAttribute("disabled",""),ve(!0)});Ze.call(e,l)});M||Ea(e);let V=e.getAttribute("data-SubmitCTA");V&&V.trim()!==""&&Ra(e,V);let U=e.hasAttribute("data-experiment-product-idea-required");if(e.getAttribute("data-FormRef").startsWith("AC")){let l=e.querySelector("select[name='StageOfIdea']"),u=e.querySelector("[data-form-element='ProductIdea']");if(l&&u){let d=()=>{l.options[l.selectedIndex].getAttribute(U?"data-ProductIdea-v2":"data-ProductIdea")==="hide"?(u.querySelector("textarea").removeAttribute("required"),u.style.display="none"):(u.querySelector("textarea").setAttribute("required",""),u.style.display="block")};d(),l.addEventListener("change",d)}if(U){let d=e.querySelector("[data-form-element='ProductIdea']");d.firstElementChild.innerText=d.firstElementChild.innerText.trim()+"*";let v=document.createElement("div");v.innerHTML=oe`
                <a><p style="font-size: 12px; margin-bottom: 0">We take idea privacy seriously</p></a>
                <p style="line-height: unset; font-size: 12px; margin-bottom: 0; display: none">
                    We'll give you an option to sign a standard mutual non-disclosure agreement so that all the
                    sensitive information exchanged during calls is legally protected.
                </p>
            `,d.appendChild(v),v.addEventListener("click",S=>{S.stopPropagation(),S.stopImmediatePropagation(),v.children[1].style.display="block"})}}else{let l=e.StageOfIdea,u=e.querySelector("[data-form-element='ProductIdea']"),d=e.querySelector("[data-form-element='Funding']");d&&d.querySelectorAll("input").forEach(F=>F.required=!1);let v,S=e.hasAttribute("data-experiment-conditional-bant-questions")||i.searchParams.has("dev-conditional-bant-questions");if(l&&u){let F=null;for(var $=0;$<l.length;$++)l[$].addEventListener("change",function(T){this!==F&&(F=this);let I=this.value;if(["Ready to build now","Need help picking features","I have an idea but I'm not sure where to start","I'm ready to build my idea now"].includes(I)){if(u.style.display="block",S&&(u.querySelector("textarea").setAttribute("required",""),d)){d.style.display="block";let A=Array.from(d.querySelectorAll("input[type='radio']"));Oa(A),v||(v=function(re){Oa(A)},d.addEventListener("change",v))}}else u.style.display="none",S&&(u.querySelector("textarea").removeAttribute("required"),d&&(d.style.display="none",v&&(d.removeEventListener("change",v),v=void 0,Array.from(d.querySelectorAll("input[type='radio']")).forEach(re=>re.required=!1))))})}let E=e.querySelector('[data-form-element="CompanyName"]'),R=e.querySelector('[data-form-element="CompanySize"]'),j=e.querySelector('[data-form-element="StageOfBusiness"]');if(i.searchParams.has("dev-conditional-company-name")&&j&&E){let F=T=>{let I=T.target,A=I.getAttribute("data-CompanyName");I.checked&&(A==="hide"?(E.parentElement.removeAttribute("required"),E.parentElement.style.display="none",R.parentElement.removeAttribute("required"),R.parentElement.style.display="none"):(E.parentElement.setAttribute("required",""),E.parentElement.style.display="block",R.parentElement.setAttribute("required",""),R.parentElement.style.display="block"))};j.querySelectorAll("input").forEach(function(T){T.addEventListener("change",F)})}}if(t||(t=e.getAttribute("data-phone-code"),t.startsWith("+")||(t=`+${t}`)),t||(t=document.body.getAttribute("country-code")),t){let l=e.querySelector('select[name="CountryCode"]');l&&(l.value=t)}let m=ho(),ae=e.querySelector("select[name='CountryCode']");if(e.getAttribute("data-FormRef")?.startsWith("B")&&ae&&(m(ae),ae.changed=()=>m(ae),ae.addEventListener("change",function(l){let u=l.target;m(u)})),g){let l=document.getElementById("formtitle");l&&l.remove();let d=At(!0,n,c,!0,i,e,r,!0),v=document.querySelector("[data-form-fields-container]");v&&v.remove(),d.setAttribute("data-form-fields-container","")}if(!M)for(let l of["FirstName","LastName","Phone","Email","CountryCode","CompanyName"]){let u;if(l==="CountryCode"?u=e.querySelector('select[name="CountryCode"]'):u=e.querySelector(`input[name='${l}']`),u){if(u.value=qa(l),u.value||(u.value=qa(l.toLowerCase())),u.value)continue;if(window.sessionStorage){let d=window.sessionStorage.getItem(l);d||(d=window.sessionStorage.getItem(l.toLowerCase())),d&&(u.value=d)}}}if(e.hasAttribute("data-experiment-student-option-last")){let l=e.querySelector("option[value='Student']");if(l){let u=l.parentElement;u.getAttribute("name")==="WhatBestDescribesYou"&&u.appendChild(l)}}if(e.update=(l=!1,u)=>{let d={};u&&(d=u);let v=e.querySelector('select[name="CountryCode"]'),S=v?v.value:void 0;if(e.innerHTML="",!b){let E=e.parentElement.firstChild;E&&E.localName!=="form"&&(b=E)}return b&&(e.style.display="block",b.remove()),e=fo(e),d.formtype&&e.setAttribute("data-FormType",d.formtype),d.submitcta&&e.setAttribute("data-SubmitCTA",d.submitcta),Et(e,S,l),e},e.enableMultiStepExperiment=()=>{let l=e.querySelector("input[name='Email']"),u=document.createElement("button");u.innerHTML="Book a free demo",u.type="button",u.setAttribute("style","margin-top: 2rem; margin-bottom: 2rem;"),u.setAttribute("class","_submit font-rubik bg-buildergreen-a45 hover:bg-buildergreen-a5 text-gray-10 font-bold text-sm px-10 py-3 rounded w-full"),l.parentElement.append(u);let d=e.querySelector("[data-form-step='about-you']"),v=e.querySelector("[data-form-step='about-your-company']"),S=e.querySelector("[data-form-step='about-your-idea']"),E=S.nextElementSibling,R=e.querySelector("[type='submit']");R&&(R.innerHTML="Submit"),d.style.display="block",v.style.display="none",S.style.display="none",E.style.display="none";for(let j of["CompanyName","CompanySize","WhatBestDescribesYou","StageOfIdea"])e.querySelectorAll(`[name='${j}']`).forEach(T=>T.setAttribute("disabled",""));u.addEventListener("click",j=>{if(!Pa(e)){e.reportValidity();return}Xe||(z(window,gt),Xe=!0);for(let T of["CompanyName","CompanySize","WhatBestDescribesYou","StageOfIdea"])e.querySelectorAll(`[name='${T}']`).forEach(A=>A.removeAttribute("disabled"));d.style.display="none",v.style.display="block",S.style.display="block",E.style.display="block"})},Me&&(e.hasAttribute("data-experiment-multi-step-forms")?e.enableMultiStepExperiment&&e.enableMultiStepExperiment():e.addEventListener("focusout",function(l){if(!l.target.getAttribute("name"))return;Pa(e)&&(Xe||(z(window,gt),Xe=!0))}),e.addEventListener("focusout",function(l){let d=l.target.getAttribute("name");if(!d)return;["FirstName","LastName","CountryCode","Phone","Email"].includes(d)?Ta||(z(window,Jt),Ta=!0):La||(z(window,Qt),La=!0)})),M){let l=e.querySelector("[name='AtEventBuilderAIRepresentative']");if(l){let d=window.localStorage.getItem("AtEventBuilderAIRepresentative");d&&(l.value=d)}let u=e.querySelector("[name='EventYouWillBeAttending']");if(u){let d=window.localStorage.getItem("EventYouWillBeAttending");d&&(u.value=d)}}new URL(window.location.href).pathname==="/formsb/studio-store-1"&&e.querySelectorAll("[data-motivation-micro-copy]").forEach(function(l){l.style.display="block"}),i.pathname==="/scheduler"&&g===!1?bo(e):e.getAttribute("data-formtype")&&e.getAttribute("data-formtype").includes("partner")&&et(e,!0)}function Pa(e){let t=e.querySelector("[name='FirstName']"),a=e.querySelector("[name='LastName']"),i=e.querySelector("[name='CountryCode']"),r=e.querySelector("[name='Phone']"),s=e.querySelector("[name='Email']"),o=!0;for(let n of[t,a,i,r,s]){if(!n)return!1;n.checkValidity()||(o=!1)}return o}function Ra(e,t){let a=e.getElementsByClassName("_submit");a!==null&&a.length===1&&(a[0].textContent=t)}function qa(e){for(var t=e+"=",a=decodeURIComponent(document.cookie),i=a.split(";"),r=0;r<i.length;r++){for(var s=i[r];s.charAt(0)==" ";)s=s.substring(1);if(s.indexOf(t)==0)return s.substring(t.length,s.length)}return""}function ho(){let e=null;function t(a){let i=a.options[a.selectedIndex];a.selectedIndex===0&&a.value&&a.querySelectorAll("option").forEach(function(s){"+"+s.getAttribute("data-country-code")==a.value.trim()&&(i=s)});let r=a.previousElementSibling;if(r){if(e){e.innerText="+"+e.getAttribute("data-country-code")+" "+e.getAttribute("data-country-name");let s=e.getAttribute("data-country-ref");s==="ca"&&(s="us"),r.classList.remove("flag-icon-"+s)}if(i&&i.innerText.trim()){e=i,i.innerText="+"+i.getAttribute("data-country-code");let s=i.getAttribute("data-country-ref");s==="ca"&&(s="us"),r.classList.add("flag-icon-"+s)}}}return t}function Oa(e){let t=!1;for(let a=0;a<e.length;a++)e[a].checked===!0&&(t=!0);if(t)for(let a=0;a<e.length;a++)e[a].required=!1;else for(let a=0;a<e.length;a++)e[a].required=!0}var ye={demo:{phone:{empty:"Why do we need this? So our expert can call you.",invalid:"Can you check this number? Our expert needs it for your 1:1 call.",valid:""},email:{empty:"Why do we need your email? It\u2019s only used to update you about this call.",invalid:"Can you give us your real email? We only use it to update you about your 1:1 call.",valid:""}},guide:{phone:{empty:"Can you add your number?",invalid:"Can you check this number?",valid:""},email:{empty:"Why do we need your email? To send over a copy of your free guide.",invalid:"Can you give us your real email? We\u2019ll send over your free guide.",valid:""}},video:{phone:{empty:"Can you add your number?",invalid:"Can you check this number?",valid:""},email:{empty:"Why do we need your email? To send you a link to the video.",invalid:"Can you give us your real email? We\u2019ll send you a link to the video.",valid:""}}};new URL(window.location.href).pathname.startsWith("/events/")&&(ye.demo.email.empty="",ye.demo.email.invalid="",ye.demo.email.valid="",ye.demo.phone.empty="",ye.demo.phone.invalid="",ye.demo.phone.valid="");var vo={empty:`
        /*border-color: #ef6c00;
        background: url("/images/exclamation-circle-outline.svg") no-repeat calc(100% - 15px) center;
        background-color: white;
    `,invalid:`
        border-color: #ef6c00;
        background: url("/images/exclamation-circle-outline.svg") no-repeat calc(100% - 15px) center;
        background-color: white;
        padding-right: 40px;
    `,valid:`
        background: url("/images/tick-green.svg") no-repeat calc(100% - 15px) center;
        background-color: white;
        padding-right: 40px;
    `},It={empty:`
        display: block;
        color: #ef6c00;
        font-size: 12px;
        margin-top: 4px;
    `,invalid:`
        display: block;
        color: #ef6c00;
        font-size: 12px;
        margin-top: 4px;
    `,valid:`
        display: none;
    `},$a=(e,t,a,i,r)=>{a.forEach(o=>o.style=vo[t]),i.style=It[t],console.log({style:It[t]}),console.log({formFieldValidationMessageStyles:It}),console.log({validationState:t});let s="demo";r.indexOf("guide")>-1?s="guide":r.indexOf("video")>-1&&(s="video"),i.innerText=ye[s][e][t]},yo=e=>!e.trim().length,Ae=new Map;function Ba(e,t){let a=e.querySelectorAll('[data-form-step="about-you"] [data-motivation-micro-copy]'),i=e.querySelector('input[type="tel"]'),r=e.querySelector('select[name="CountryCode"]'),s=[i,r],o=a[0],n=e.querySelector('input[type="email"]'),c=a[1],h=async(b,_,O,w,D)=>{let P=yo(_.value),q=!0,V,U,$,m,ae=e.getAttribute("data-option")?e.getAttribute("data-option"):"book-demo";if(P)return t&&$a(b,"empty",O,w,ae),[!1,{ExperianPhoneConfidenceLevel:V,ExperianPhoneType:U,ExperianEmailConfidenceLevel:$,ExperianEmailConfidenceLevelVerbose:m}];if(b==="phone"){let u={number:r.value+i.value,output_format:"NATIONAL",cache_value_days:0,get_ported_date:!1,get_disposable_number:!1},d;if(Ae.has(JSON.stringify(u)))d=Ae.get(JSON.stringify(u));else try{let v=await fetch("https://api.experianaperture.io/phone/validate/v2",{body:JSON.stringify(u),headers:{Accept:"application/json","Timeout-Seconds":`${D}`,"Auth-Token":"dea92562-81ad-45f0-bd74-292256e68e9d","Content-Type":"application/json"},method:"POST"});v.ok&&(d=await v.json(),Ae.set(JSON.stringify(u),d))}catch(v){console.error(v)}d&&(console.log(d),V=d.result.confidence,U=d.result.phone_type,["Verified","Absent","Unknown","No coverage"].includes(d.result.confidence)?q=!0:q=!1)}else if(b==="email"){let u={email:n.value},d;if(Ae.has(JSON.stringify(u)))d=Ae.get(JSON.stringify(u));else try{let S=await fetch("https://api.experianaperture.io/email/validate/v2",{body:JSON.stringify(u),headers:{Accept:"application/json","Timeout-Seconds":"3","Auth-Token":"dea92562-81ad-45f0-bd74-292256e68e9d","Content-Type":"application/json"},method:"POST"});S.ok&&(d=await S.json(),Ae.set(JSON.stringify(u),d))}catch(S){console.error(S)}let v;if(d){$=d.result.confidence,m=d.result.verbose_output,console.log(d),d.result.confidence==="verified"||d.result.confidence==="unknown"||d.result.confidence===""?q=!0:q=!1;let S=[...Ie.POPULAR_DOMAINS,"builder.ai","mac.com"];if(v=(()=>{let E=Ie.run({email:u.email,domains:S,secondLevelDomains:["yahoo","hotmail","mail","live","outlook"],topLevelDomains:[...Ie.POPULAR_TLDS,"tv","company"]});if(E)return E.full})(),v&&u.email.includes("@")&&u.email.trim().endsWith(".cmo")&&(v=u.email.replace(".cmo",".com")),v){for(let E of S)if(v.endsWith(`@${E}`)){$="illegitimate",m="typoDomain",q=!1;break}}}v&&console.log({suggestion:v})}return t&&$a(b,q?"valid":"invalid",O,w,ae),[q,{ExperianPhoneConfidenceLevel:V,ExperianPhoneType:U,ExperianEmailConfidenceLevel:$,ExperianEmailConfidenceLevelVerbose:m}]},g=b=>h("phone",i,s,o,b),x=b=>h("email",n,[n],c,b);return i.addEventListener("focusout",()=>g(15)),n.addEventListener("focusout",()=>x(15)),{validatePhone:g,validateEmail:x}}async function Na(e){return new Promise(function(t,a){let i=document.createElement("script");i.onload=t,i.onerror=a,i.src=e,document.head.appendChild(i)})}function Wa(e){return e.data&&e.data.event&&e.data.event.indexOf("calendly.")===0}var ko=String.raw,wo=String.raw,_o=wo`
    .calendly-spinner {
        position: absolute;
        top: 50%;
        left: 0;
        right: 0;
        transform: translateY(-50%);
        text-align: center;
        z-index: -1;
    }
    .calendly-spinner > div {
        display: inline-block;
        width: 18px;
        height: 18px;
        background-color: #e1e1e1;
        border-radius: 50%;
        vertical-align: middle;
        animation: calendly-bouncedelay 1.4s infinite ease-in-out;
        animation-fill-mode: both;
    }
    .calendly-spinner .calendly-bounce1 {
        animation-delay: -0.32s;
    }
    .calendly-spinner .calendly-bounce2 {
        animation-delay: -0.16s;
    }

    @keyframes calendly-bouncedelay {
        0%,
        80%,
        100% {
            transform: scale(0);
        }
        40% {
            transform: scale(1);
        }
    } ;
`,xo="https://assets.calendly.com/assets/external/widget.ts",Ct=class extends HTMLElement{static properties(){return[]}constructor(){super()}product;container;connectedCallback(){let t=document.createElement("style");t.innerHTML=_o,document.body.appendChild(t);let a=document.createElement("div");a.setAttribute("style","position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 1020px; min-width: 320px; width: 100%; overflow-y:auto; -webkit-overflow-scrolling:auto;"),this.appendChild(a),this.container=a,a.style.height="710px";let i=document.createElement("div");i.innerHTML=ko`<div class="calendly-spinner" style="position: absolute; top: 265px;">
            <div class="calendly-bounce1"></div>
            <div class="calendly-bounce2"></div>
            <div class="calendly-bounce3"></div>
        </div>`,a.appendChild(i),this.init(a).then(()=>{},r=>console.error(r))}get _calendly(){return window.Calendly?Promise.resolve(window.Calendly):Na(xo).then(()=>window.Calendly)}get url(){return this.getAttribute("data-url")}get firstName(){return this.getAttribute("first-name")||new URL(window.location.href).searchParams.get("first_name")}get lastName(){return this.getAttribute("last-name")||new URL(window.location.href).searchParams.get("last_name")}get email(){return this.getAttribute("email")||new URL(window.location.href).searchParams.get("email")}get redirectURL(){let t=this.getAttribute("redirect-url")??"";return t||(t="/thank-you"),new URL(t,window.location.href).href}get title(){return this.getAttribute("title")||"Schedule your call"}async init(t){let a=this.url,i,r;if(this.url)i=new URL(this.url),r=this.title;else{let n={country_code:"IN"};try{let x=document.getElementById("context");if(x){let b=JSON.parse(x.innerText);b&&b.country&&(n={country_code:b.country})}}catch{}let c=Re(n.country_code);c||(c=ua()),new URL(window.location.href).searchParams.has("dev-force-location")&&(console.log(c),c=Re(new URL(window.location.href).searchParams.get("dev-force-location")?.toUpperCase())),this.product=le(new URL(window.location.href));let{calendlyURL:h,calendlyTitle:g}=ze(c,this.product);i=new URL(h),r=g}new URL(window.location.href).searchParams.has("test-calendly")&&(console.log("Assigned URL would have been: "+i.toString()),i=new URL("https://calendly.com/d/chc-sgn-m7z/demo-call-builder-ai-studio-store-uk")),i.searchParams.set("hide_landing_page_details","1"),i.searchParams.set("hide_event_type_details","1"),i.searchParams.set("hide_gdpr_banner","1"),i.searchParams.set("primary_color","6200ea"),this.firstName&&i.searchParams.set("first_name",this.firstName),this.lastName&&i.searchParams.set("last_name",this.lastName),this.email&&i.searchParams.set("email",this.email);let s=new URL(window.location.href);for(let n of["utm_source","utm_medium","utm_campaign","utm_content","utm_term"]){let c=s.searchParams.get(n);c&&i.searchParams.set(n,c)}if(a){let n=document.createElement("div");n.innerHTML=r,n.setAttribute("style","background-color: white; padding-top: 20px; padding-bottom: 20px; text-align: center; font-weight: bold; width: 100%; max-width: 400px;"),t.appendChild(n)}let o;i.searchParams.set("embed_domain","www.builder.ai"),i.searchParams.set("embed_type","Inline"),o=document.createElement("iframe"),o.src=i.href,o.width="100%",o.height="100%",o.frameBorder="0",o.setAttribute("style","display: inline; height: 100%; width: 100%; max-width: 400px;"),o.setAttribute("sandbox","allow-scripts allow-forms allow-same-origin"),t.appendChild(o),o.addEventListener("load",()=>{t.firstChild.remove(),this.dispatchCustomEvent("book_demo_calendar_loaded",{})},{once:!0}),window.addEventListener("message",this.listener.bind(this))}disconnectedCallback(){window.removeEventListener("message",this.listener),this.innerHTML=""}dispatchCustomEvent(t,a){let i=new CustomEvent(t,{detail:a,cancelable:!0,composed:!0,bubbles:!0});return this.dispatchEvent(i)}listener(t){if(Wa(t)){if(t.stopPropagation(),t.data.event==="calendly.date_and_time_selected")this.container.style.height="1020px",this.dispatchCustomEvent("book_demo_calendar_time_selected",{});else if(t.data.event==="calendly.event_scheduled"){this.container.style.height="710px";let a=new URL(this.redirectURL);try{a.searchParams.set("event",t.data.payload.event.uri.split("/")[4]),a.searchParams.set("invitee",t.data.payload.invitee.uri.split("/")[6])}catch(o){console.log(o)}let i=a.href,r={redirectURL:i,calendlyEventURI:t.data.payload.event.uri,calendlyInviteeURI:t.data.payload.invitee.uri};this.dispatchCustomEvent("book_demo_calendar_booked",r)&&(window.location.href=i)}}}};customElements.define("book-demo-calendar",Ct);function So(e){let t=["legacy","v0"],a="v0",i=e.getAttribute("data-mode");return i||(i=a),i=i.toLowerCase(),t.includes(i)||(i=a),e.getAttribute("data-mode")!=i&&e.setAttribute("data-mode",i),i}function Ao(e){let t=So(e);if(new URL(window.location.href).pathname==="/app"){let a=document.querySelector("#formtitle");a&&(a.style.display="none");let i=document.createElement("script");i.onload=function(){let r=document.createElement("script");r.innerText=`hbspt.forms.create({
    region: "eu1",
    portalId: "25293623",
    formId: "2f5e3e83-0454-4db5-98d4-75c76b171678"
  });`,e.appendChild(r)},i.setAttribute("src","//js-eu1.hsforms.net/forms/embed/v2.js"),e.appendChild(i);return}t==="v0"?Et(e):console.error(`Unexpected builder-form mode: ${t}`)}function Io(){let e=!1,t="";if(window.sessionStorage)try{let s=window.sessionStorage.getItem("get_started");s==="get_started_store"?(e=!0,t="StudioStore"):s==="get_started_pro"&&(e=!0,t="StudioPro")}catch{}let a=new URL(window.location.href);e&&(t==="StudioPro"&&a.pathname.indexOf("thank-you")>-1?k({event:"get_started_pro_demo_thankyou"}):a.pathname.startsWith("/video-explainer")?k({event:"get_started_pro_video_videoexplainer"}):a.pathname==="/how-to-create-an-app"?k({event:"get_started_pro_guide_guidepage"}):a.pathname==="/formsb/download-guide"?k({event:"get_started_pro_guide_formviewed"}):t==="StudioStore"&&a.pathname.indexOf("thank-you")>-1?k({event:"get_started_store_demo_thankyou"}):a.pathname==="/formsb/download-guide-studio-store"?k({event:"get_started_store_guide_formviewed"}):a.pathname==="/studio-store-product/explainer-video"&&k({event:"get_started_store_video_videoexplainer"}));let r=document.querySelectorAll("form[is='builder-form']");for(let s of r)if(!s.hasAttribute("data-builder-form-upgraded")){try{Ao(s)}catch(o){console.error(o)}if(s.setAttribute("data-builder-form-upgraded",""),e){let o=s.getAttribute("data-option");s.addEventListener("focusout",function(n){let h=n.target.getAttribute("name");if(h){for(let g of xe)if(g.name===h){o==="download-guide"?k({event:"get_started_pro_guide_forminteracted"}):o==="download-guide-store"&&k({event:"get_started_store_guide_forminteracted"});break}}},{once:!0}),o==="download-guide"?s.addEventListener("submit",function(n){k({event:"get_started_pro_guide_formsubmitted"})}):o==="download-guide-store"&&s.addEventListener("submit",function(n){k({event:"get_started_store_guide_formsubmitted"})})}if(a.searchParams.has("dev-shorten-form")||s.hasAttribute("data-experiment-shorten-form"))try{et(s)}catch(o){console.log(o)}}}function Eo(){let e=new URL(window.location.href);if(e.searchParams.has("dev-disable-get-started-url")===!0)return;let t="";try{let o=document.getElementById("context");if(o){let n=JSON.parse(o.innerText);n&&n.country&&(t=n.country)}}catch{}if(t!=="IN")return;let i=le(e)==="StudioStore"?"/get-started/studio-store":"/get-started",r=new URL(i,window.location.href),s=window.location.href;e.searchParams.has("from")&&(s=e.searchParams.get("from")),r.searchParams.set("from",s),document.querySelectorAll("a[href='#getstarted']").forEach(o=>{o.setAttribute("href",r.href)})}async function Co(){if(new URL(window.location.href).pathname.startsWith("/quiz-result")===!1)return;let t=W("Email");if(t){let a=new URLSearchParams({Email:t,CompanySize:W("CompanySize"),AppCategory:W("AppCategory"),QuizRecommendedProduct:W("QuizRecommendedProduct"),QuizBusinessNeed:W("QuizBusinessNeed"),QuizTechComfortLevel:W("QuizTechComfortLevel"),QuizInvolvementPreference:W("QuizInvolvementPreference"),QuizExpectedBudget:W("QuizExpectedBudget")});try{await Ge(a)}catch(i){console.error(i)}}}function Do(){Io(),Eo(),Co()}var Ua=!1;for(let e of["DOMContentLoaded","DeferredDOMContentLoaded"])window.addEventListener(e,()=>{Ua||(Ua=!0,Do())});
